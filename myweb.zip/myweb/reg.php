<?php
include('ses.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register New User</title>

</head>


<body class="w3-animate-opacity">

    <?php
    if(isset($_COOKIE['er'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-danger alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:100px;">
            <strong><?php echo $_COOKIE['er']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>

    <?php
    if(isset($_COOKIE['vaco'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:100px;">
            <strong><?php echo $_COOKIE['vaco']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>


    <script>
    setTimeout(function() {
        document.getElementById('alt1').style.display = "none";
    }, 3000)
    </script>









    <?php
    if(isset($_SESSION['reg']) && $_SESSION['reg'] == "login" ||  isset($_SESSION['log']) &&  $_SESSION['log'] == "login"){
        echo "
        <script>
        window.location.href = '/myweb/index.php'
        </script>
        ";
    }
    else{
        include('navbar.php');
    }
    ?>


    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="main-banner header-text" id="top1">
        <div class="Modern-Slider">
            <div class="item item-3">
                <div class="img-fill">
                    <div class="text-content">
                    </div>
                </div>
            </div>

        </div>
    </div>

    <br><br><br>

    <div class="container">
        <!-- <center class=" bg-success text-white" style="border-radius:10px;font-size:17px;font-weight:bold;">If You New User And Register Then You Getting 10% Discount</center> -->
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="text-center mb-4">
                </div>
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h2 class="card-title text-center mb-4">Register</h2>
                        <form action="lrm.php" method="post" id="formreg" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input name="n" class="form-control" id="name" placeholder="John Doe" type="text" />
                            </div>
                            <div class="form-group">
                                <label for="email">Email Id</label>
                                <input name="e" class="form-control" id="email" placeholder="john.doe@domain.com"
                                    type="email" />
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input name="p" class="form-control" id="password" placeholder="Password"
                                    type="password" maxlength=9 minlength=1 /> <br>
                                <span><input type="checkbox" class="" id="ch" onclick="show()"> Show Password</span>
                                <script>
                                document.getElementById('password').type = "password"

                                function show() {
                                    var x = document.getElementById('password');
                                    if (x.type === "password") {
                                        x.type = "text";
                                    } else {
                                        x.type = "password";
                                    }
                                }
                                </script>
                            </div>
                            <div class="form-group">
                                <label for="confirm-password">Confirm Password</label>
                                <input name="cp" class="form-control" id="password1" placeholder="Confirm Password"
                                    type="password" maxlength=9 minlength=1 /> <br>
                                <span><input type="checkbox" class="" id="ch1" onclick="show1()"> Show Password</span>
                                <script>
                                document.getElementById('password1').type = "password"

                                function show1() {
                                    var x = document.getElementById('password1');
                                    if (x.type === "password") {
                                        x.type = "text";
                                    } else {
                                        x.type = "password";
                                    }
                                }
                                </script>
                            </div>

                            <div class="form-group">
                                <label for="confirm-password">Mobile Num</label>
                                <input name="m" class="form-control" id="confirm-password"
                                    placeholder="Enter Mobile Num" type="text" maxlength=10 minlength=1 />
                            </div>


                            <div class="form-group">
                                <label for="confirm-password">Address</label>
                                <textarea name="ad" class=" form-control"></textarea>
                            </div>

                            <div class="form-group">
                                <label for="confirm-password">Profile Picture</label>
                                <input name="f1" class="form-control" type="file" />
                            </div>
                            <input type="submit" class="btn btn-primary btn-block" name="reg" value="Register">
                            <a href="log.php" class="btn btn-outline-primary btn-block mt-3" type="button">Already have
                                an
                                account? Login</a>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div><br><br><br><br>

    <script>
    // Custom domain validation method
    $.validator.addMethod("allowedDomain", function(value, element) {
        var domain = value.split('@')[1];
        var allowed = ['gmail.com', 'ac.in', 'yourdomain.com'];
        return this.optional(element) || allowed.includes(domain);
    }, "Sirf gmail.com, ac.in ya allowed domains hi valid hain.");

    $("#formreg").validate({
        rules: {
            n: {
                required: true
            },
            e: {
                required: true,
                email: true,
                allowedDomain: true
            },
            p: {
                required: true,
                minlength: 8,
                maxlength: 12,
                pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%?&])[A-Za-z\d@$!%?&]{8,12}$/
            },
            cp: {
                required: true,
                equalTo: "#password"
            },
            m: {
                required: true,
                pattern: /^[0-9]{10}$/,
                maxlength: 10,
                minlength: 10
            },
            f1: {
                required: true,
                accept: "image/*"
            },
            ad: {
                required: true
            }
        },
        messages: {
            e: {
                required: "Please enter email",
                email: "Please enter valid email ",
                allowedDomain: "Enter Valid Email"
            }
            // baaki messages same as before...
        },
        highlight: function(element) {
            $(element).addClass("highlight").removeClass("valid");
        },
        unhighlight: function(element) {
            $(element).removeClass("highlight").addClass("valid");
        },
    });
    </script>
    <?php
    include('foot.php');
    ?>
</body>

</html>