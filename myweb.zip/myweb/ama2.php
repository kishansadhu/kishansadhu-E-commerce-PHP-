<?php
include('ses.php');

        if(isset($_POST['addadm'])){
            $n = $_POST['an'];
            $e = $_POST['ae'];
            $p = $_POST['ap'];
            $em = $_SESSION['ue'];

    $rs = "SELECT email FROM admin where email='$em'";
    $rsr =mysqli_query($con,$rs);
       if(mysqli_num_rows($rsr) >0){
            $ui = "UPDATE admin  SET name='$n',email='$e',password='$p'  where email='$em' ";
            $ur = mysqli_query($con,$ui);

            setcookie("adu","Updated successfully",time()+2);
            echo "<script>
            window.location.href = '/myweb/ada.php';
            </script>";
            }

}
?>