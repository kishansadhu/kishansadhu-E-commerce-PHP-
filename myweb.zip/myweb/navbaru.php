<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="/myweb/plug/bootstrap-4.0.0-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/owl.css">

    <style>
    /* this is for the form error */
    label.error {
        border-radius: 5px;
        color: red;
    }

    .error {
        margin-top: 1.5px;
        color: red;
        font-size: 15px;
        font-weight: 500;
    }

    .highlight {
        border: 2px solid rgb(252, 150, 150);
    }

    .valid {
        border: 2px solid green;

    }

    body.modal-open {
        overflow: visible !important;
        padding-right: 0 !important;
    }

    </style>
</head>
<script src="/myweb/plug/js/jquery-3.7.1.min.js"></script>
<script src="/myweb/plug/js/jquery.validate.js"></script>
<script src="/myweb/plug/js/additional-methods.js"></script>

<script src="/myweb/plug/bootstrap-4.0.0-dist/js/bootstrap.bundle.js"></script>

<body>

    <header class="">
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <span class="navbar-brand" href="index.php">
                    <h2>Mobile Store<em></em></h2>
                </span>
                <button class="navbar-toggler" style="border-radius:15px;" type="button" data-toggle="collapse" data-target="#navbarResponsive"
                    aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="#" style="visibility:hidden;">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="products.php">Products</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="cmp.php">Compare Products</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact Us</a>
                        </li>
                        <li class="nav-item dropdown show">
                            <img class="dropdown-toggle btn img rounded-circle img-fluid " type="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-target="#open"
                                src="uploads/<?php echo $_SESSION['r']['i'];?>" alt="img"
                                style="height:60px;width:60px;">

                            <div class="dropdown-menu" id="open">
                                <a class="dropdown-item" href="user.php">Profile</a>
                                <a class="dropdown-item" href="checkout.php"><svg xmlns="http://www.w3.org/2000/svg"
                                        width="16" height="16" fill="currentColor" class="bi bi-bag-fill"
                                        viewBox="0 0 16 16">
                                        <path
                                            d="M8 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 8 1m3.5 3v-.5a3.5 3.5 0 1 0-7 0V4H1v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V4z" />
                                    </svg>
                                    <?php
                                    $em = $_SESSION['r']['e'];
                                    $sel = "SELECT  * FROM orders WHERE email='$em'";
                                    $run = mysqli_query($con,$sel);

                                    if(mysqli_num_rows($run) > 0){
                                        $i = 0;
                                        while($f = mysqli_fetch_assoc($run)){
                                            $i =  $i + 1;
                                        }

                                        echo "<sup>".$i.'</sup>';
                                    }
                                    else{
                                        echo "<sup>0</sup>";
                                    }
                                    ?>
                                    <sup></sup>
                                </a><hr>

                                <a class="dropdown-item" style="visibility:hidden;" href="logout.php"></a>
                                <a class="dropdown-item" href="logout.php">LogOut</a>
                            </div>
                        </li>





                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <style>
    input.filled-button:hover{
        border:none;
    }
    a.filled-button:hover{
        border:none;
    }
</style>





    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/slick.js"></script>
    <script src="assets/js/accordions.js"></script>
<?php

date_default_timezone_set('Asia/Kolkata');
$dt = date("Y-m-d H:i:s", time());

$skl = mysqli_query($con, "SELECT * FROM orderp WHERE email='$em' AND stat='complete'");

if ($row = mysqli_fetch_assoc($skl)) {
    $orderTime = strtotime($row['dt']);
    $currentTime = time();
    $timeDiff = $currentTime - $orderTime;

    $waitSeconds = 10; // 10 sec ke liye
    // $waitSeconds = 24 * 60 * 60; // 24 ke liye

    if ($timeDiff >= $waitSeconds) {
        echo "
        <script>
            setTimeout(function() {
                window.location.href = 'checkout2.php';
            }, 1000); // 1sec bad redirect hoga mere dusre page me
        </script>
        ";
    } else {
        $remaining = $waitSeconds - $timeDiff;
        echo "
        <script>
            setTimeout(function() {
                window.location.href = 'checkout2.php';
            }, " . ($remaining * 1000) . ");
        </script>
        ";
    }
} else {
    echo "";
}

?>

</body>

</html>