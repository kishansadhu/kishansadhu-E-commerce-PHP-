<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
    <?php
    include('admin.php');
    if(isset($_POST['up1'])){
        $e = $_POST['up'];
        $e1 = $_POST['up2'];

        $_SESSION['ue'] =  $e;
        $_SESSION['ue1'] =  $e1;

        $seld = "SELECT  * FROM orders where name='$e1' and email='$e'";
        $rund = mysqli_query($con,$seld);
        $fd = mysqli_fetch_assoc($rund);

    }
    else{
        echo "<script>
        window.location.href ='/myweb/ado.php'
        </script>";
    }
    ?>
    <br><br><br>
    <div class="container card" style="padding:20px;border-radius:20px;">
        <h2>Edit Details</h2>
        <hr><br>
        <form action="oma2.php" method="post" id="ford" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Name</label>
                <input name="on" class="form-control" id="name" type="text" value='<?php echo $fd['name']; ?>' readonly />
            </div>
            <div class="form-group">
                <label for="email">Prize</label>
                <input name="op" class="form-control" id="email" type="text" value='<?php echo $fd['prize']; ?>' />
            </div>
            <div class="form-group">
                <label for="password">Quntity</label>
                <div class="input-group">
                    <input name="oq" class="form-control" id="password" type="text" value='<?php echo $fd['qun']; ?>' />
                </div>
            </div>
            <div class="form-group">
                <label for="confirm-password">Order Total</label>
                <div class="input-group">
                    <input name="otot" class="form-control" id="password1" type="text" value='<?php echo $fd['tot']; ?>' />
                </div>
            </div>

            <div class="form-group">
                <label for="confirm-password">Order Statuse</label>
                <div class="input-group">
                    <input name="os" class="form-control" id="confirm-password" type="text" value='<?php echo $fd['stat']; ?>' />
                </div>
            </div>

            <div class="form-group">
                <label for="confirm-password">Order Method</label>
                <div class="input-group">
                    <input name="ome" class="form-control" id="confirm-password" type="text" value='<?php echo $fd['method']; ?>' />
                </div>
            </div>

            <div class="form-group">
                <label for="confirm-password">Order Email</label>
                <div class="input-group">
                    <input name="oe" class="form-control" id="confirm-password" type="email" value='<?php echo $fd['email']; ?>' readonly/>
                </div>
            </div>

            <input type="submit" class="btn btn-success btn-block" name="addo" value="Update Details">
        </form>

        <script>
        $("#ford").validate({
            rules: {
                on: {
                    required: true
                },
                op: {
                    required: true
                },
                oq: {
                    required: true
                },
                otot: {
                    required: true
                },
                os: {
                    required: true
                },
                ome: {
                    required: true
                },
                oe: {
                    required: true,
                    email: true
                }

            },
            messages: {
                on: {
                    required: "enter Orde name"
                },
                op: {
                    required: "enter order prize"
                },
                oq: {
                    required: "enter order quntity"
                },
                otot: {
                    required: "enter order total"
                },
                os: {
                    required: "enter order statuse"
                },
                ome: {
                    required: "enter order method"
                },
                oe: {
                    required: "enter order email",
                    email: "enter valid email"
                }
            },
            highlight: function(element) {
                $(element).addClass("highlight").removeClass("valid");
            },
            unhighlight: function(element) {
                $(element).removeClass("highlight").addClass("valid");
            }
        });
        </script>
    </div>




    <?php

if(isset($_POST['up1'])){
    $e = $_POST['up'];
    $e1= $_POST['up2'];
    $_SESSION['ue'] =  $e;
    $_SESSION['ue1'] =  $e1;

    $seld = "SELECT  * FROM orders where email='$e' and name='$e1'";
    $rund = mysqli_query($con,$seld);
    $fd = mysqli_fetch_assoc($rund);
}
else{
    echo "<script>
    window.location.href ='/myweb/ado.php'
    </script>";
}

?>



</body>
</html>