<?php
include('ases.php');
if(isset($_POST['rm1'])){
        $mc = $_POST['rm'];
        $mc1 = $_POST['rm2'];
        $del1 = "DELETE FROM contact WHERE email='$mc' and ques='$mc1'";
        $drun1 = mysqli_query($con,$del1);
        setcookie("delq","deleted Successfully",time()+2);
       echo "
        <script>
        window.location.href ='/myweb/conq.php';
        </script>
        ";

}



if(isset($_POST['uqu'])){
    $n = $_POST['an1'];
    $e = $_POST['ae1'];
    $p = $_POST['ap1'];

        $ui = "INSERT INTO contact (name,email,ques) VALUES ('$n','$e','$p')";
        $ur = mysqli_query($con,$ui);

        setcookie("uqadd","Added Successfully",time()+2);
        echo "<script>
        window.location.href ='/myweb/conq.php';
        </script>";
        }


?>