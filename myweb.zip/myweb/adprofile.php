<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile</title>
</head>

<body>
    <?php
    include('admin.php');
    ?>
    <div class="container mt-4 bg-white p-4" style="border-radius:20px;">
        <center class="" style="border-bottom:1px solid lightgray;">
            <span><span style="font-size:30px;color:#a4c639;">M</span><span style="font-size:30px;">y</span>
                <span><span style="font-size:30px;color:#a4c639;">P</span><span
                        style="font-size:30px;">rofile</span></span><br>
        </center><br><br><br>
        <div class="row">
            <div class="col-md-3 col-lg-3" style="padding:20px;">
                <?php
                $ea = $_SESSION['am']['e'];
                $sl = "SELECT * FROM admin where email='$ea'";
                $sr =mysqli_query($con,$sl);
                $f = mysqli_fetch_assoc($sr);
                ?>
                <i class="fa fa-5x fa-user-secret  mt-1" style="height:40px;"></i><br>
                <h3>Admin</h3>

            </div>
            <div class="col-md-1 col-lg-1"></div>
            <form action="adprofile.php" method="post" id="formupdate" enctype="multipart/form-data">
                <div class="row">
                    <div class="div.col-lg-6">
                        <div class="form-group">

                            <div class="col-xs-6">
                                <label for="email1">
                                    <h4>Email</h4>
                                </label>
                                <input type="email" class="form-control" name="e1" id="email1"
                                    value='<?php echo $f['email']; ?>' readonly placeholder="Enter Email"
                                    title="enter your first name if any.">
                            </div>
                        </div>

                        <div class="col-xs-6">
                            <label for="password">
                                <h4>Password</h4>
                            </label>
                            <input type="password" class="form-control" name="p1" id="password"
                                value="<?php echo  $f['password']; ?>" placeholder="password"
                                title="enter your password." >
                            <span><input type="checkbox" class="" id="ch" onclick="show()"> Show
                                Password</span>
                            <script>
                            document.getElementById('password').type = "password"

                            function show() {
                                var x = document.getElementById('password');
                                if (x.type === "password") {
                                    x.type = "text";
                                } else {
                                    x.type = "password";
                                }
                            }
                            </script>
                        </div><br><br>
                    </div>

                </div>

                <input type="submit" name="upd" class="btn btn-lg btn-success" value="Update Details">
            </form>

            <?php
            if(isset($_POST['']))
            ?>
            <hr>
        </div>
    </div>
    </div>
    </div>




    <script>
    $("#formupdate").validate({
        rules: {
            e1: {
                required: true,
                email: true
            },
            p11: {
                required: true,
                minlength: 8,
                maxlength: 12,
                // Regex: kam se kam 1 lowercase, 1 uppercase, 1 digit, 1 special character
                pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%?&])[A-Za-z\d@$!%?&]{8,12}$/
            }

        },
        messages: {
            e1: {
                required: "Please enter email",
                email: "Please enter valid email "
            },
            p1: {
                required: "Please provide a password",
                minlength: "Password must be exactly 8",
                maxlength: "Password Length less then 12",
                pattern: "Password Formate Ksadhu@1"
            }
        },
        highlight: function(element) {
            $(element).addClass("highlight").removeClass("valid");
        },
        unhighlight: function(element) {
            $(element).removeClass("highlight").addClass("valid");
        }
    });
    </script>

</body>

</html>