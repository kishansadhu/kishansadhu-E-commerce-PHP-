<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
    <?php
    include('admin.php');

    if(isset($_POST['up1'])){
        $e = $_POST['up'];
        $_SESSION['ue'] =  $e;

        $seld = "SELECT  * FROM user where email='$e'";
        $rund = mysqli_query($con,$seld);
        $fd = mysqli_fetch_assoc($rund);
    }
    else{
        echo "<script>
        window.location.href ='/myweb/adu.php'
        </script>";
    }
    ?>
<br><br><br>
        <div class="container card" style="padding:20px;border-radius:20px;">
            <h2>Edit Details</h2><hr><br>
            <form action="uma2.php" method="post" id="formreg" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="name">Name</label>
                    <input name="n" class="form-control" id="name" type="text" value='<?php echo $fd['name']; ?>' />
                </div>
                <div class="form-group">
                    <label for="email">Email Id</label>
                    <input name="e" class="form-control" id="email" type="email" value='<?php echo $fd['email']; ?>' readonly/>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                        <?php
                        $n = $fd['password'];
                        $n1 = "";

                        $m = array(
                           "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z",
                        "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
                        "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
                        "!", "\"", "#", "$", "%", "&", "'", "(", ")", "*", "+", ",", "-", ".", "/", ":", ";", "<", "=", ">", "?", "@", "[", "\\", "]", "^", "_", "`", "{", "|", "}", "~",
                        " ", "\t", "\n"
                    );

                            for($i = 0; $i < strlen($n); $i++) {
                                for($j = 0; $j < count($m); $j++) {
                                    if($n[$i] == $m[$j]) {
                                        $n1 .= $m[$j - 3];  // Adding the character 3 positions ahead
                                    }
                                }
                            }

                        ?>
                        <input name="p" class="form-control" id="password" type="password" value='<?php echo $n1; ?>' /><br>
                    <span><input type="checkbox" class="" id="ch" onclick="show()"> Show
                        Password</span>
                    <script>
                    document.getElementById('password').type = "password"

                    function show() {
                        var x = document.getElementById('password');
                        if (x.type === "password") {
                            x.type = "text";
                        } else {
                            x.type = "password";
                        }
                    }
                    </script>
                </div>

                <div class="form-group">
                    <label for="confirm-password">Mobile Num</label>
                    <input name="m" class="form-control" id="confirm-password" type="text" value='<?php echo $fd['mobile']; ?>' maxlength=10 minlength=1/>

                </div>


                <div class="form-group">
                    <label for="confirm-password">Address</label>
                    <textarea name="ad" class=" form-control">
                        <?php echo $fd['adr']; ?>'
                        </textarea>
                </div>

                <div class="form-group">
                    <label for="confirm-password">Profile Picture</label><br>
                    <img src="uploads/<?php echo $fd['img']; ?>" alt="" height="60px" width="60px"><br>
                    <input name="f1" class="form-control" type="file" />
                </div>
                <input type="submit" class="btn btn-success btn-block" name="upm" value="Update Details">
            </form>

            <script>
            $("#formreg").validate({
                rules: {
                    n: {
                        required: true
                    },
                    e: {
                        required: true,
                        email: true
                    },
                    p: {
                        required: true,
                        minlength: 8,
                        maxlength: 12,
                        // Regex: kam se kam 1 lowercase, 1 uppercase, 1 digit, 1 special character
                        pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%?&])[A-Za-z\d@$!%?&]{8,12}$/
                    },
                    cp: {
                        required: true,
                        equalTo: "#password"
                    },
                    m: {
                        required: true,
                        maxlength: 10,
                        minlength: 10,
                        pattern:/^[0-9]{10}$/
                    },
                    ad: {
                        required: true
                    }

                },
                messages: {
                    n: {
                        required: "Please enter your full name"
                    },
                    e: {
                        required: "Please enter email",
                        email: "Please enter valid email "
                    },
                    p: {
                        required: "Please provide a password",
                        minlength: "Password must be exactly 8",
                        maxlength: "Password Length less then 12",
                        pattern: "Password Formate Ksadhu@1"
                    },
                    cp: {
                        required: "Please Enter confirm password",
                        equalTo: "Passwords do not match"
                    },
                    m: {
                        required: "Enter Mobile Num",
                        maxlength: "Max Length 10",
                        minlength: "Max Length 10",
                        pattern:"Enter Valid Mobile Num"
                    },
                    ad: {
                        required: "Enter Your Address"
                    }
                },
                highlight: function(element) {
                    $(element).addClass("highlight").removeClass("valid");
                },
                unhighlight: function(element) {
                    $(element).removeClass("highlight").addClass("valid");
                }
            });
            </script>
        </div>




</body>
</html>