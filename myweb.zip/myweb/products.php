<?php
include('ses.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Product Page</title>
</head>

<body class="w3-animate-opacity bg-light">
    <?php
    if(isset($_COOKIE['pos'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-danger alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:200px;">
            <strong><?php echo $_COOKIE['pos']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>

    <?php
    if(isset($_COOKIE['pos1'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-danger alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:200px;">
            <strong><?php echo $_COOKIE['pos1']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>

    <?php
    if(isset($_COOKIE['atc'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-danger alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:200px;">
            <strong><?php echo $_COOKIE['atc']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>


    <?php
    if(isset($_COOKIE['atc1'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:200px;">
            <strong><?php echo $_COOKIE['atc1']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>






    <script>
    setTimeout(function() {
        document.getElementById('alt1').style.display = "none";
    }, 2000)
    </script>






    <?php
    if(isset($_SESSION['reg']) && $_SESSION['reg'] == "login" ||  isset($_SESSION['log']) &&  $_SESSION['log'] == "login"){
        include('navbaru.php');
    }
    else{
        include('navbar.php');
    }
    ?>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="main-banner header-text" id="top1">
        <div class="Modern-Slider">
            <div class="item item-3">
                <div class="img-fill">
                    <div class="text-content">
                    </div>
                </div>
            </div>

        </div>
    </div>







<!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->



    <div class="container bg-light  " style="box-shadow:5px 5px 10px black;">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <button class="navbar-toggler mt-0" type="button" data-toggle="collapse" data-target="#navbarText"
                aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarText">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <button class="nav-link btn  text-dark menu-item" style="background:#F8F9FA;border:none;" data-target="sam">Samsung</button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link btn  text-dark menu-item" style="background:#F8F9FA;border:none;"  data-target="vivo">Vivo</button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link btn  text-dark menu-item" style="background:#F8F9FA;border:none;" data-target="redmi">Redmi</button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link btn  text-dark menu-item" style="background:#F8F9FA;border:none;" data-target="oppo">Oppo</button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link btn  text-dark menu-item" style="background:#F8F9FA;border:none;" data-target="realme">Realme</button>
                    </li>
                    <style>
                    .services img {
                        height: 300px;
                    }
                    </style>
                    <li class="nav-item">
                    </li>
                    <li class="nav-item">
                    </li>
                    <li class="nav-item">
                    </li>


                    <form action='products.php' method='post' class="form">
                        <div class="row">
                            <div class="col-lg-10 col-7" style="margin-left:0px;">
                                <input type='search' name='sr' class=" form-control" placeholder="Search Mobile">
                            </div>
                            <div class="col-lg-2 col-3" style="padding-left:0px;">
                                <input type='submit' value='search' name='spr' class="filled-button">
                            </div>
                        </div>
                    </form>

                    <li class="nav-item active">
                        <a class="nav-link" href="#" style="visibility:hidden;">Home</a>
                    </li>

                    <form action='products.php' method='post'>
                        <a href='#' class="dropdown-toggle btn ml-5 mt-1"
                            style="background:#A4C639;color:white;border-radius:5px;" type="button" id="productDropdown"
                            id='tog' data-toggle="dropdown">
                            Filter
                        </a>
                        <div class="dropdown-menu container bg-light pl-5" aria-labelledby="productDropdown">
                            <div class="row">
                                <div class="col-lg-4 col-3" style='padding:0px;margin:0px;'>
                                    <input type='text' name='fl' class=" form-control bg-light"
                                        placeholder="Start Prize">
                                </div>
                                <div class="col-lg-4 col-3" style='padding:0px;margin:0px;'>
                                    <input type='text' name='fl1' class=" form-control bg-light"
                                        placeholder="Last Prize">
                                </div>
                                <input type='submit' value='search' name='filt' class="filled-button"
                                    style='margin-left:10px;'>
                            </div>
                        </div>
                    </form>

            </div><br><br>

        </nav>
    </div>



    <style>
    nav {
        z-index: 5000;
    }

    .navsc {
        height: 0px;
    }
    </style>
    <div class="container navsc bg-white"><br>
        <?php

if(isset($_POST['spr'])){
    $a = $_POST['sr'];
    $s = "SELECT * FROM product WHERE  name like '$a%'  ";
    $r = mysqli_query($con,$s);

    if(mysqli_num_rows($r) > 0 && $a != null){
        ?>
        <style>
        /* width */
        ::-webkit-scrollbar {
            width: 10px;
        }

        /* Track */
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        /* Handle */
        ::-webkit-scrollbar-thumb {
            background: #888;
        }

        /* Handle on hover */
        ::-webkit-scrollbar-thumb:hover {
            background: #555;
        }

        .navsc {
            overflow-y: scroll;
            height: 300px;
            z-index: 1000;
        }

        #ps:hover {
            background: rgb(245, 244, 244);
            color: white;
        }
        </style><?php
        while($f = mysqli_fetch_assoc($r)){
            echo "" ?>
        <div class="container">
            <form action="pmanage.php" method="post">
                <div class="row" id="ps">
                    <div class="col-lg-1 col-2">
                        <img src="img/<?php echo $f['img']; ?>" alt="img" width="50px" height="50px">
                    </div>
                    <div class="col-lg-10 col-10">
                        <!-- class="filled-button" -->

                        <input type="submit" id="psl" name="dt" value="<?php  echo $f['name'];?>"
                            style="background:none;color:black;font-weight:bold;background:#F8F9FA;border:none;margin-top:15px;">

                        <input type="hidden" name="dt1" value="<?php echo $f['name']; ?>">
                        <input type="hidden" name="dt2" value="<?php echo $f['prize']; ?>">
                        <input type="hidden" name="dt3" value="<?php echo $f['offer']; ?>">
                        <input type="hidden" name="dt4" value="<?php echo $f['offr']; ?>">
                        <input type="hidden" name="dt5" value="<?php echo $f['di']; ?>">
                        <input type="hidden" name="dt6" value="<?php echo $f['img']; ?>">
                        <input type="hidden" name="dt7" value="<?php echo $f['about']; ?>">
                        <input type="hidden" name="dt8" value="<?php echo $f['mem']; ?>">
                        <input type="hidden" name="dt9" value="<?php echo $f['inf']; ?>">
                        <input type="hidden" name="dt10" value="<?php echo $f['tec']; ?>">
                    </div>
                </div>
            </form>
        </div><br>
        <?php

}
}
else{
    ?>
        <style>
        .navsc {
            height: 70px;
            z-index: 1000;
        }
        </style>
        <?php
    echo "<div class='container'>
    <center><h3 style='color:black;font-weight:bold;'>Not Find Any Mobile</h3></center>
    </div>";
}

}

?>






















        <?php
if(isset($_POST['filt'])){
    $st1 = mysqli_real_escape_string($con,$_POST['fl']);
    $int1 = (int)str_replace(","," ",$st1);
    $p = number_format($int1);


    $st11 = mysqli_real_escape_string($con,$_POST['fl1']);
    $int11 = (int)str_replace(","," ",$st11);
    $p1 = number_format($int11);


    $s = "SELECT * FROM product where prize >= $p  and prize <=$p1";
    $r = mysqli_query($con,$s);

    if(mysqli_num_rows($r) > 0){
        ?>
        <style>
        /* width */
        ::-webkit-scrollbar {
            width: 10px;
        }

        /* Track */
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        /* Handle */
        ::-webkit-scrollbar-thumb {
            background: #888;
        }

        /* Handle on hover */
        ::-webkit-scrollbar-thumb:hover {
            background: #555;
        }

        .navsc {
            overflow-y: scroll;
            height: 500px;
            z-index: 1000;
        }

        #ps:hover {
            background: rgb(245, 244, 244);
            color: white;
        }

        img {
            width: 100px;
        }
        </style><?php
        while($f = mysqli_fetch_assoc($r)){
            ?>
        <div class="container">
            <br><img src="img/<?php echo $f['img']; ?>" alt="" style="height:200px;width:200px;">
            <hr>
            <form action="pmanage.php" method="POST">
                <p style="font-weight:bold;"><?php echo $f['name']; ?></p>

                <p>
                <div class="row">
                    <div class="col-lg-1 col-3">
                        <h4><sup>&#8377</sup><?php echo $f['prize']; ?></h4>
                    </div>
                    <div class="col-lg-3 col-3">
                        <h6><del><?php echo $f['offer']; ?></del><?php echo $f['offr']; ?></h6>

                    </div>
                </div>
                </p>
                <form action="pmanage.php" method="post">
                    <div class="row">
                        <div class="col-lg-2 col-6">
                            <input type="submit" name="dt" class="filled-button" value="View Details">
                        </div>
                        <div class="col-lg-3 col-6">
                            <input type="submit" name="si" class="filled-button" value="Add cart">
                            <input type="hidden" name="dt11" value="<?php echo $f['qun']; ?>">
                            <input type="hidden" name="dt1" value="<?php echo $f['name']; ?>">
                            <input type="hidden" name="dt2" value="<?php echo $f['prize']; ?>">
                            <input type="hidden" name="dt3" value="<?php echo $f['offer']; ?>">
                            <input type="hidden" name="dt4" value="<?php echo $f['offr']; ?>">
                            <input type="hidden" name="dt5" value="<?php echo $f['di']; ?>">
                            <input type="hidden" name="dt6" value="<?php echo $f['img']; ?>">
                            <input type="hidden" name="dt7" value="<?php echo $f['about']; ?>">
                            <input type="hidden" name="dt8" value="<?php echo $f['mem']; ?>">
                            <input type="hidden" name="dt9" value="<?php echo $f['inf']; ?>">
                            <input type="hidden" name="dt10" value="<?php echo $f['tec']; ?>">
                        </div>
                    </div>
                </form>

            </form>
            <br>
        </div>
        <?php

}
}
else{
    ?>
        <style>
        .navsc {
            height: 70px;
            z-index: 1000;
        }
        </style>
        <?php
    echo "<div class='container'>
    <center><h3 style='color:black;font-weight:bold;'>Not Find Any Mobile</h3></center>
    </div>";
}

}

?>
    </div>













    <style>
    .services img {
        height: 300px;
    }

    .services .container .service-item:hover {
        position: relative;
        bottom: 0.1px;
        transition: 0.2s;
        box-shadow: 2px 2px 9px 0px black;
    }
    </style>

    <div class="content">
        <?php
        $s1 = "SELECT * FROM product where u='sam'";
        $run =mysqli_query($con,$s1);
        ?>
        <div class="services">
            <div class="container content-section w3-animate-opacity" id="sam">
                <div class="row">
                    <?php
            if(mysqli_num_rows($run) > 0 ){
              while($f = mysqli_fetch_assoc($run)){
                ?>
                    <div class="col-md-4">
                        <div class="service-item">
                            <div class="down-content">
                                <?php
                            $n = $f['name'];
                            $p = "SELECT * FROM product WHERE name='$n' ";
                            $p1 = mysqli_query($con,$p);
                            $p2 = mysqli_fetch_assoc($p1);
                            $cn = $p2['qun'] == 0;
                            if($cn == true){
                            echo "<center><p style='color:red;font-weight:bold;'>This Mobile Is Out Of Stock</p></center><hr>";
                            }
                            ?>
                                <br><img src="img/<?php echo $f['img']; ?>" alt="" style="height:200px;width:200px;">
                                <hr>
                                <form action="pmanage.php" method="POST">
                                    <p style="font-weight:bold;"><?php echo $f['name']; ?></p>

                                    <p>
                                    <div class="row">
                                        <div class="col-lg-3">
                                            <h4><sup>&#8377</sup><?php echo $f['prize']; ?></h4>
                                        </div>
                                        <div class="col-lg-9">
                                            <h6><del><?php echo $f['offer']; ?></del><?php echo $f['offr']; ?></h6>

                                        </div>
                                    </div>
                                    </p>
                                    <form action="pmanage.php" method="post">
                                        <div class="row">
                                            <div class="col-lg-6 col-6">
                                                <input type="submit" name="dt" class="filled-button" value="View Details">

                                            </div>
                                            <div class="col-lg-6 col-6">
                                                <input type="submit" name="si" class="filled-button" value="Add cart">
                                                <input type="hidden" name="dt11" value="<?php echo $f['qun']; ?>">
                                                <input type="hidden" name="dt1" value="<?php echo $f['name']; ?>">
                                                <input type="hidden" name="dt2" value="<?php echo $f['prize']; ?>">
                                                <input type="hidden" name="dt3" value="<?php echo $f['offer']; ?>">
                                                <input type="hidden" name="dt4" value="<?php echo $f['offr']; ?>">
                                                <input type="hidden" name="dt5" value="<?php echo $f['di']; ?>">
                                                <input type="hidden" name="dt6" value="<?php echo $f['img']; ?>">
                                                <input type="hidden" name="dt7" value="<?php echo $f['about']; ?>">
                                                <input type="hidden" name="dt8" value="<?php echo $f['mem']; ?>">
                                                <input type="hidden" name="dt9" value="<?php echo $f['inf']; ?>">
                                                <input type="hidden" name="dt10" value="<?php echo $f['tec']; ?>">
                                            </div>
                                        </div>
                                    </form>

                                </form>
                            </div>
                        </div>

                        <br>
                    </div>
                    <?php
              }
            }


?>
                </div>
            </div>
        </div>



        <!------------------------------------------------ this is for the vivo -------------------------------------->
        <?php
        $s2 = "SELECT * FROM product where u='vivo'";
        $run =mysqli_query($con,$s2);
?>
        <div class="services">
            <div class="container content-section w3-animate-opacity d-none" id="vivo">
                <div class="row">
                    <?php
            if(mysqli_num_rows($run) > 0 ){
              while($f = mysqli_fetch_assoc($run)){
                ?>
                    <div class="col-md-4">
                        <div class="service-item">
                            <div class="down-content">
                                <br><img src="img/<?php echo $f['img']; ?>" alt="" style="height:200px;width:200px;">
                                <hr>
                                <form action="pmanage.php" method="POST">
                                    <p style="font-weight:bold;"><?php echo $f['name']; ?></p>

                                    <p>
                                    <div class="row">
                                        <div class="col-lg-3">
                                            <h4><sup>&#8377</sup><?php echo $f['prize']; ?></h4>
                                        </div>
                                        <div class="col-lg-9">
                                            <h6><del><?php echo $f['offer']; ?></del><?php echo $f['offr']; ?></h6>

                                        </div>
                                    </div>
                                    </p>
                                    <form action="pmanage.php" method="post">
                                        <div class="row">
                                            <div class="col-lg-6 col-6">
                                                <input type="submit" name="dt" class="filled-button" value="View Details">

                                            </div>
                                            <div class="col-lg-6 col-6">
                                                <input type="submit" name="si" class="filled-button" value="Add cart">
                                                <input type="hidden" name="dt11" value="<?php echo $f['qun']; ?>">
                                                <input type="hidden" name="dt1" value="<?php echo $f['name']; ?>">
                                                <input type="hidden" name="dt2" value="<?php echo $f['prize']; ?>">
                                                <input type="hidden" name="dt3" value="<?php echo $f['offer']; ?>">
                                                <input type="hidden" name="dt4" value="<?php echo $f['offr']; ?>">
                                                <input type="hidden" name="dt5" value="<?php echo $f['di']; ?>">
                                                <input type="hidden" name="dt6" value="<?php echo $f['img']; ?>">
                                                <input type="hidden" name="dt7" value="<?php echo $f['about']; ?>">
                                                <input type="hidden" name="dt8" value="<?php echo $f['mem']; ?>">
                                                <input type="hidden" name="dt9" value="<?php echo $f['inf']; ?>">
                                                <input type="hidden" name="dt10" value="<?php echo $f['tec']; ?>">
                                            </div>
                                        </div>
                                    </form>

                                </form>
                            </div>
                        </div>

                        <br>
                    </div>
                    <?php
              }
            }


?>
                </div>
            </div>
        </div>











        <!------------------------------------------------ this is for the REDMIN -------------------------------------->
        <?php
        $s3 = "SELECT * FROM product where u='red'";
        $run =mysqli_query($con,$s3);
?>
        <div class="services">
            <div class="container content-section w3-animate-opacity d-none" id="redmi">
                <div class="row">
                    <?php
            if(mysqli_num_rows($run) > 0 ){
              while($f = mysqli_fetch_assoc($run)){
                ?>
                    <div class="col-md-4">
                        <div class="service-item">
                            <div class="down-content">
                                <br><img src="img/<?php echo $f['img']; ?>" alt="" style="height:200px;width:200px;">
                                <hr>
                                <form action="pmanage.php" method="POST">
                                    <p style="font-weight:bold;"><?php echo $f['name']; ?></p>

                                    <p>
                                    <div class="row">
                                        <div class="col-lg-3">
                                            <h4><sup>&#8377</sup><?php echo $f['prize']; ?></h4>
                                        </div>
                                        <div class="col-lg-9">
                                            <h6><del><?php echo $f['offer']; ?></del><?php echo $f['offr']; ?></h6>
                                        </div>
                                    </div>
                                    </p>
                                    <div class="row">
                                        <div class="col-lg-6 col-6">
                                            <form action="pmanage.php" method="post">
                                                <input type="submit" name="dt" class="filled-button" value="View Details">
                                                <input type="hidden" name="dt1" value="<?php echo $f['name']; ?>">
                                                <input type="hidden" name="dt2" value="<?php echo $f['prize']; ?>">
                                                <input type="hidden" name="dt3" value="<?php echo $f['offer']; ?>">
                                                <input type="hidden" name="dt4" value="<?php echo $f['offr']; ?>">
                                                <input type="hidden" name="dt5" value="<?php echo $f['di']; ?>">
                                                <input type="hidden" name="dt6" value="<?php echo $f['img']; ?>">
                                                <input type="hidden" name="dt7" value="<?php echo $f['about']; ?>">
                                                <input type="hidden" name="dt8" value="<?php echo $f['mem']; ?>">
                                                <input type="hidden" name="dt9" value="<?php echo $f['inf']; ?>">
                                                <input type="hidden" name="dt10" value="<?php echo $f['tec']; ?>">

                                            </form>
                                        </div>
                                        <div class="col-lg-6 col-6">
                                            <input type="submit" name="si" class="filled-button" value="Add cart">
                                            <input type="hidden" name="dt11" value="<?php echo $f['qun']; ?>">
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>

                        <br>
                    </div>
                    <?php
              }
            }


?>
                </div>
            </div>
        </div>










        <!------------------------------------------------ this is for the OPPO -------------------------------------->
        <?php
        $s4 = "SELECT * FROM product where u='op'";
        $run =mysqli_query($con,$s4);
?>
        <div class="services">
            <div class="container content-section w3-animate-opacity d-none" id="oppo">
                <div class="row">
                    <?php
            if(mysqli_num_rows($run) > 0 ){
              while($f = mysqli_fetch_assoc($run)){
                ?>
                    <div class="col-md-4">
                        <div class="service-item">
                            <div class="down-content">
                                <br><img src="img/<?php echo $f['img']; ?>" alt="" style="height:200px;width:200px;">
                                <hr>
                                <form action="pmanage.php" method="POST">
                                    <p style="font-weight:bold;"><?php echo $f['name']; ?></p>

                                    <p>
                                    <div class="row">
                                        <div class="col-lg-3">
                                            <h4><sup>&#8377</sup><?php echo $f['prize']; ?></h4>
                                        </div>
                                        <div class="col-lg-9">
                                            <h6><del><?php echo $f['offer']; ?></del><?php echo $f['offr']; ?></h6>

                                        </div>
                                    </div>
                                    </p>
                                    <div class="row">
                                        <div class="col-lg-6 col-6">
                                            <form action="pmanage.php" method="post">
                                                <input type="submit" name="dt" class="filled-button" value="View Details">
                                                <input type="hidden" name="dt1" value="<?php echo $f['name']; ?>">
                                                <input type="hidden" name="dt2" value="<?php echo $f['prize']; ?>">
                                                <input type="hidden" name="dt3" value="<?php echo $f['offer']; ?>">
                                                <input type="hidden" name="dt4" value="<?php echo $f['offr']; ?>">
                                                <input type="hidden" name="dt5" value="<?php echo $f['di']; ?>">
                                                <input type="hidden" name="dt6" value="<?php echo $f['img']; ?>">
                                                <input type="hidden" name="dt7" value="<?php echo $f['about']; ?>">
                                                <input type="hidden" name="dt8" value="<?php echo $f['mem']; ?>">
                                                <input type="hidden" name="dt9" value="<?php echo $f['inf']; ?>">
                                                <input type="hidden" name="dt10" value="<?php echo $f['tec']; ?>">

                                            </form>
                                        </div>
                                        <div class="col-lg-6 col-6">
                                            <input type="submit" name="si" class="filled-button" value="Add cart">
                                            <input type="hidden" name="dt11" value="<?php echo $f['qun']; ?>">
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>

                        <br>
                    </div>
                    <?php
              }
            }


?>
                </div>
            </div>
        </div>





        <!------------------------------------------------ this is for the OPPO -------------------------------------->
        <?php
        $s5 = "SELECT * FROM product where u='rl'";
        $run =mysqli_query($con,$s5);
?>
        <div class="services">
            <div class="container content-section w3-animate-opacity d-none" id="realme">
                <div class="row">
                    <?php
            if(mysqli_num_rows($run) > 0 ){
              while($f = mysqli_fetch_assoc($run)){
                ?>
                    <div class="col-md-4">
                        <div class="service-item">
                            <div class="down-content">
                                <br><img src="img/<?php echo $f['img']; ?>" alt="" style="height:200px;width:200px;">
                                <hr>
                                <form action="pmanage.php" method="POST">
                                    <p style="font-weight:bold;"><?php echo $f['name']; ?></p>

                                    <p>
                                    <div class="row">
                                        <div class="col-lg-3">
                                            <h4><sup>&#8377</sup><?php echo $f['prize']; ?></h4>
                                        </div>
                                        <div class="col-lg-9">
                                            <h6><del><?php echo $f['offer']; ?></del><?php echo $f['offr']; ?></h6>

                                        </div>
                                    </div>
                                    </p>
                                    <div class="row">
                                        <div class="col-lg-6 col-6">
                                            <form action="pmanage.php" method="post">
                                                <input type="submit" name="dt" class="filled-button" value="View Details">
                                                <input type="hidden" name="dt1" value="<?php echo $f['name']; ?>">
                                                <input type="hidden" name="dt2" value="<?php echo $f['prize']; ?>">
                                                <input type="hidden" name="dt3" value="<?php echo $f['offer']; ?>">
                                                <input type="hidden" name="dt4" value="<?php echo $f['offr']; ?>">
                                                <input type="hidden" name="dt5" value="<?php echo $f['di']; ?>">
                                                <input type="hidden" name="dt6" value="<?php echo $f['img']; ?>">
                                                <input type="hidden" name="dt7" value="<?php echo $f['about']; ?>">
                                                <input type="hidden" name="dt8" value="<?php echo $f['mem']; ?>">
                                                <input type="hidden" name="dt9" value="<?php echo $f['inf']; ?>">
                                                <input type="hidden" name="dt10" value="<?php echo $f['tec']; ?>">

                                            </form>
                                        </div>
                                        <div class="col-lg-6 col-6">
                                            <input type="submit" name="si" class="filled-button" value="Add cart">
                                            <input type="hidden" name="dt11" value="<?php echo $f['qun']; ?>">
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>

                        <br>
                    </div>
                    <?php
              }
            }


?>
                </div>
            </div>
        </div>






























    </div><!-- this is end of the content part  -->




    <script>
    $(document).ready(function() {
        $(".menu-item").click(function() {
            var target = $(this).data("target");
            $(".content-section").addClass("d-none"); // Hide all sections
            $("#" + target).removeClass("d-none"); // Show selected section
        });
    });
    </script>
    <?php
    include("foot.php");
    ?>



</body>

</html>