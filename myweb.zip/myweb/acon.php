<?php
include('ses.php');
if(isset($_POST['sc'])){
    $h = $_POST['ec'];

    echo $h."<br><br>";
    echo $m;

}
?>