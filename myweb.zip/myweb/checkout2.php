<?php
include('ses.php');

if (isset($_SESSION['r']['e'])) {
    $email = $_SESSION['r']['e'];
    $sel = mysqli_query($con, "SELECT dt FROM orderp WHERE email='$email' AND stat='complete'");
    $rw = mysqli_fetch_assoc($sel);
    $orderCompleteTime = strtotime($rw['dt']);
    // $receiveTime = date("Y-m-d H:i:s", $orderCompleteTime +  24 * 60 * 60);
    $receiveTime = date("Y-m-d H:i:s", $orderCompleteTime +  10);

    $query = "UPDATE orderp SET stat='recive',dt='$receiveTime ' WHERE email='$email' AND stat='complete'";
    if (mysqli_query($con, $query)) {
        $dtkl = date("d F Y");
        $dtkl1 =  date("l");
        setcookie("orderrecive","<h4>You recived Your Order On (<strong class='badge badge-success'>$dtkl1 - $dtkl</strong>) Chekout Your Updated Statuse Of Order</h4>",time()+5);
        echo "
        <script>
        window.location.href ='user.php';
        </script>
        ";
    } else {
        echo "
        <script>
        alert('Somthing Went Wrong');
        window.location.href ='user.php';
        </script>
        ";
    }
} else {
    echo "
    <script>
    alert('please login to your accont');
    window.location.href ='log.php';
    </script>
    ";
}
?>
