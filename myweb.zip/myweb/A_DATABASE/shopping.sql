-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2025 at 12:18 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopping`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`) VALUES
(1, 'KISHAN', 'admin@gmail.com', 'Admin@1kk'),
(4, 'kishan1', 'admin1@gmail.com', 'Admin@1k'),
(5, 'kishan', 'admink@gmail.com', 'Admin@1k');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `ques` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `ques`) VALUES
(1, 'rohit', 'kishansadhusadhu69@gmail.com', 'wf;mwf');

-- --------------------------------------------------------

--
-- Table structure for table `orderp`
--

CREATE TABLE `orderp` (
  `id` int(11) NOT NULL,
  `img` varchar(700) NOT NULL,
  `name` varchar(100) NOT NULL,
  `prize` varchar(20) NOT NULL,
  `qun` varchar(20) NOT NULL,
  `tot` varchar(30) NOT NULL,
  `stat` varchar(10) NOT NULL,
  `method` varchar(20) NOT NULL,
  `adr` mediumtext NOT NULL,
  `email` varchar(500) NOT NULL,
  `dt` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderp`
--

INSERT INTO `orderp` (`id`, `img`, `name`, `prize`, `qun`, `tot`, `stat`, `method`, `adr`, `email`, `dt`) VALUES
(1, 's1.png', 'Samsung Galaxy S25 5G', '70,000', '4', '280000', 'recive', 'Pay Now', '                                    rajkot                                ', 'kishansadhusadhu6@gmail.com', '2025-04-28 17:03:24 '),
(2, 's1.png', 'Samsung Galaxy S25 5G', '70,000', '1', '70,000', 'recive', 'Case On Delivary', '                                                                            rajkot                                                                        ', 'kishansadhusadhu6@gmail.com', '2025-04-28 17:09:55 '),
(4, 's1.png', 'Samsung Galaxy S25 5G', '70,000', '1', '70,000', 'recive', 'Case On Delivary', '                                                                            rajkot                                                                        ', 'kishansadhusadhu69@gmail.com', '2025-05-02 09:44:40 '),
(6, 's1.png', 'Samsung Galaxy S25 5G', '70,000', '1', '70,000', 'recive', 'Case On Delivary', '                                                                            rajkot                                                                        ', 'kishansadhusadhu69@gmail.com', '2025-05-02 10:17:40 '),
(7, 's1.png', 'Samsung Galaxy S25 5G', '70,000', '1', '70,000', 'recive', 'Case On Delivary', '                                                                            rajkot                                                                        ', 'kishansadhusadhu69@gmail.com', '2025-05-02 15:17:27 ');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `img` varchar(700) NOT NULL,
  `name` varchar(200) NOT NULL,
  `prize` varchar(200) NOT NULL,
  `qun` varchar(200) NOT NULL,
  `tot` varchar(200) NOT NULL,
  `stat` varchar(200) NOT NULL,
  `method` varchar(200) NOT NULL,
  `adr` mediumtext NOT NULL,
  `email` varchar(100) NOT NULL,
  `dt` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `img` varchar(1000) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `prize` varchar(100) NOT NULL,
  `qun` int(100) NOT NULL,
  `offer` varchar(100) NOT NULL,
  `offr` varchar(100) NOT NULL,
  `di` mediumtext NOT NULL,
  `about` mediumtext NOT NULL,
  `mem` varchar(100) NOT NULL,
  `inf` varchar(100) NOT NULL,
  `tec` varchar(100) NOT NULL,
  `u` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `img`, `name`, `prize`, `qun`, `offer`, `offr`, `di`, `about`, `mem`, `inf`, `tec`, `u`) VALUES
(1, 's1.png', 'Samsung Galaxy S25 5G', '70,000', 42, '25000', '(29% off)', 'Samsung Galaxy S25 5G AI Smartphone (Icyblue, 12GB RAM, 256GB Storage), 50MP Camera with Galaxy AI', '                                                                                                                                                                                                                                                                                                                                                                                                                                                                            \r\nAbout this item\r\nIntroducing Galaxy S25, your true AI companion. Powered by the next chapter of Galaxy AI with multi-modality, and the most advanced Galaxy fundamentals, Galaxy S25 naturally adapts to you: learning your patterns, anticipating your needs, and connecting your world. Be it helping in getting multiple tasks done by performing seamless actions across apps or offering personalized insights to get you through your day with Now Brief.\r\n<hr>\r\n\r\nWith Galaxy S25, easily get rid of unwanted background noise from your videos and make them share-worthy with Audio Eraser.\r\n<hr>\r\nGalaxy S25 lets you capture epic portraits every single time thanks to its enhanced object-aware engine that can adapt to various lighting environments. It also offers unrivaled Nightography video with more precise noise removal. Say goodbye to grainy night footage.\r\n\r\n<hr>\r\nEnjoy multi-tasking and epic performance with the most powerful processor customized for Galaxy - Snapdragon 8 Elite.\r\n\r\n<hr>\r\n\r\nFramed in Armor Aluminum and strengthened with Corning Gorilla Glass Victus 2, stay worry free with Galaxy S25.\r\n\r\n\r\n                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ', '256 GB + 8 GB RAM', 'touch screen                       ', '5G', 'sam'),
(2, 's2.png', 'Samsung Galaxy S25 Ultra 5G', '75,000', 50, '25,999', '(29% off)', 'Samsung Galaxy S25 Ultra 5G AI Smartphone (Titanium Gray, 12GB RAM, 256GB Storage), 200MP Camera, S Pen Included, Long Battery Life', 'Meet Galaxy S25 Ultra, your true AI companion. Powered by the next chapter of Galaxy AI with multi-modality, and the most advanced Galaxy fundamentals, Galaxy S25 Ultra naturally adapts to you: learning your patterns, anticipating your needs, and connecting your world seamlessly. With Now Brief, it also offers you personalized insights to get you through your day.\r\nNeed to do multiple tasks? Galaxy S25 Ultra performs seamless actions across apps and will get them done for you instantly.\r\nLive to create? Galaxy S25 Ultra’s cutting-edge camera and visual creation tools offer you the best camera and editing experience, thanks to its most advanced AI ProVisual Engine. Go from Wide to Tele and even Ultra Wide and get the sharpest details.\r\nLove gaming? Enjoy hyper-realistic, ultra-smooth gameplay with the most powerful processor, customized for Galaxy - Snapdragon 8 Elite.\r\nAll this shielded in an Ultra-strong titanium frame with Galaxy’s toughest glass ever, Corning Gorilla Armor 2.', '256 GB', 'touch screen stylus pen', '5G', 'sam'),
(3, 's3.png', 'Samsung Galaxy M05 ', '7,498', 50, '8,999', '(17%off)', 'Samsung Galaxy M05 (Mint Green, 4GB RAM, 64 GB Storage) | 50MP Dual Camera | Bigger 6.7\" HD+ Display | 5000mAh Battery | 25W Fast Charging | 2 Gen OS Upgrade & 4 Year Security Update | Without Charger', 'Captivating viewing experience on bigger 6.7\" Display with HD+ resolution (720*1600 Pixels) | 20:9 Aspect Ratio\r\n50 MP High-resolution Dual Camera (f/1.8) for sharp and detailed pictures| 8 MP Front camera (f/2.0) for stunning selfie | FHD (1920*1080) Video resolution\r\nGet a massive 5000mAh with C-Type 25 W Fast Charging\r\nLatest Android 14 Operating System having One UI Core 6.0 platform | 2GHz, 1.8GHz Clock Speed with Octa-Core Processor | 8 GB RAM with RAM Plus | Expandable Memory upto 1 TB\r\nGet upto 2 Generations of AndroidOS Upgrades & 4 Years of Security Updates with Samsung Galaxy M05.', '64 GB', 'touch screen', '4G', 'sam'),
(4, 's4.png', 'Samsung Galaxy M15', '12,999', 50, '16,999', '(24%)', 'Samsung Galaxy M15 5G Prime Edition (Blue Topaz,6GB RAM,128GB Storage) | Super AMOLED Display| 50MP Triple Cam| 6000mAh Battery| MediaTek Dimensity 6100+ | 4 Gen. OS Upgrade & 5 Year Security Update', 'DISPLAY - 16.39 Centimeters (6.5\"Inch) Super AMOLED Display with 19.5:9 Aspect Ratio, FHD+ Resolution with 1080 x 2340 Pixels , 399 PPI with 16M Colors and 90Hz Refresh Rate\r\nCAMERA - 50MP (F1.8) Main Wide Angle Camera + 5MP (F2.2) Ultra Wide Angle Camera + 2MP (F2.4) Macro Angle Camera | 13MP (F2.0) Front Camera | Video Maximum Resolution of Full HD (1920 x 1080) @30fps\r\nINTERFACE & PROCESSOR - Latest Android 14 Operating System having One UI 6.1 platform with MediaTek Dimensity 6100+ Processor | 2.2GHz, 2GHz Clock Speed with Octa-Core Processor\r\nBATTERY - Get a massive 6000mAh Lithium-ion Battery (Non-Removable) with C-Type Super Fast Charging (25W Charging Support)\r\nOS UPDATES & SECURITY - Get upto 4 Generations of AndroidOS Upgrades & 5 Years of Security Updates with Samsung Galaxy M15. Includes 1 Year Manufacturer Warranty for Device and 6 Months for In-Box Accessories.', '128 GB', '‎Touchscreen', '5G', 'sam'),
(5, 's5.png', 'Samsung Galaxy A05', '7,972', 50, '14,999', '(47%off)', 'Samsung Galaxy A05 (Silver, 6GB, 128GB Storage) | 50 MP Main Camera | Upto 12GB RAM with RAM Plus | MediaTek Helio G85 | 5000 mAh Battery', 'DISPLAY - 17.13 Centimeters (6.7\"Inch) PLS LCD Display, HD+ Resolution with 720 x 1600 Pixels , 260 PPI with 16M Colours and 60Hz Refresh Rate\r\nCAMERA - 50MP (F1.8) Main Camera with Auto Focus + 2MP (F2.4) Depth Camera | 8MP (F2.0) Front Camera\r\nINTERFACE & PROCESSOR - Android 13, v13.0 Operating System having One UI Core 5.1 platform with MediaTek Helio G85 Processor | 2GHz, 1.8GHz 12nm Octa-Core Processor\r\nBATTERY - Get a massive 5000mAh Lithium-ion Battery (Non-Removable) with C-Type Super Fast Charging (25W Charging Support)\r\nOS UPDATES & SECURITY - Get upto 2 Generations of AndroidOS Upgrades & 4 Years of Security Updates with Samsung Galaxy A05. Includes 1 Year Manufacturer Warranty for Device and 6 Months for In-Box Accessories.', '128BG', 'TOUCH SCREEN', '4G', ''),
(6, 's6.png', 'Samsung Galaxy M35', '16,999', 50, '24,499', '(31% off)', 'Samsung Galaxy M35 5G (Daybreak Blue,6GB RAM,128GB Storage)| Corning Gorilla Glass Victus+| AnTuTu Score 595K+ | Vapour Cooling Chamber | 6000mAh Battery | 120Hz Super AMOLED Display| Without Charger', 'Monster Durability & Display : Corning Gorilla Glass Victus+, 16.83 Centimeters (6.6\"Inch) Super AMOLED Display, FHD+ Resolution with 1080 x 2340 Pixels and 120Hz Refresh Rate\r\nMonster Processor - Exynos 1380 Processor with Vapour Cooling Chamber | Latest Android 14 Operating System having One UI 6.1 platform | 2.4GHz, 2GHz Clock Speed with Octa-Core Processor\r\nMonster Convenience & Security - Samsung Wallet with Tap & Pay | Knox Security | Get upto 4 Generations of AndroidOS Upgrades & 5 Years of Security Updates\r\nMonster Camera - 50MP (F1.8) Main Wide Angle Camera + 8MP (F2.2) Ultra Wide Angle Camera + 2MP (F2.4) Macro Angle Camera | OIS & Nightography | 13MP (F2.2) Selfie Camera | Video Maximum Resolution of Ultra HD (3840 x 2160) @30fps\r\nMonster Battery - Get a massive 6000mAh Lithium-ion Battery (Non-Removable) with C-Type Fast Charging (25W Charging Support)', '128GB+6GB RAM', '	\r\ntouch screen', '	\r\nAndroid 14+56', 'sam'),
(7, 'v1.png', 'Vivo T3x 5G', '14,199', 50, '18,999', '(25%off)', 'Vivo T3x 5G (Crimson Bliss, 128 GB) (6 GB RAM)', '6 GB RAM | 128 GB ROM | Expandable Upto 1 TB\r\n17.07 cm (6.72 inch) Full HD+ Display\r\n50MP + 2MP | 8MP Front Camera\r\n6000 mAh Battery\r\n6 Gen 1 Processor', '129GB', 'water resistant', '5G', 'vivo'),
(8, 'v2.png', 'Vivo T3x 5G', '13,699', 50, '18,999', '(28%off)', 'Vivo T3x 5G (Celestial Green, 128 GB) (6 GB RAM)', '6 GB RAM | 128 GB ROM | Expandable Upto 1 TB\r\n17.07 cm (6.72 inch) Full HD+ Display\r\n50MP + 2MP | 8MP Front Camera\r\n6000 mAh Battery\r\n6 Gen 1 Processor', '128GB', 'touch screen, touch screen', '4G', 'vivo'),
(9, 'v3.png', 'vivo Y28e 5G', '10,999', 50, '15,999', '(31% off)', 'vivo Y28e 5G (Vintage Red, 4GB RAM, 128GB Storage) with No Cost EMI/Additional Exchange Offers | Without Charger', 'Camera: Dual 13MP+0.08MP Rear Camera | 5MP Selfie Camera\r\nDisplay: 16.6624 cm (6.56\" inch) LCD Capacitive multi-touch display 90Hz refresh rate, 269 ppi\r\nMemory & SIM: 4GB RAM | 128GB internal memory; LPDDR4X | eMMC 5.1\r\nBattery & charging: 5000 mAh with 15W charging\r\nSide-mounted capacitive fingerprint sensor\r\nProcessor: Dimensity 6300 5G processor\r\nRear camera: Night, Portrait, Photo, Video, Pano, Documents, Slo-mo, Time-lapse, Pro, Live Photo Front camera: Night, Portrait, Photo, Video, Live Photo\r\nThis product is rated as IP54 for splash, water, and dust resistance under IEC standard 60529 and was tested under controlled laboratory conditions. The resistance to splashes, water and dust is not permanent and may be reduced due to daily use.', '64GB', 'touch screen', '5G', 'vivo'),
(10, 'v4.png', 'Vivo Y29 5G', '15,499', 50, '17,999', '(14% off)', 'Vivo Y29 5G (Glacier Blue, 6GB RAM, 128GB Storage) with No Cost EMI/Additional Exchange Offers', '50 MP + 0.08 MP Rear Camera | 8 MP Selfie Camera\r\n16.96 cm (6.67\" inch)\r\nMemory & SIM: 6GB RAM | 128GB internal memory\r\n44W fast charging with 5380 mAh battery', '64+6GB RAM', 'touch screen', '5G', 'vivo'),
(11, 'v5.png', 'Vivo V40e 5G ', '28,999', 50, '35,999', '(19% off)', 'Vivo V40e 5G (Royal Bronze, 8GB RAM, 256GB Storage) with No Cost EMI/Additional Exchange Offers', '50 MP Sony IMX882 OISMain Camera: OIS supported; f/1.79; FOV 79°; 5P lens + 8 MP Ultra Wide-Angle Camera: f/2.2; FOV 116°; 5P lens Rear Camera | 50 MP AF Ultra Wide-Angle Selfie Camera: AF supported; f/2.0; FOV 92°; 5P lens Selfie Camera\r\n17.206 cm (6.77\" inch) + AMOLED display\r\nMemory & SIM: 8GB RAM | 256GB internal memory\r\n80W fast charging with 5500 mAh battery', '256GB + 8GB RAM', 'touch screen', '5G', 'vivo'),
(12, 'v6.png', 'Vivo Y27', '11,000', 50, '18,999', '(42%off)', 'Vivo Y27 (Garden Green, 6GB RAM, 128GB Storage) with No Cost EMI/Additional Exchange Offers', 'Camera: Dual 50MP+2MP Rear Camera | 8MP Selfie Camera with rear flash, night mode\r\nDisplay: 16.86 cm (6.64 inch) FHD+ LCD Sunlight Display for enhanced outdoor display\r\nMemory & SIM: 6 GB RAM | 128 GB internal memory with next Gen extendede RAM technology 3.0,\r\nBattery & charging: 44W FlashCharge with 5000 mAh battery\r\nSecurity: Supports unlocking with Face Access and Side-Mounted Fingerprint Sensor, faster and more convenient.\r\nProcessor: Helio G85\r\nCamera features: Photo, Night, Portrait, Video, 50MP, Panorama, Live Photo, Slo-mo, Time-Lapse, Pro, Documents', '128GB + 6GB RAM', 'touch screen', '5G', 'vivo'),
(13, 'r1.png', 'Redmi 14C 5G', '9,999', 49, '12,999', '(23% off)', 'Redmi 14C 5G (Stargaze Black, 4GB RAM, 64GB Storage) | Superfast 4nm Snapdragon 4 Gen 2 | 120Hz 17.47cm (6.88”) Display | 5160mAh Battery | 50MP Dual Camera | Premium Starlight Design', 'High performance - Snapdragon 4 Gen 2 5G Processor | Large 17.47cm 120Hz Display | Upto 8GB RAM including 4GB Virtual RAM |64GB Storage | Fast Side fingerprint sensor\r\nDisplay: Large 17.47 cm 120Hz Refresh Rate display | 600nits peak brightness | 240Hz Touch sampling Rate | TUV triple certified eye care protection\r\nCamera: 50MP Dual camera | 5MP Front camera\r\n5160mAh(typ) battery with 18W fast charging support and 33W charger in-box with USB Type-C\r\nExpandable Storage to upto 1TB with Dedicated MicroSD card Slot | 3.5mm headphone jack | Android 14 | Side fingerprint sensor', '64GB + 4GB RAM', 'touch screen', '4G', 'red'),
(14, 'r2.png', 'Redmi A4 5G', '8,299', 50, '10,999', '(25%off)', 'Redmi A4 5G (Starry Black, 4GB RAM, 64GB Storage) | Global Debut SD 4s Gen 2 | Segment Largest 6.88in 120Hz | 50MP Dual Camera | 18W Fast Charging', 'High performance - Snapdragon 4s Gen 2 5G Processor | Large 17.47cm 120Hz Display | Upto 8GB RAM including 4GB Virtual RAM |64GB Storage | Fast Side fingerprint sensor\r\nDisplay: Large 17.47 cm 120Hz Refresh Rate display | 600nits peak brightness | 240Hz Touch sampling Rate | TUV triple certified eye care protection\r\nCamera: 50MP Dual camera | 5MP Front camera\r\n5160mAh(typ) battery with 18W fast charging support and 33W charger in-box with USB Type-C\r\nExpandable Storage to upto 1TB with Dedicated MicroSD card Slot | 3.5mm headphone jack | Android 14 | Side fingerprint sensor\r\nSupports 4G+ 5G SA network | Note : 5G NSA not supported | Please check availability of Standalone 5G with your networks provider', '64gb + 4GB RAM', 'touch screen', '4G', 'red'),
(15, 'r3.png', 'Redmi A4 5G', '8,999', 50, '11,999', '(25%off)', 'Redmi A4 5G (Sparkle Purple, 4GB RAM, 128GB Storage) | Global Debut SD 4s Gen 2 | Segment Largest 6.88in 120Hz | 50MP Dual Camera | 18W Fast Charging', 'High performance - Snapdragon 4s Gen 2 5G Processor | Large 17.47cm 120Hz Display | Upto 8GB RAM including 4GB Virtual RAM |128GB Storage | Fast Side fingerprint sensor\r\nDisplay: Large 17.47 cm 120Hz Refresh Rate display | 600nits peak brightness | 240Hz Touch sampling Rate | TUV triple certified eye care protection\r\nCamera: 50MP Dual camera | 5MP Front camera\r\n5160mAh(typ) battery with 18W fast charging support and 33W charger in-box with USB Type-C\r\nExpandable Storage to upto 1TB with Dedicated MicroSD card Slot | 3.5mm headphone jack | Android 14 | Side fingerprint sensor\r\nSupports 4G+ 5G SA network | Note : 5G NSA not supported | Please check availability of Standalone 5G with your networks provider', '128GB + 4GB RAM', 'touch screen', '5G', 'red'),
(16, 'r4.png', 'edmi 13 5G', '13,999', 50, '19,999', '(30%off)', 'Redmi 13 5G, Hawaiian Blue, 8GB+128GB | India Debut SD 4 Gen 2 AE | 108MP Pro Grade Camera | 6.79in Largest Display in Segment', 'Display: Large 17.24cm FHD+ 120Hz AdaptiveSync display with Corning Gorilla Glass 3 Protection, TÜV Rheinland low blue light, TÜV flicker-free, TÜV Circadian Friendly, Wet finger touch display\r\nProcessor: Qualcomm Snapdragon 4 Gen2 Accelerated Edition Octa-core processor for high performance ; Up to 2.3GHz; Android 14 with Xiaomi HyperOS, Upto 16GB RAM including 8GB Virtual RAM\r\nCamera: 108MP f/1.75 Dual camera with 3X In-Sensor Zoom, classic film filters, Portrait, Night Mode,HDR, 108MP mode, Time-lapse, Google lens, Macro Video | 13MP Selfie camera\r\nBattery: 5030 mAh large battery with 33W fast charger in-box and Type-C connectivity\r\nSide Fingerprint Sensor, 3.5mm Jack, IR Blaster, IP53', '128GB + 8GB  RAM', 'touch screen', '5G', 'red'),
(17, 'r5.png', 'Redmi 13 5G', '13,998', 50, '19,999', '(30%off)', 'Redmi 13 5G, Black Diamond, 8GB+128GB | India Debut SD 4 Gen 2 AE | 108MP Pro Grade Camera | 6.79in Largest Display in Segment', 'Display: Large 17.24cm FHD+ 120Hz AdaptiveSync display with Corning Gorilla Glass 3 Protection, TÜV Rheinland low blue light, TÜV flicker-free, TÜV Circadian Friendly, Wet finger touch display\r\nProcessor: Qualcomm Snapdragon 4 Gen2 Accelerated Edition Octa-core processor for high performance ; Up to 2.3GHz; Android 14 with Xiaomi HyperOS, Upto 16GB RAM including 8GB Virtual RAM\r\nCamera: 108MP f/1.75 Dual camera with 3X In-Sensor Zoom, classic film filters, Portrait, Night Mode,HDR, 108MP mode, Time-lapse, Google lens, Macro Video | 13MP Selfie camera\r\nBattery: 5030 mAh large battery with 33W fast charger in-box and Type-C connectivity\r\nSide Fingerprint Sensor, 3.5mm Jack, IR Blaster, IP53', '64GB + 8GB RAM', 'touch screen', '5G', 'red'),
(18, 'r6.png', 'Redmi Note 13', '15,499', 50, '10,999', '(20%off)', 'Redmi Note 13 5G (Chromatic Purple, 8GB RAM, 256GB Storage)', 'Display: 6.67\" FHD+ pOLED (1080x2400) Ultra-narrow bezels Display with 120Hz Refresh rate; 1000nits peak brightness; Corning Gorilla Glass 5 Display Protection\r\nProcessor:Mediatek Dimensity 6080 6nm Octa-core 5G processor for high performance ; Up to 2.4GHz; Upto 16GB RAM including 8GB Virtual RAM\r\nCamera: 108MP 3X in-sensor zoom AI Triple Camera with 8MP Ultra Wide sensor and 2MP Macro camera| 16MP Front camera\r\nBattery: 5000 mAh large battery with 33W fast charger in-box and Type-C connectivity\r\nMemory, Storage & SIM: 8GB RAM | 128GB UFS 2.2 | Dual SIM (nano+nano) 5G', '256GB + 8GB RAM', 'touch screen', '5G', 'red'),
(19, 'o1.png', 'Oppo K12x', '12,745', 50, '16,999', '(25%off)', 'Oppo K12x 5G with 45W SUPERVOOC Charger in-The-Box (Breeze Blue, 128 GB) (6 GB RAM)', '6 GB RAM | 128 GB ROM | Expandable Upto 1 TB\r\n16.94 cm (6.67 inch) HD Display\r\n32MP + 2MP | 8MP Front Camera\r\n5100 mAh Battery\r\nDimensity 6300 Processor', '128GB + 6GB RAM', 'touch screen', '5G', 'op'),
(20, 'o2.png', 'Oppo K12x 5G', '12,800', 50, '16,999', '(25%off)', 'Oppo K12x 5G with 45W SUPERVOOC Charger in-The-Box (Midnight Voilet, 128 GB) (6 GB RAM)', '4 GB RAM | 128 GB ROM | Expandable Upto 1 TB\r\n16.94 cm (6.67 inch) HD Display\r\n32MP + 2MP | 8MP Front Camera\r\n5100 mAh Battery\r\nDimensity 6300 Processor', '128GB + 4GB RAM', 'touch screen', '4G', 'op'),
(21, 'o3.png', 'OPPO F27 Pro', '27,999', 50, '54,999', '(20%off)', 'OPPO F27 Pro+ 5G (Midnight Navy, 8GB RAM, 256GB Storage) | 6.7\" FHD+ AMOLED Toughest 3D Curved Display|64MP AI Featured Camera|IP69 | 67W SUPERVOOC| with No Cost EMI/Additional Exchange Offers', 'DISPLAY : 17.02cm (6.7\"Inch) AMOLED 3D Curved Display with Screen-to-body ratio: 93% .FHD+ Resolution with 2412×1080 Pixels , with 1Billion Colours and 120Hz Refresh Rate.\r\nCAMERA : Dual Ultra-Clear Camera 64MP Main Camera + 2MP Portrait camera |8MP Front Selfie Camera| AI Portrait Retouching |AI Eraser|AI Smart Image Matting features\r\nMEMORY STORAGE,SIM & PROCESSOR : 8 GB RAM|256 GB ROM | Dual 5G Sim Slot |Latest Android 14 Operating System and ColorOS 14.0 System Platform with MediaTek Dimensity 7050.\r\nFAST CHARGING & BATTERY : 67W SuperVOOC charging enable full charging in 44Mins .It have 5000mAh durable long Battery .\r\nTOUGHEST 3D CURVED SCREEN & PREMIUM DESIGN :All-Round Armor Impact Resistant Structure with Screen Protected by corning gorilla Glass Victus 2.Cosmos Ring design has been adopted to showcase a classic style of beauty featuring inclusiveness and orderliness. The elegant circular panel looks unique and eye-catching.Premium back leather design with stain resistance', '256GB + 8GB RAM', 'touch screen', '5G', 'op'),
(22, 'o4.png', 'OPPO A3 5G ', '14,999', 50, '19,999', '(25%off)', 'OPPO A3 5G (Nebula Red, 6GB RAM, 128GB Storage)', 'DISPLAY :16.94 cm (6.67\"Inch) HD+ LCD 120Hz Ultra Bright Display to greatly improve the smoothness of screen touches ,with Screen-to-body ratio of 89.9% for better viewing experience.\r\nCAMERA : Ultra-Clear Camera 50MP Rear camera |5MP Front Selfie Camera| AI Portrait Retouching |With the Dual-View Video on, the front and rear cameras can record videos at the same time, which is a new interesting form of video shooting.\r\nMEMORY, STORAGE,SIM & PROCESSOR : 6GB RAM|128 GB ROM | Dual 5G Sim Slot |Latest Android 14 Operating System and ColorOS 14.0 System Platform with MediaTek Dimensity 6300.\r\nMEMORY, STORAGE,SIM & PROCESSOR : 6GB RAM|128 GB ROM | Dual 5G Sim Slot |Latest Android 14 Operating System and ColorOS 14.0 System Platform with MediaTek Dimensity 6300.\r\nPREMIUM DESIGN & MILITARY-GRADE SHOCK RESISTANCE : It has Straight-corner bezel design, with chamfering on back cover edges to ensure a comfortable grip.The 2.5D curved screen ensures smoother slides from the screen to the edges, and also feel more durable and drop-resistant than the conventional curved screen.The screen uses double-tempering glass making it shock resistance device', '128GB + 6GB RAM', 'touch screen', '5G', 'op'),
(23, 'o5.png', 'OPPO F27 5G', '22,999', 50, '28,999', '(21%off)', 'OPPO F27 5G (Emerald Green, 8GB RAM, 256GB Storage) | 6.67\" FHD+ AMOLED Display|32MP Sony IMX615 Selfie Camera |AI Portrait Expert| 45W SUPERVOOC| with No Cost EMI/Additional Exchange Offers', 'PREMIUM DESIGN & HALO LIGHT EFFECT : Oppo F255G has flagship Cosmos ring Design having classic style of beauty featuring inclusiveness and orderliness. The elegant circular panel looks unique and eye-catching. , this design features a circle of breathing lighting in the Cosmos Ring that changes with sound, creating a most trendy, vigorous lighting effect. The breathing lighting effects are customisable for battery charging, incoming calls, notifications, music etc.\r\nDISPLAY :16.94 cm (6.67\"Inch) FHD+ Amoled 120Hz Ultra Bright Display to greatly improve the smoothness of screen touches ,with Screen-to-body ratio of 92.2% for better viewing experience.Clear for better eye protection, intelligent for smoother experience.\r\nULTRA-CLEAR CAMERA :50MP+2MP Ultra clear main camera| |32MP Sony IMX615 sensor Front Selfie Camera|Dual-View Video| AI Portrait Retouching |AI Eraser 2.0|AI Smart Image Matting 2.0|AI Studio.\r\nMEMORY STORAGE,SIM & PROCESSOR : 8GB RAM|256GB ROM | Dual SIM Dual Active 5G |Latest Android 14 Operating System and ColorOS 14.0 System Platform with MediaTek Dimensity 6300.\r\nFAST CHARGING & BATTERY : 45W SuperVOOC charging enable fast charging .It have 5000mAh durable long Battery .', '128GB + 8GB RAM', 'touch screen', '5G', 'op'),
(24, 'o6.png', 'Oppo A78 5G', '17,400', 50, '24,999', '(30%off)', 'Oppo A78 5G (Glowing Blue, 8GB RAM, 128 Storage) | 5000 mAh Battery with 33W SUPERVOOC Charger| 50MP AI Camera | 90Hz Refresh Rate | with No Cost EMI/Additional Exchange Offers', 'Big 5000 mAh Battery with 33W SUPERVOOC Charging\r\nSuper smooth experience with ColorOS 13 and 8GB RAM (+ RAM expansion up to 8GB) | 128GB ROM | Expandable Upto 1TB\r\nCrystal clear details with AI Camera setup 50MP + 2MP Rear Camera | 8MP Front Camera\r\nOPPO Glow Design with 6.56\" inch (16.66cm) 90Hz Color-Rich Display and Large Screen to Body ratio of 89.8%\r\nDual Ultra Linear Stereo Speakers with ROST and flagship hardware which produce an immersive sound effect', '256GB + 8GB RAM', 'touch screen', '5G', 'op'),
(25, 're1.png', 'realme NARZO N61', '7,498', 50, '8,999', '(17% off)', 'realme NARZO N61 (Voyage Blue,4GB RAM+64GB Storage) 90Hz Eye Comfort Display | IP54 Dust & Water Resistance | 48-Month Fluency | Charger in The Box', '\r\nBrand	realme\r\nOperating System	Android 14\r\nRAM Memory Installed Size	4 GB\r\nCPU Model	MediaTek Helio\r\nCPU Speed	1.8 GHz', '64GB + 4GB RAM', 'touch screen', '4G', 'rl'),
(26, 're2.png', 'realme NARZO 70x', '13,225', 50, '18,999', '(30%off)', 'realme NARZO 70x 5G (Ice Blue, 8GB RAM,128GB Storage)|120Hz Ultra Smooth Display|Dimensity 6100+ 6nm 5G|50MP AI Camera|45W Charger in The Box', '45W SUPERVOOC Charge provide Charges up to 50% in 31 mins. 5000mAh Massive Battery provide upto 26 days Standby or up to 35 hours Music;\r\nFully loaded 120Hz Ultra Smooth Display, Screen-to-body ratio: 91.40% Resolution ratio: FHD+ 1080 × 2400 PPI:391PPI,Touch Sampling Rate: 240Hz;\r\n7.69 mm Ultra-slim ,188g Light Body,The ultra-thin and lightweight body, combined with a width of 7.97cm, allows for comfortable single-handed grip even during extended periods of use; IP54 Dust and Water Resistance;\r\nMediaTek Dimensity 6100+ processor 5G, TÜV SÜD is a renowned certification body, and this product has been subjected to stringent professional testing to ensure a consistently smooth user experience for at least a period of 48 months. with the powerful 5G network connection Intelligent identification of LTE strong signal adjacent areas;\r\n50MP Primary Camera and Dual Stereo Speakers;', '256GB + 8GB RAM', 'touch screen', '5G', 'rl'),
(27, 're3.png', 'realme C65 5G', '11,152', 50, '15,999', '(30%off)', 'realme C65 5G (Feather Green, 128 GB) (6 GB RAM)', '6 GB RAM | 128 GB ROM | Expandable Upto 2 TB\r\n50MP + 2MP | 8MP Front Camera\r\n5000 mAh Battery', '128GB + 6GB RAM', 'touch screen', '4G', 'rl'),
(28, 're4.png', 'realme NARZO 70 Turbo', '16,999', 50, '19,999', '(15%off)', 'realme NARZO 70 Turbo 5G (Turbo Yellow,6GB RAM,128GB Storage) | Segment\'s Fastest Dimensity 7300 Energy 5G Chipset | Motorsports Inspired Design', 'Dimensity 7300 Energy 5G Chipset, Fastest chipset in this segment, dominate your games with an unprecedented 750000 AnTuTu score,AI BOOST 2.0,Turbo ahead with up to 40% smoother performance\r\nThe most sophisticated vapor cooling system in its class, bringing turbo speed designed to last with an advanced 9-layer cooling system and a massive cooling area of 6050mm , your phone will stay cool to the touch even when playing demanding games.\r\n92.65% screen-to-body ratio 120Hz Display bring your content to life, a display made with gamers in mind with a liquid-smooth 120Hz refresh rate and Pro-XDR technology, visuals are not only smooth but also incredibly deep and vibrant. And for next-level eye comfort, AI Eye Protection works in the background to reduce eye strain.\r\nMade for comfort. Even with an advanced 9-layer internal cooling structure, the phone still maintains an ultra-thin body of just 7.6mm, and a weight of only 185g.\r\nMotorsports inspired design, born for speed. The back design captures the concept of extreme speed in motorsports, with an advanced process that brings to life the weightless feeling of zipping through the air.', '128GB + 6GB RAM', 'touch screen', '5G', 'rl'),
(29, 're5.png', 'Redmi A4 5G', '8,299', 50, '10,999', '(25%off)', 'Redmi A4 5G (Sparkle Purple, 4GB RAM, 64GB Storage) | Global Debut SD 4s Gen 2 | Segment Largest 6.88in 120Hz | 50MP Dual Camera | 18W Fast Charging', 'High performance - Snapdragon 4s Gen 2 5G Processor | Large 17.47cm 120Hz Display | Upto 8GB RAM including 4GB Virtual RAM |64GB Storage | Fast Side fingerprint sensor\r\nDisplay: Large 17.47 cm 120Hz Refresh Rate display | 600nits peak brightness | 240Hz Touch sampling Rate | TUV triple certified eye care protection\r\nCamera: 50MP Dual camera | 5MP Front camera\r\n5160mAh(typ) battery with 18W fast charging support and 33W charger in-box with USB Type-C\r\nExpandable Storage to upto 1TB with Dedicated MicroSD card Slot | 3.5mm headphone jack | Android 14 | Side fingerprint sensor\r\nSupports 4G+ 5G SA network | Note : 5G NSA not supported | Please check availability of Standalone 5G with your networks provider', '64GB + 4GB RAM', 'touch screen', '5G', 'rl'),
(30, 're6.png', 'realme 13 Pro 5G', '23,974', 50, '34,999', '(32%off)', 'realme 13 Pro 5G (Monet Gold,12GB+512GB)', 'Brand	realme\r\nOperating System	Android 14\r\nRAM Memory Installed Size	12 GB\r\nCPU Model	Snapdragon\r\nCPU Speed	2.4 GHz', '25GGB + 12GB RAM', 'touc screen', '5G', 'rl');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(15) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `adr` varchar(1000) NOT NULL,
  `cup` varchar(10) NOT NULL,
  `img` varchar(200) NOT NULL,
  `otp` varchar(100) NOT NULL,
  `stat` varchar(100) NOT NULL,
  `cou` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`, `mobile`, `adr`, `cup`, `img`, `otp`, `stat`, `cou`) VALUES
(1, 'KISHAN SADHU', 'kishansadhusadhu69@gmail.com', 'Nvdgkx]4n', '4663636346', '                                        rajkot                                        ', 'W6K3R8', '68144386a4051WhatsApp Image 2023-09-28 at 16.21.57.jpg', '', 'inactive', ''),
(2, 'KISHAN SADHU', 'ksadhu@gmail.com', 'Nvdgkx]4n', '1234666665', 'rajkot', '19ZNSF', '67f7dcced44b5v1.png', '', 'inactive', ''),
(3, 'KISHAN SADHU', 'kishansadhusadhu6@gmail.com', 'Nvdgkx]4', '9876543325', '                                        rajkot                                        ', 'CEJIA2', 'user.png', '', 'inactive', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderp`
--
ALTER TABLE `orderp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orderp`
--
ALTER TABLE `orderp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
