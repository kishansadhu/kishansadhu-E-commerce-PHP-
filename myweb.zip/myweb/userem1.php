<?php
include('ses.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Details</title>
</head>

<body>


    <?php
    if(isset($_COOKIE['otp1'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:100px;">
            <strong><?php echo $_COOKIE['otp1']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>

    <?php
    if(isset($_COOKIE['pus1'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:100px;">
            <strong><?php echo $_COOKIE['pus1']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>


    <?php
    if(isset($_COOKIE['ede1'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-danger alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:100px;">
            <strong><?php echo $_COOKIE['ede1']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>


    <?php
    if(isset($_COOKIE['onm1'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-danger alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:100px;">
            <strong><?php echo $_COOKIE['onm1']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>


    <?php
    if(isset($_COOKIE['onm11'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-danger alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:100px;">
            <strong><?php echo $_COOKIE['onm11']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>

    <?php
    if(isset($_COOKIE['onm111'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-danger alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:100px;">
            <strong><?php echo $_COOKIE['onm111']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>






    <script>
    setTimeout(function() {
        document.getElementById('alt1').style.display = "none";
    }, 4000)
    </script>





    <?php

    if(isset($_SESSION['reg']) && $_SESSION['reg'] == "login" ||  isset($_SESSION['log']) &&  $_SESSION['log'] == "login"){
        include('navbaru.php');
    }
    else{
        echo "<script>
        window.location.href = '/myweb/index.php';
        </script>";
    }
   ?>


    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="main-banner header-text" id="top1">
        <div class="Modern-Slider">
            <div class="item item-3">
                <div class="img-fill">
                    <div class="text-content">
                    </div>
                </div>
            </div>

        </div>
    </div>
    <br><br><br>




    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="text-center mb-4">
                </div>
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h2 class="card-title text-center mb-4">Update Mobile & Email</h2>
                        <hr>
                        <form action="fgetm.php" method="post" id="formuu1">
                            <div class="form-group">
                                <label for="email">New Email Id</label>
                                <input name="ef3" class="form-control" id="email" placeholder="john.doe@domain.com"
                                    type="email" />
                            </div>
                            <div class="form-group">
                                <label for="email">New Mobile</label>
                                <input name="psf3" class="form-control" id="pass" placeholder="3545452312" type="text"
                                    maxlength="10" />
                            </div>

                            <div class="form-group">
                                <label for="password">OTP</label>
                                <div class="input-group">
                                    <input name="pf3" class="form-control" id="password" placeholder="OTP" type="text"
                                        maxlength="4" />
                                </div>
                            </div><br>


                            <button class="btn btn-primary" name="fg11" type="submit">Update</button>
                        </form><br>

                        <a href="userem.php">Re-Sent OTP</a><br>

                    </div>
                </div>
            </div>
        </div>
    </div><br><br><br><br>


    <script>
    $("#formuu1").validate({
        rules: {
            ef3: {
                required: true,
                email: true
            },
            psf3: {
                required: true
            },
            pf3: {
                required: true,

            }

        },
        messages: {
            ef3: {
                required: "Enter Old Email",
                email: "Enter Valid Email"
            },
            psf3: {
                required: "Please Enter Mobile Num"
            },
            pf3: {
                required: "Enter OTP",
            }
        },
        highlight: function(element) {
            $(element).addClass("highlight").removeClass("valid");
        },
        unhighlight: function(element) {
            $(element).removeClass("highlight").addClass("valid");
        },
    });
    </script>

    <?php
include('foot.php');
?>
</body>

</html>