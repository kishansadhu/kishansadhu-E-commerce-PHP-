<!-- rich text editor for any page editing ke liye -->
<?php
include('ases.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.0/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="/myweb/plug/bootstrap-4.0.0-dist/css/bootstrap.min.css">
    <link href="/myweb/srm/summernote.min.css" rel="stylesheet">

    <title>Admin Panel</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <style>
    /* this is for the form error */
    label.error {
        border-radius: 5px;
        color: red;
    }

    .error {
        margin-top: 1.5px;
        color: red;
        font-size: 15px;
        font-weight: 500;
    }

    .highlight {
        border: 2px solid rgb(252, 150, 150);
    }

    .valid {
        border: 2px solid green;

    }

    body.modal-open {
        overflow: visible !important;
        padding-right: 0 !important;
    }

    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }

    /* Sidebar Styles */
    .sidebar {
        height: 100vh;
        /* width: 350px; */
        width: 340px;
        position: fixed;
        left: 0;
        top: 0;
        background: rgb(255, 255, 255);
        /* background: #FBF8EF; */
        padding-top: 20px;
        transition: transform 0.3s ease-in-out;
        box-shadow: 5px 5px 10px 0px black;
        z-index: 100;
        transition: 0.3s;
    }

    @media (max-width: 768px) {
        .sidebar {
            box-shadow: 1px 1px 3px 0px black;
        }
    }

    ::selection {
        color: white;
        background-color: black;
    }





    .content {
        z-index: 10;
    }

    .sidebar a {
        color: black;
        padding: 10px;
        text-decoration: none;
        display: block;
        /* transition: background 0.3s ease-in-out; */
        font-size: 25px;
        font-weight: 500;
        font-family: monospace;
        margin-top: 20px;
    }

    .sidebar a:hover {
        /* background:#4b49ac; */
        background: #4B49AC;
        border-radius: 2px;
        color: white;
    }

    /* Sidebar Hidden on Small Devices */
    @media (max-width: 768px) {
        .sidebar {
            transform: translateX(-100%);
        }

        .sidebar.active {
            transform: translateX(0);
        }
    }

    /* Toggle Button for Small Devices */
    .toggle-btn {
        display: none;
        position: fixed;
        left: 10px;
        top: 10px;
        /* background: #007bff; */
        background: #FFFFFF;
        color: #A4C639;
        border: none;
        padding: 10px 15px;
        cursor: pointer;
        z-index: 1000;
        border: 0.5px solid rgb(137, 136, 136);
        border-radius: 10px;
    }

    @media (max-width: 768px) {
        .toggle-btn {
            display: block;
        }

    }

    /* Content Area */
    .content {
        margin-left: 500px;
        padding: 20px;
    }

    @media (max-width: 768px) {
        .content {
            margin-left: 0px;
            margin-top: 100px;
        }
    }

    /* Content Sections */
    .section {
        display: none;
        animation: fadeIn 0.5s ease-in-out;
    }

    .section.active {
        display: block;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }


    .row .col-lg-6 .card:hover {
        bottom: 0.1px;
        box-shadow: 2px 2px 9px 0px black;
    }

    .row .card {
        background: #FBF8EF;
    }

    #home,
    #about,
    #order,
    #services,
    #contact {
        height: 100;
    }

    body {
        /* background: #FBF8EF; */
        background: #EEEEEE;
    }

    table th {
        /* background: #79D7BE; */
        color: rgb(0, 0, 0);
        font-weight: bolder;
        font-size: 17px;
        background: rgb(200, 202, 202);

    }

    @media (max-width: 365px) {
        .row .col-lg-6 .card {
            width: 230px;
        }
    }
    </style>
</head>

<script src="/myweb/plug/js/jquery-3.7.1.min.js"></script>
<script src="/myweb/plug/js/jquery.validate.js"></script>
<script src="/myweb/plug/js/additional-methods.js"></script>

<script src="/myweb/plug/bootstrap-4.0.0-dist/js/bootstrap.bundle.js"></script>
<script src="/myweb/srm/summernote.min.js"></script>


<body>





    <?php
    if(isset($_SESSION['admin']) && $_SESSION['admin'] == "login"){
        echo "";
    }
    else{
        echo "
        <script>
        window.location.href = '/myweb/index.php'
        </script>
        ";
    }

    ?>
    <!-- Toggle Button for Small Devices -->
    <button class="toggle-btn" onclick="toggleMenu()">☰ </button>

    <!-- Sidebar Navigation -->
    <div class="sidebar" id="sidebar">
    <style>
        #tog:hover {
            color: white;
        }

        .dropdown-item:hover {
            /* background:#4b49ac; */
            background: #4B49AC;
            border-radius: 5px;
            color: white;
        }
        </style>
        <!-- <a href='#' class="dropdown-toggle" type="button" id="productDropdown" id='tog' data-toggle="dropdown">
            Pages Edit
        </a>
        <div class="dropdown-menu" aria-labelledby="productDropdown">
            <a class="dropdown-item" href="#">Home</a>
            <a class="dropdown-item" href="#">Contact</a>
            <a class="dropdown-item" href="#">About</a>
            <a class="dropdown-item" href="#">Compare</a>
        </div> -->

        <center style="font-size:50px;font-weight:bold;font-family: monospace;">
            <span style="font-weight:bold;font-family: monospace;color:#a4c639;">A</span><span>dmin</span>
        </center>
        <a href="ad.php" class="nav-link"><i class="fa fa-1x fa-home mt-1" style="height:40px;"></i> Dashbord</a>
        <a href="adu.php"><i class="fa fa-1x fa-users mt-1" style="height:40px;"></i> Users</a>
        <a href="ado.php" ><i class="fa fa-1x fa-truck mt-1" style="height:40px;"></i> Orders</a>
        <a href="adp.php" ><i class="fa fa-1x fa-mobile mt-1" style="height:40px;"></i> Product</a>
        <a href="ada.php"><i class="fa fa-1x fa-user mt-1" style="height:40px;"></i> Admins</a>
        <a href="conq.php"><i class="fa fa-1x fa-comment mt-1" style="height:40px;"></i> User Query</a>
        <hr>
        <!-- <a href="adprofile.php" style='border:1px solid black;margin-top:100px;'><i class="fa fa-1x fa-user-secret  mt-1" style="height:40px;"></i> Profile</a> -->
        <a href="lo1.php" style='border:1px solid black;margin-top:5px;'><i class="fa fa-1x fa-sign-in mt-1" style="height:40px;"></i> Logout</a>
    </div>








    <script>
    // Toggle Sidebar for Small Devices
    function toggleMenu() {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.toggle('active');
    }

    // Show Section Content
    function showSection(id) {

        const sidebar = document.getElementById('sidebar');
        if (window.innerWidth <= 768) {
            sidebar.classList.remove('active');
        }
    }
    </script>

</body>

</html>