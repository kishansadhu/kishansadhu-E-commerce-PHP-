<?php
include('ses.php');
$em = $_SESSION['ue'];
$nm=$_SESSION['ue1'];


        if(isset($_POST['addo'])){

            $p = "SELECT * FROM orders WHERE name='$nm' and email='$em'";
            $p1 = mysqli_query($con,$p);
            $p2 = mysqli_fetch_assoc($p1);
            $pq = $p2['qun'];
            $q1 =$_POST['oq'];
            $oq = $q1 - $pq;

            $slp = "SELECT * FROM product WHERE name='$nm'";
            $slrp = mysqli_query($con,$slp);
            $slrpf = mysqli_fetch_assoc($slrp);
            $qu = $slrpf['qun'];
            $niq =$qu - $oq     ;



            $n =$_POST['on'];
            $p =mysqli_real_escape_string($con,$_POST['op']);
            $q =mysqli_real_escape_string($con,$_POST['oq']);
            $t =$_POST['otot'];
            $s =$_POST['os'];
            $sm=$_POST['ome'];
            $e =$_POST['oe'];



            $ui = "UPDATE orders  SET name='$n',email='$e',prize='$p',qun='$q',tot='$t',stat='$s',method='$sm' where email='$em' and name='$nm' ";
            $ur = mysqli_query($con,$ui);


            $int1 = "UPDATE product SET qun='$niq' where name='$nm'";
            $irt1= mysqli_query($con,$int1);


            setcookie("uo","Updated Successfully",time()+2);
            echo "
            <script>
            window.location.href = '/myweb/ado.php';
            </script>
            ";











        }
?>