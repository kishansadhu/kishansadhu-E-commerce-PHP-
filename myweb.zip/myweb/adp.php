<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
</head>

<body>


    <?php
    if(isset($_COOKIE['ap'])){
        ?>
    <div class="container  w-100">
        <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show" role="alert" id="alt"
            style="z-index:10000;">
            <strong><?php echo $_COOKIE['ap']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>


    <?php
    if(isset($_COOKIE['dp'])){
        ?>
    <div class="container  w-100">
        <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show" role="alert" id="alt"
            style="z-index:10000;">
            <strong><?php echo $_COOKIE['dp']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>

    <?php
    if(isset($_COOKIE['updatep'])){
        ?>
    <div class="container  w-100">
        <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show" role="alert" id="alt"
            style="z-index:10000;">
            <strong><?php echo $_COOKIE['updatep']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>








    <?php
    include('admin.php');
    ?><br><br><br>

    <div class="container card w3-animate-opacity" style="padding:20px;border-radius:20px;">
        <span><span style="font-weight:bold;font-family: monospace;font-size:30px;color:#a4c639;">P</span><span
                style="font-weight:bold;font-family: monospace;font-size:30px;">roduct</span></span>

        <div class="d-flex flex-row-reverse">
            <button style="width:110px;color:" type="button" class="btn btn-success" data-toggle="modal" data-target="#two">
                Add Product
            </button>
        </div>
        <br>
        <style>
        #services #sr {
            /* overflow-y:scroll; */
            height: 100px;
        }
        </style>

        <?php
                $sel1 = "SELECT  * FROM product";
                $run = mysqli_query($con,$sel1);
                // $fm = mysqli_fetch_assoc($run);

                // jese hi select ho jaye vese num rows ke wise data add karo table me.
                echo "<table class=' container table table-striped table-responsive' style='font-size:16px;font-weight:bold;'>
                        <tr>
                        <th>id</th>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Prize</th>
                        <th>Quntity</th>
                        <th>Offers</th>
                        <th>Offers-Rate</th>
                        <th>Discription</th>
                        <th>About</th>
                        <th>Memoriy</th>
                        <th>Interface</th>
                        <th>Technical</th>
                        <th>Edit</th>
                        <th>Action</th>
                        </tr>
                ";

                if(mysqli_num_rows($run) > 0){
                    $i = 1;
                    $total_prize= 0;
                    while($f = mysqli_fetch_assoc($run)){
                        // $i mens all item starting from 1
                        // f[prize] ke niche jo form he usme muje jo qun he usme uske total prize ke liye likha he
                        echo"
                        <tr>
                        <td class='bg-light'>$i</td>
                        <td class='bg-light'><img src='img/$f[img]' style='height:100px;width:100px;'></td>
                        <td>$f[name]</td>
                        <td>$f[prize]</td>
                        <td>$f[qun]</td>
                        <td>$f[offer]</td>
                        <td>$f[offr]</td>
                        <td>$f[di]</td>
                        <td id='sr'><textarea rows='8' name='' readonly>$f[about]</textarea></td>
                        <td>$f[mem]</td>
                        <td>$f[inf]</td>
                        <td>$f[tec]</td>
                        <td>
                        <form action='pma1.php' method='post'>
                            <input type='submit' name='up1' class='btn btn-success' value='Edit'>
                            <input type='hidden' name='up' value='$f[name]'>
                            <input type='hidden' name='up2' value='$f[u]'>
                        </form>
                        </td>
                        <td>
                        <form action='pma.php' method='post'>
                            <input type='submit' name='rm1' class='btn btn-danger' value='Remove'>
                            <input type='hidden' name='rm' value='$f[name]'>
                        </form>
                        </td>
                        </tr>
                        ";
                        $i =  $i + 1;
                    }
                    echo "</table>";
                }
                else{
                    Echo "
                    <table>
                    <tr>
                    <h2 class='text-dark'>We Dont Have Any Users</h2><br>
                    </tr>
                    </table>
                    ";

                }

                ?>
        <hr><br>



        <div class="modal fade" id="two">
            <div class="modal-dialog" role="document">
                <div class="modal-content bg-light text-dark">
                    <div class="modal-header">
                        <h3>Add New Product</h3>
                    </div>
                    <div class="modal-body">
                        <form action="pma.php" method="post" id="fpro" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="name">Select Product</label>
                                <select name="prd" class=" form-control">
                                    <option value="sam">Samsung</option>
                                    <option value="vivo">Vivo</option>
                                    <option value="red">Redmi</option>
                                    <option value="op">Oppo</option>
                                    <option value="rl">Reylme</option>
                                </select>

                            </div>
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input name="pn" class="form-control" id="name" type="text" />
                            </div>
                            <div class="form-group">
                                <label for="email">Prize</label>
                                <input name="pp" class="form-control" id="email" type="text" />
                            </div>
                            <div class="form-group">
                                <label for="password">Offers</label>
                                <div class="input-group">
                                    <input name="po" class="form-control" id="password" type="text" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="confirm-password">Offres-Rate</label>
                                <div class="input-group">
                                    <input name="por" class="form-control" id="password1" type="text" />
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="confirm-password">Description</label>
                                <div class="input-group">
                                    <input name="pd" class="form-control" id="confirm-password" type="text" />
                                </div>
                            </div>


                            <div class="form-group">
                                <label for="confirm-password">About</label>
                                <div class="input-group">
                                    <textarea name="pab" class=" form-control"></textarea>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="confirm-password">Memory</label>
                                <div class="input-group">
                                    <input name="pm" class="form-control" id="confirm-password" type="text" />
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="confirm-password">Interface</label>
                                <div class="input-group">
                                    <input name="pi" class="form-control" id="confirm-password" type="text" />
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="confirm-password">Technologiy</label>
                                <div class="input-group">
                                    <input name="pt" class="form-control" id="confirm-password" type="text" />
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="confirm-password">Picture</label>
                                <div class="input-group">
                                    <input name="f2" class="form-control" type="file" />
                                </div>
                            </div>
                            <input type="submit" class="btn btn-success btn-block" name="addpro"
                                value="Add New Product">
                        </form>

                        <script>
                        $("#fpro").validate({
                            rules: {
                                pn: {
                                    required: true
                                },
                                pp: {
                                    required: true
                                },
                                po: {
                                    required: true
                                },
                                por: {
                                    required: true
                                },
                                pd: {
                                    required: true
                                },
                                pab: {
                                    required: true
                                },
                                pm: {
                                    required: true
                                },
                                pi: {
                                    required: true
                                },
                                pt: {
                                    required: true
                                },
                                f2: {
                                    required: true,
                                    accept: "image/*",
                                    fileSize: 100 * 1024
                                }

                            },
                            messages: {
                                pn: {
                                    required: "Please enter your full name"
                                },
                                pp: {
                                    required: "Please enter Prize"
                                },
                                po: {
                                    required: "Please enter offer"
                                },
                                cor: {
                                    required: "Please Enter offer rate"
                                },
                                pd: {
                                    required: "Enter Description"
                                },
                                pab: {
                                    required: "Enter Product About"
                                },
                                pm: {
                                    required: "Enter Product Memory"
                                },
                                pi: {
                                    required: "Enter Product Interface"
                                },
                                pt: {
                                    required: "Enter Product Technology"
                                },
                                f2: {
                                    required: "Please Select New Img",
                                    accept: "Upload Onley jpeg,png,svg..",
                                    fileSize: "File Maximum Size 100KB"
                                }
                            },
                            highlight: function(element) {
                                $(element).addClass("highlight").removeClass("valid");
                            },
                            unhighlight: function(element) {
                                $(element).removeClass("highlight").addClass("valid");
                            }
                        });
                        </script>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div><br><br><br>

    <script>
    setTimeout(function() {
        document.getElementById('alt').style.display = "none";
    }, 2000)
    </script>
</body>

</html>