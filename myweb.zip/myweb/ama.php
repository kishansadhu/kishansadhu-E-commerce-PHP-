<?php
include('ases.php');
if(isset($_POST['rm1'])){
        $mc = $_POST['rm'];
        $del1 = "DELETE FROM admin WHERE email='$mc'";
        $drun1 = mysqli_query($con,$del1);
        setcookie("add","Admin deleted Successfully",time()+2);
       echo "
        <script>
        window.location.href ='/myweb/ada.php';
        </script>
        ";

}



if(isset($_POST['addadm'])){
    $n = $_POST['an'];
    $e = $_POST['ae'];
    $p = $_POST['ap'];


    $rs = "SELECT email FROM admin where email='$e' ";
    $rsr =mysqli_query($con,$rs);
    if(mysqli_num_rows($rsr) >0){

        setcookie("ade","Email already exist",time()+2);
        echo "<script>
        window.location.href ='/myweb/ada.php';
        </script>";
    }
    else{
        $ui = "INSERT INTO admin (name,email,password) VALUES ('$n','$e','$p')";
        $ur = mysqli_query($con,$ui);

        setcookie("ada","Admin Added Successfully",time()+2);
        echo "<script>
        window.location.href ='/myweb/ada.php';
        </script>";
        }

    }

?>