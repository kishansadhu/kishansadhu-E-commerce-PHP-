<?php

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>


<body>

    <?php
    include('admin.php');
    if(isset($_POST['up1'])){
        $e = $_POST['up'];
        $e1 = $_POST['up2'];

        $_SESSION['ue'] =  $e;
        $_SESSION['ue1'] =  $e1;

        $seld = "SELECT  * FROM product where name='$e' and u='$e1'";
        $rund = mysqli_query($con,$seld);
        $fd = mysqli_fetch_assoc($rund);

    }
    else{
        echo "<script>
        window.location.href ='/myweb/adp.php'
        </script>";
    }


        ?>

    </div>
    <br><br>
    <div class="container card" style="padding:20px;border-radius:20px;">
        <h2>Edit Details</h2>
        <hr><br>
        <form action="pman2.php"  method="POST" id="fprok" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Name</label>
                <input name="pn1" class="form-control" id="name" type="text" value='<?php echo $fd['name']; ?>' readonly/>
            </div>
            <div class="form-group">
                <label for="email">Prize</label>
                <input name="pp1" class="form-control" id="email" type="text" value='<?php echo $fd['prize']; ?>' />
            </div>

            <div class="form-group">
                <label for="email">Quntity</label>
                <input name="pq1" class="form-control" id="email" type="text" value='<?php echo $fd['qun']; ?>' />
            </div>
            <div class="form-group">
                <label for="password">Offers</label>
                <div class="input-group">
                    <input name="po1" class="form-control" id="password" type="text"
                        value='<?php echo $fd['offer']; ?>' />
                </div>
            </div>
            <div class="form-group">
                <label for="confirm-password">Offres-Rate</label>
                <div class="input-group">
                    <input name="por1" class="form-control" id="password1" type="text"
                        value='<?php echo $fd['offr']; ?>' />
                </div>
            </div>

            <div class="form-group">
                <label for="confirm-password">Description</label>
                <div class="input-group">
                    <input name="pd1" class="form-control" id="confirm-password" type="text"
                        value='<?php echo $fd['di']; ?>' />
                </div>
            </div>


            <div class="form-group">
                <label for="confirm-password">About</label>
                <div class="input-group">
                    <textarea name="pab1" class=" form-control">
                    <?php echo $fd['about']; ?>
                    </textarea>
                </div>
            </div>

            <div class="form-group">
                <label for="confirm-password">Memory</label>
                <div class="input-group">
                    <input name="pm1" class="form-control" id="confirm-password" type="text"
                        value='<?php echo $fd['mem']; ?>' />
                </div>
            </div>

            <div class="form-group">
                <label for="confirm-password">Interface</label>
                <div class="input-group">
                    <input name="pi1" class="form-control" id="confirm-password" type="text"
                        value='<?php echo $fd['inf']; ?> ' />
                </div>
            </div>

            <div class="form-group">
                <label for="confirm-password">Technologiy</label>
                <div class="input-group">
                    <input name="pt1" class="form-control" id="confirm-password" type="text"
                        value='<?php echo $fd['tec']; ?>' />
                </div>
            </div>

            <div class="form-group">
                <label for="confirm-password">Picture</label>
                <div class="input-group">
                    <input name="f2" class="form-control" type="file" />
                </div>
            </div>
            <input type="submit" class="btn btn-success btn-block" name="uppro" value="Update Details">
        </form>
    </div>

        <script>
        $("#fprok").validate({
            rules: {
                pn1: {
                    required: true
                },
                pp1: {
                    required: true
                },
                po1: {
                    required: true
                },
                por1: {
                    required: true
                },
                pd1: {
                    required: true
                },
                pab1: {
                    required: true
                },
                pm1: {
                    required: true
                },
                pi1: {
                    required: true
                },
                pt1: {
                    required: true
                }

            },
            messages: {
                pn1: {
                    required: "Please enter your full name"
                },
                pp1: {
                    required: "Please enter Prize"
                },
                po1: {
                    required: "Please enter offer"
                },
                cor1: {
                    required: "Please Enter offer rate"
                },
                pd1: {
                    required: "Enter Description"
                },
                pab1: {
                    required: "Enter Product About"
                },
                pm1: {
                    required: "Enter Product Memory"
                },
                pi1: {
                    required: "Enter Product Interface"
                },
                pt1: {
                    required: "Enter Product Technology"
                }
            },
            highlight: function(element) {
                $(element).addClass("highlight").removeClass("valid");
            },
            unhighlight: function(element) {
                $(element).removeClass("highlight").addClass("valid");
            }
        });
         </script><br><br><br><br><br>
</body>
</html>