<?php
include('ases.php');



if(isset($_POST['rm1'])){
    $mc = $_POST['rm'];
    $mc1 = $_POST['rm2'];
    $mc4 = $_POST['rm4'];


        $pp1 = "SELECT * FROM product where name='$mc' ";
        $pp2 = mysqli_query($con,$pp1);
        $pp3 = mysqli_fetch_assoc($pp2);

        $pp11= "SELECT * FROM orders where name='$mc' and email='$mc1'";
        $pp12 = mysqli_query($con,$pp11);
        $pp13 = mysqli_fetch_assoc($pp12);


        $flq1 = ($pp3['qun'] + $mc4) ;


            $del12 = "DELETE  FROM orders WHERE name='$mc' and email='$mc1'";
            $drun12 = mysqli_query($con,$del12);


            $int112 = "UPDATE product SET qun='$flq1' where name='$mc'";
            $irt112= mysqli_query($con,$int112);

            setcookie("do","Order Deleted Successfully",time()+2);
            echo "
            <script>
            window.location.href ='/myweb/ado.php';
            </script>
            ";
}







if(isset($_POST['addo'])){
    $n1 = mysqli_real_escape_string($con,$_POST['on']);
    $p1 = mysqli_real_escape_string($con,$_POST['op']);
    $q1 = mysqli_real_escape_string($con,$_POST['oq']);
    $t1 = mysqli_real_escape_string($con,$_POST['otot']);
    $s1 = mysqli_real_escape_string($con,$_POST['os']);
    $sm1= mysqli_real_escape_string($con,$_POST['ome']);
    $e1 = mysqli_real_escape_string($con,$_POST['oe']);


    $rs11 = "SELECT * FROM orders where email='$e1' and name='$n1'";
    $rsr1k =mysqli_query($con,$rs11);

    if(mysqli_num_rows($rsr1k) > 0){
        setcookie("eo","Order Already Exist",time()+2);
        echo "<script>
        window.location.href ='/myweb/ado.php';
        </script>";
    }

    else{
        $insert = "INSERT INTO orders (name,prize,qun,tot,stat,method,email) VALUES ('$n1','$p1',1,'$t1','$s1','$sm1','$e1') ";
        $ir = mysqli_query($con,$insert);

        $sl = "SELECT * FROM product where name='$n1' ";
        $slr = mysqli_query($con,$sl);
        $srl = mysqli_fetch_assoc($slr);
        $qun = $srl['qun'] - 1 ;
        $int = "UPDATE product SET qun='$qun' where name='$n1'";
        $irt= mysqli_query($con,$int);

        setcookie("ao","Order Added Successfully",time()+2);
        echo "<script>
        window.location.href ='/myweb/ado.php';
        </script>";
        }

}


?>