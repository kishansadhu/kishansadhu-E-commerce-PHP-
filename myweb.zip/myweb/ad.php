<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashbord</title>
</head>

<body>
    <?php
    include('admin.php');
    // echo "<center>".$_SESSION['am']['e']."</center>";
    ?><br><br><br>
    <div class="container">
        <div class="card w3-animate-opacity" style="padding:20px;border-radius:20px;">
        <span><span style="font-weight:bold;font-family: monospace;font-size:30px;color:#a4c639;">D</span><span
        style="font-weight:bold;font-family: monospace;font-size:30px;">ashbord</span></span>
            <div class="container p-5 bg-white">
                <div class="row">
                    <?php
                    $sel1 = "SELECT *  FROM  user";
                    $run1 = mysqli_query($con,$sel1);
                    $tr1 = mysqli_num_rows($run1);

                    ?>
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="card bg-light p-2 text-center text-dark">
                            <div class="row">
                                <div class="col-4">
                                <i class="fa fa-3x fa-users mt-1" style="height:50px;"></i>
                                </div>
                                <div class="col-4">
                                    <h4>Total User</h4>
                                    <h4><?php echo $tr1; ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php
                    $sel2 = "SELECT *  FROM  orderp where stat='complete' or stat='pendding'";
                    $run2 = mysqli_query($con,$sel2);
                    $tr2 = mysqli_num_rows($run2);

                    ?>

                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="card bg-light p-2 text-center text-dark">
                            <div class="row">
                                <div class="col-4">
                                    <i class="fa fa-3x fa-truck mt-1" style="height:50px;"></i>
                                </div>
                                <div class="col-4">
                                    <h4>Total Order</h4>
                                    <h4><?php echo $tr2;  ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><br>



                <?php
                    $sel3 = "SELECT *  FROM  product";
                    $run3 = mysqli_query($con,$sel3);
                    $tr3 = mysqli_num_rows($run3);

                    ?>
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="card bg-light p-2 text-center text-dark">
                            <div class="row">
                                <div class="col-4">
                                <i class="fa fa-3x fa-mobile mt-1 " style="height:50px;"></i>
                                </div>
                                <div class="col-4">
                                    <h4>Total Mobiles</h4>
                                    <h4><?php echo $tr3; ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>



                    <?php
                $sel4 = "SELECT  * FROM admin";
                $run4 = mysqli_query($con,$sel4);
                $tr4 = mysqli_num_rows($run4);
                ?>

                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="card bg-light p-2 text-center text-dark">
                            <div class="row">
                                <div class="col-4">
                                <i class="fa fa-3x fa-user mt-1" style="height:50px;"></i>
                                </div>
                                <div class="col-4">
                                    <h4>Total Admin</h4>
                                    <h4><?php echo $tr4;  ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><br><br>


                <?php
                $sel5 = "SELECT *  FROM  orderp where stat='complete' or stat='recived' or stat='recive' ";
                $run5 = mysqli_query($con,$sel5);
                $tr5 = mysqli_num_rows($run5);
                $tp= 0;
                if(mysqli_num_rows($run5) > 0){
                  $i = 1;
                      while($f = mysqli_fetch_assoc($run5)){
                          $st = $f['prize'];
                          $int = (int)str_replace(",","",$st);
                          $m = ($f['qun'] ) * $int;
                          $st1 = number_format($m);
                          $tp = $tp + $m;
                          $i =  $i + 1;
                      }
                  }
                ?>
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="card bg-light p-2 text-center text-dark">
                            <div class="row">
                                <div class="col-4">
                                <i class="fa fa-3x fa-money mt-1" style="height:50px;"></i>
                                </div>
                                <div class="col-4">
                                    <h4>Profite</h4>
                                    <h4><?php echo number_format($tp); ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>


                    <?php
                        $sel6 = "SELECT  stat  FROM orderp where stat='canseled' or stat='cansel'";
                        $run6 = mysqli_query($con,$sel6);
                        $tr6 =mysqli_num_rows($run6) ;
                       ?>

                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="card bg-light p-2 text-center text-dark">
                            <div class="row">
                                <div class="col-4">
                                <i class="fa fa-3x fa-ban mt-1" style="height:50px;"></i>
                                </div>
                                <div class="col-6">
                                    <h4>Order Cansel</h4>
                                    <h4><?php echo $tr6;  ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

</body>

</html>