<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users</title>
</head>

<body>
    <?php
    if(isset($_COOKIE['uadd'])){
        ?>
    <div class="container  w-100">
        <div class="alert w3-animate-right alert-success alert-dismissible fade show" role="alert" id="alt"
            style="z-index:10000;">
            <strong><?php echo $_COOKIE['uadd']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>




    <?php
    if(isset($_COOKIE['udel'])){
        ?>
    <div class="container  w-100">
        <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show" role="alert" id="alt"
            style="z-index:10000;">
            <strong><?php echo $_COOKIE['udel']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>



    <?php
    if(isset($_COOKIE['eu'])){
        ?>
    <div class="container  w-100">
        <div class="fixed-top container w3-animate-right alert alert-danger alert-dismissible fade show" role="alert" id="alt"
            style="z-index:10000;">
            <strong><?php echo $_COOKIE['eu']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>



    <?php
    if(isset($_COOKIE['ude'])){
        ?>
    <div class="container  w-100">
        <div class="fixed-top container w3-animate-right alert alert-danger alert-dismissible fade show" role="alert" id="alt"
            style="z-index:10000;">
            <strong><?php echo $_COOKIE['ude']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>



    <?php
    if(isset($_COOKIE['up'])){
        ?>
    <div class="container  w-100">
        <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show" role="alert" id="alt"
            style="z-index:10000;">
            <strong><?php echo $_COOKIE['up']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>


    <?php
    if(isset($_COOKIE['up1'])){
        ?>
    <div class="container  w-100">
        <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show" role="alert" id="alt"
            style="z-index:10000;">
            <strong><?php echo $_COOKIE['up1']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>






    <?php
    // if(isset($_SESSION['admin']) && $_SESSION['admin'] == "login"){
        include('admin.php');
    // }
    // else{
    //     echo "
    //     <script>
    //     window.location.href = '/myweb/index.php'
    //     </script>
    //     ";
    // }
    ?>


    <br><br><br>

    <div class="container w3-animate-opacity ">
        <div class="container card" style="padding:20px;border-radius:20px;">
            <span><span style="font-weight:bold;font-family: monospace;font-size:30px;color:#a4c639;">U</span><span
                    style="font-weight:bold;font-family: monospace;font-size:30px;">sers</span></span>
            <div class="d-flex flex-row-reverse">
                <button style="width:100px;" type="button" class="btn btn-success"
                    data-toggle="modal" data-target="#one">
                    Add User
                </button>
            </div>
            <br>
            <?php
                $sel = "SELECT  * FROM user";
                $run = mysqli_query($con,$sel);

                // $fm = mysqli_fetch_assoc($run);

                // jese hi select ho jaye vese num rows ke wise data add karo table me.
                echo "<table class='container table table-striped table-responsive' style='font-size:16px;font-weight:bold;'>
                        <tr>
                        <th>id</th>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Password</th>
                        <th>Mobile</th>
                        <th>Address</th>
                        <th>Edit</th>
                        <th>Action</th>
                        </tr>
                ";

                if(mysqli_num_rows($run) > 0){
                    $i1 = 1;
                    $total_prize= 0;
                    while($f = mysqli_fetch_assoc($run)){
                        $n = $f['password'];
                        $n1 = "";

                        $m = array(
                           "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z",
                        "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
                        "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
                        "!", "\"", "#", "$", "%", "&", "'", "(", ")", "*", "+", ",", "-", ".", "/", ":", ";", "<", "=", ">", "?", "@", "[", "\\", "]", "^", "_", "`", "{", "|", "}", "~",
                        " ", "\t", "\n"
                    );

                            for($i = 0; $i < strlen($n); $i++) {
                                for($j = 0; $j < count($m); $j++) {
                                    if($n[$i] == $m[$j]) {
                                        $n1 .= $m[$j - 3];  // Adding the character 3 positions ahead
                                    }
                                }
                            }

                        // $i mens all item starting from 1
                        // f[prize] ke niche jo form he usme muje jo qun he usme uske total prize ke liye likha he
                        echo"
                        <tr>
                        <td>$i1</td>
                        <td><img src='/myweb/uploads/$f[img]' style='height:50px;width:50px;'></td>
                        <td>$f[name]</td>
                        <td>$f[email]</td>
                        <td>$n1</td>
                        <td>$f[mobile]</td>
                        <td>$f[adr]</td>
                        <td>
                        <form action='uma1.php' method='post'>
                           <input type='submit' name='up1' class='btn btn-success' value='Edit'>
                            <input type='hidden' name='up' value='$f[email]'>
                        </form>
                        </td>
                        <td>
                        <form action='uma.php' method='post'>
                            <input type='submit' name='rm1' class='btn btn-danger' value='Remove'>
                            <input type='hidden' name='rm' value='$f[email]'>
                        </form>
                        </td>
                        </tr>
                        ";
                        $i1 =  $i1 + 1;
                    }
                    echo "</table>";
                }
                else{
                    Echo "
                    <table>
                    <tr>
                    <h2 class='text-dark'>We Dont Have Any Users</h2><br>
                    </tr>
                    </table>
                    ";

                }

                ?>
            <hr><br>

            <!-- <center>
                <button type="button" class="btn  btn-outline-primary btn-block" data-toggle="modal" data-target="#one">
                    Add User
                </button>
            </center><br><br> -->



            <div class="modal fade" id="one">
                <div class="modal-dialog" role="document">
                    <div class="modal-content bg-light text-dark">
                        <div class="modal-header">
                            <h3>Add New User</h3>
                        </div>
                        <div class="modal-body">
                            <form action="uma.php" method="post" id="formreg" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label for="name">Name</label>
                                    <input name="n" class="form-control" id="name" type="text" />
                                </div>
                                <div class="form-group">
                                    <label for="email">Email Id</label>
                                    <input name="e" class="form-control" id="email" type="email" />
                                </div>
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input name="p" class="form-control" id="password" type="password" /><br>
                                    <span><input type="checkbox" class="" id="ch" onclick="show()"> Show
                                        Password</span>
                                    <script>
                                    document.getElementById('password').type = "password"

                                    function show() {
                                        var x = document.getElementById('password');
                                        if (x.type === "password") {
                                            x.type = "text";
                                        } else {
                                            x.type = "password";
                                        }
                                    }
                                    </script>
                                </div>

                                <div class="form-group">
                                    <label for="confirm-password">Mobile Num</label>
                                    <input name="m" class="form-control" id="confirm-password" type="text"
                                            maxlength="10" minlength="1" />
                                </div>


                                <div class="form-group">
                                    <label for="confirm-password">Address</label>
                                    <textarea name="ad" class=" form-control"></textarea>
                                </div>

                                <div class="form-group">
                                    <label for="confirm-password">Profile Picture</label>
                                    <input name="f1" class="form-control" type="file" />
                                </div>
                                <input type="submit" class="btn btn-success btn-block" name="addu" value="Add User">
                            </form>

                            <script>
                            $("#formreg").validate({
                                rules: {
                                    n: {
                                        required: true
                                    },
                                    e: {
                                        required: true,
                                        email: true
                                    },
                                    p: {
                                        required: true,
                                        minlength: 8,
                                        maxlength: 12,
                                        // Regex: kam se kam 1 lowercase, 1 uppercase, 1 digit, 1 special character
                                        pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%?&])[A-Za-z\d@$!%?&]{8,12}$/
                                    },
                                    cp: {
                                        required: true,
                                        equalTo: "#password"
                                    },
                                    m: {
                                        required: true,
                                        maxlength: 10,
                                        minlength: 10,
                                        pattern:/^[0-9]{10}$/
                                    },
                                    f1: {
                                        required: true,
                                        accept: "image/*",
                                        fileSize: 100 * 1024
                                    },
                                    ad: {
                                        required: true
                                    }

                                },
                                messages: {
                                    n: {
                                        required: "Please enter your full name"
                                    },
                                    e: {
                                        required: "Please enter email",
                                        email: "Please enter valid email "
                                    },
                                    p: {
                                        required: "Please provide a password",
                                        minlength: "Password must be exactly 8",
                                        maxlength: "Password Length less then 12",
                                        pattern: "Password Formate Ksadhu@1"
                                    },
                                    cp: {
                                        required: "Please Enter confirm password",
                                        equalTo: "Passwords do not match"
                                    },
                                    m: {
                                        required: "Enter Mobile Num",
                                        maxlength: "Max Length 10",
                                        minlength: "Max Length 10",
                                        pattern:"Enter Valid Mobile Num"
                                    },
                                    f1: {
                                        required: "Please Select New Img",
                                        accept: "Upload Onley jpeg,png,svg..",
                                        fileSize: "File Maximum Size 100KB"
                                    },
                                    ad: {
                                        required: "Enter Your Address"
                                    }
                                },
                                highlight: function(element) {
                                    $(element).addClass("highlight").removeClass("valid");
                                },
                                unhighlight: function(element) {
                                    $(element).removeClass("highlight").addClass("valid");
                                }
                            });
                            </script>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div><br><br><br>
    </div>

    <script>
    setTimeout(function() {
        document.getElementById('alt').style.display = "none";
    }, 2000)
    </script>
</body>

</html>