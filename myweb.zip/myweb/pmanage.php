<?php
include('ses.php');

if(isset($_POST['dt'])){
    $_SESSION['det']['n'] = $_POST['dt1'];
    $_SESSION['det']['p'] = $_POST['dt2'];
    $_SESSION['det']['o'] = $_POST['dt3'];
    $_SESSION['det']['or'] = $_POST['dt4'];
    $_SESSION['det']['des'] = $_POST['dt5'];
    $_SESSION['det']['i'] = $_POST['dt6'];
    $_SESSION['det']['ab'] = $_POST['dt7'];

    $_SESSION['det']['t1'] = $_POST['dt8'];
    $_SESSION['det']['t2'] = $_POST['dt9'];
    $_SESSION['det']['t3'] = $_POST['dt10'];
    $_SESSION['det']['t4'] = $_POST['dt11'];


    echo "
    <script>
    window.location.href='product-details.php'
    </script>
    ";
}
else{
    $_SESSION['det']['dp'] = 0;
}

















if(isset($_SESSION['reg']) && $_SESSION['reg'] == "login" || isset($_SESSION['log']) && $_SESSION['log'] == "login"){
    if(isset($_POST['si'])){
        $_SESSION['det']['n'] = $_POST['dt1'];
        $_SESSION['det']['p'] = $_POST['dt2'];
        $_SESSION['det']['o'] = $_POST['dt3'];
        $_SESSION['det']['or'] = $_POST['dt4'];
        $_SESSION['det']['des'] = $_POST['dt5'];
        $_SESSION['det']['i'] = $_POST['dt6'];
        $_SESSION['det']['ab'] = $_POST['dt7'];

        $_SESSION['det']['t1'] = $_POST['dt8'];
        $_SESSION['det']['t2'] = $_POST['dt9'];
        $_SESSION['det']['t3'] = $_POST['dt10'];
        $_SESSION['det']['t4'] = $_POST['dt11'];
    
        $_SESSION['det']['t3'] = $_POST['dt10'];

        $n = $_POST['dt1'];
        $p=$_POST['dt2'];
        $ip = $_POST['dt6'];
        $em = $_SESSION['r']['e'];
        $dt= date("Y-m-d H:i:s");

        $notp = $_POST['dt1'];
        $pkk = "SELECT * FROM product WHERE name='$notp' and qun>0";
        $pkk1 = mysqli_query($con,$pkk);


        if(mysqli_num_rows($pkk1)>0){
            $rs = "SELECT * FROM orders where name='$n' and email='$em'";
            $rsr = mysqli_query($con,$rs);

        // $rs1 = "SELECT * FROM orders where name='$n' and qun>2";
        // $rsr1 = mysqli_query($con,$rs1);
            if(mysqli_num_rows($rsr) >0){
                setcookie("atc","This Product Already In Cart Please Remove Then You Add It",time()+2);
                echo "<script>
                window.location.href = '/myweb/products.php';
                </script>";
            }
            else{

                setcookie("atc1","Your Mobile Added Into Cart",time()+2);
                $insert = "INSERT INTO orders (img,name,prize,qun,tot,stat,method,email) VALUES ('$ip','$n','$p','1','$p','pendding','pendding','$em') ";
                $ir = mysqli_query($con,$insert);


                $sl = "SELECT * FROM product where name='$n' ";
                $slr = mysqli_query($con,$sl);
                $srl = mysqli_fetch_assoc($slr);
                $qun = $srl['qun'] - 1 ;
                $int = "UPDATE product SET qun='$qun' where name='$n'";
                $irt= mysqli_query($con,$int);


                $insert111 = "INSERT INTO orderp (img,name,prize,qun,tot,stat,method,email) VALUES ('$ip','$n','$p','1','$p','pendding','pendding','$em') ";
                $ir11 = mysqli_query($con,$insert111);

                    echo "
                    <script>
                    window.location.href='products.php'
                    </script>
                    ";

                }
            }

        else{
            echo "<script>
            alert('This Product Is Out Of Stock')
                window.location.href = '/myweb/products.php';
                </script>";
        }
    }
}

else{
    setcookie("plg","Please Login After By The Product",time()+2);
    echo "
    <script>
    window.location.href='/myweb/log.php'
    </script>
    ";
}








?>