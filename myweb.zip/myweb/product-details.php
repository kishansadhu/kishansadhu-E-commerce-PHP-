<?php
include('ses.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap"
        rel="stylesheet">

    <title>Product-Details Page</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/owl.css">
</head>

<body class="w3-animate-opacity bg-light">



    <?php
    if(isset($_SESSION['det'])){
        if(isset($_SESSION['reg']) && $_SESSION['reg'] == "login" ||  isset($_SESSION['log']) &&  $_SESSION['log'] == "login"){
            include('navbaru.php');
        }
        else{
            include('navbar.php');
        }
    }
    else{
        echo "
        <script>
        window.location.href='products.php'
        </script>
        ";
    }
    ?>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="main-banner header-text" id="top1">
        <div class="Modern-Slider">
            <div class="item item-3">
                <div class="img-fill">
                    <div class="text-content">
                    </div>
                </div>
            </div>

        </div>
    </div>








    <div class="services">
        <div class="container">
        <h1><?php echo $_SESSION['det']['n']; ?></h1>

            <div class="row">
                <div class="col-md-7">
                    <div>
                        <img src="img/<?php echo $_SESSION['det']['i']; ?>" alt="" class="img-fluid wc-image">
                    </div>

                    <br>

                    <div class="row">
                        <div class="col-sm-12 col-sm-12 col-12">
                            <div>
                                <form action="pmanage.php" method="post">
                                    <a href="products.php" class="filled-button">More Products</a>
                                </form>
                            </div>
                            <br>
                        </div>

                    </div>

                    <br>
                </div>

                <div class="col-md-5">
                    <div class="sidebar-item recent-posts">
                        <div class="sidebar-heading">
                        </div>
                        <h4 style="font-weight:bold;">Basic Information</h4>
                        <hr>
                        <div class="content" style="font-size:20px;">
                            <?php echo $_SESSION['det']['des']; ?><br>
                            <p style="font-size:20px;font-weight:bold;color:black;">
                                ₹<?php echo $_SESSION['det']['p'] ?></p><br>

                        </div>
                        <hr><br><br>


                        <h4 style="font-weight:bold;">Technical Information</h4>
                        <hr><br>
                        <table class="table table-responsive table-striped">
                            <tr>
                                <th>Name</th>
                                <th><?php echo $_SESSION['det']['n'];  ?></th>
                            </tr>
                            <tr>
                                <th>Prize</th>
                                <th><?php echo $_SESSION['det']['p'];  ?></th>
                            </tr>
                            <tr>
                                <th>Memory Capacity</th>
                                <th><?php echo $_SESSION['det']['t1'];  ?></th>
                            </tr>
                            <tr>
                                <th>Input Interface</th>
                                <th><?php echo $_SESSION['det']['t2'];  ?></th>
                            </tr>
                            <tr>
                                <th>cellular technology</th>
                                <th><?php echo $_SESSION['det']['t3'];  ?></th>
                            </tr>
                            <tr>
                                <th>Quntity</th>
                                <th><?php echo $_SESSION['det']['t4'];  ?></th>
                            </tr>
                            <tr>
                                <th>Statuse</th>
                                <th><?php
                                if($_SESSION['det']['t4'] > 0 && $_SESSION['det']['t4'] <=50){
                                    echo "<h1 class=' badge badge-success'>In Stock</h1>";
                                }
                                else{
                                    echo "<h1 class=' badge badge-danger'>Out Of Stock</h1>";
                                }
                                ?></th>
                            </tr>

                        </table>

                    </div>
                </div>
            </div>

            <br>

            <h4 style="font-weight:bold;">Description</h4>
            <div class=" container-fluid" style='font-size:20px;font-weight:bold;'>
                <pre>
                <?php
                 function cleanText($text) {
                    $text = trim($text);
                    $text = preg_replace('/\s+/', ' ', $text);
                    return $text;
                }
                $ad = $_SESSION['det']['ab'] ?? '';
                echo $ad;  ?>
                </pre>
            </div>

        </div>
    </div><br><br><br><br>

    <?php
include('foot.php');
?>
</body>

</html>