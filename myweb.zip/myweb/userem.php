<?php
include('ses.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Details</title>
</head>

<body>




    <script>
    setTimeout(function() {
        document.getElementById('alt1').style.display = "none";
    }, 3000)
    </script>









    <?php

    if(isset($_SESSION['reg']) && $_SESSION['reg'] == "login" ||  isset($_SESSION['log']) &&  $_SESSION['log'] == "login"){
        include('navbaru.php');
    }
    else{
        echo "<script>
        window.location.href = '/myweb/index.php';
        </script>";
    }


  ?>


    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="main-banner header-text" id="top1">
        <div class="Modern-Slider">
            <div class="item item-3">
                <div class="img-fill">
                    <div class="text-content">
                    </div>
                </div>
            </div>

        </div>
    </div>
    <br><br><br>



                <?php
                $em=$_SESSION['r']['e'];
                $sl = "SELECT * FROM user where email='$em'";
                $sr = mysqli_query($con,$sl);
                $sf=mysqli_fetch_assoc($sr);
                ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="text-center mb-4">
                </div>
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h2 class="card-title text-center mb-4">Update Mobile & Email</h2>
                        <hr>
                        <form action="fgetm.php" method="post" id="formuu">
                            <div class="form-group">
                                <label for="email">Email Id</label>
                                <input name="ef2" class="form-control" value='<?php echo $sf['email'];  ?>' placeholder="john.doe@domain.com" type="email"  readonly/>
                                <input type="hidden" name='nm2' value='<?php echo $sf['name'];  ?>'>
                            </div>
                            <input type="submit" name="go11" class="btn btn-success" value="Send OTP"><br><br>

                            <a href="user.php">Back User Profile</a><br>

                    </div>
                </div>
            </div>
        </div>
    </div><br><br><br><br>


    <script>
    $("#formuu").validate({
        rules: {
            ef2: {
                required: true,
                email: true
            }

        },
        messages: {
            ef2: {
                required: "Enter Your Registered Email",
                email: "Enter Valid Email"
            }
        },
        highlight: function(element) {
            $(element).addClass("highlight").removeClass("valid");
        },
        unhighlight: function(element) {
            $(element).removeClass("highlight").addClass("valid");
        },
    });
    </script>


<?php
include('foot.php');
?>
</body>

</html>