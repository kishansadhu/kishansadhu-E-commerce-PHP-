<?php
 include('ses.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>E-Mobile Shopping Website</title>
</head>

<body class="w3-animate-opacity">

    <style>
    .navbar {
        position: sticky;
        top: 0px;
    }
    </style>

    <?php

    if(isset($_SESSION['reg']) && $_SESSION['reg'] == "login" ||  isset($_SESSION['log']) &&  $_SESSION['log'] == "login"){
      include('navbaru.php');
  }
  else{
      include('navbar.php');
  }
    ?>

    <div class="main-banner header-text" id="top">
        <div class="Modern-Slider">
            <div class="item item-2">
                <div class="img-fill">
                    <div class="text-content">
                        <h6></h6>
                        <h4>Welcom To Our Shop <br></h4>
                        <p>We Sell Best Mobiles .Also Given Best Service To You</p>
                        <a href="products.php" class="filled-button">Shop</a>
                    </div>
                </div>
            </div>

        </div>
    </div>


    <div class="request-form">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                </div>
                <div class="col-md-4">
                </div>
            </div>
        </div>
    </div>
    <style>
    .services img {
        height: 150px;
    }
    </style>

    <div class="services">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading" style="border-bottom:1px solid lightgray">
                        <h2>Our <em>Brands</em></h2>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="service-item">
                        <img src="img/opo.png" alt="">
                    </div>

                </div>
                <div class="col-md-4">
                    <div class="service-item">
                        <img src="img/red.png" alt="">
                    </div>

                </div>
                <div class="col-md-4">
                    <div class="service-item">
                        <img src="img/sam.png" alt="">
                    </div>

                </div>
            </div>
        </div>
    </div>










    <div class="services">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="service-item">
                        <img src="img/vivo.png" alt="">
                    </div>
                    <br>
                </div>
                <div class="col-md-4">
                    <div class="service-item">
                        <img src="img/rel.png" alt="">
                    </div>
                    <br>
                </div>
            </div>
        </div>
    </div>







    <div class="services" style="line-space:5px;">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading" style="border-bottom:1px solid lightgray">
                        <h2>Our <em>Products</em></h2>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div class="container scm">
        <style>
        .services img {
            height: 200px;
        }

        .services .container .service-item:hover {
            position: relative;
            bottom: 0.1px;
            transition: 0.2s;
            box-shadow: 2px 2px 9px 0px black;
        }
        </style>


        <?php
        $s1 = "SELECT * FROM product where u='sam' and id<=3";
        $run =mysqli_query($con,$s1);
        ?>
        <div class="services">
            <center><strong><h2>Samsung</h2></strong></center><br>
            <div class="container content-section w3-animate-opacity" id="sam">
                <div class="row">
                    <?php
            if(mysqli_num_rows($run) >0 ){
              while($f = mysqli_fetch_assoc($run)){
                ?>
                    <div class="col-md-4">
                        <div class="service-item">
                            <div class="down-content">
                                <br><img src="img/<?php echo $f['img']; ?>" alt="" style="height:200px;width:200px;">
                                <hr>
                                <form action="pmanage.php" method="POST">
                                    <p style="font-weight:bold;"><?php echo $f['name']; ?></p>
                                </form>
                            </div>
                        </div>

                        <br>
                    </div>
                    <?php
              }
            }


?>
                </div>
            </div>
        </div>




    </div>


    <div class="container scm">
       
        <?php
        $s2 = "SELECT * FROM product where u='vivo' and id>7 and id<=10";
        $run =mysqli_query($con,$s2);
        ?>
        <div class="services">
        <center><strong><h2>Vivo</h2></strong></center><br>
            <div class="container content-section w3-animate-opacity" id="sam">
                <div class="row">
                    <?php
            if(mysqli_num_rows($run) >0 ){
              while($f = mysqli_fetch_assoc($run)){
                ?>
                    <div class="col-md-4">
                        <div class="service-item">
                            <div class="down-content">
                                <br><img src="img/<?php echo $f['img']; ?>" alt="" style="height:200px;width:200px;">
                                <hr>
                                <form action="pmanage.php" method="POST">
                                    <p style="font-weight:bold;"><?php echo $f['name']; ?></p>
                                </form>
                            </div>
                        </div>

                        <br>
                    </div>
                    <?php
              }
            }


?>
                </div>
            </div>
        </div>


    </div><br>


    <center><a href="products.php" class="filled-button">More Product</a></center>



    <br><br><br>

    <?php
    include('foot.php');
    ?>



</body>

</html>