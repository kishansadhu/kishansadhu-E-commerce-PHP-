<?php
include('ses.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

if(isset($_POST['qur'])){
    $nm = $_POST['cnm'];
    $em = $_POST['cem'];
    $qu = $_POST['cqu'];

    require 'PHPMailer/Exception.php';
    require 'PHPMailer/PHPMailer.php';
    require 'PHPMailer/SMTP.php';

    $mail1 = new PHPMailer(true);

    try {

        // $mail->SMTPDebug = SMTP::DEBUG_SERVER;
        $mail1->isSMTP();                                            //Send using SMTP
        $mail1->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
        $mail1->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail1->Username   = "websitekwebsite@gmail.com";                     //SMTP username
        $mail1->Password   = 'tvscygrvllvqnbrs';                               //SMTP password
        $mail1->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
        $mail1->Port       = 465;                                    //TCP port to connect to; use 587 if you have set SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS

        //Recipients
        $mail1->setFrom($em, $em);
        $mail1->addAddress("websitekwebsite@gmail.com", "Admin");

        $mail1->isHTML(true);
        $mail1->Subject = $em;
        $mail1->Body    = "
        <h2>
        NAME:$nm<br>
        EMAIL:$em<br>
        USER QUERY:<b>$qu</b><br>
        </h2>
        ";

        $mail1->send();
        $ci = "INSERT INTO contact(name,email,ques) VALUES('$nm','$em','$qu')";
        $cr = mysqli_query($con,$ci);

        setcookie("cms","Submitted Successfully",time()+3);
        echo "<script>
        window.location.href = '/myweb/contact.php'
        </script>";

    } catch (Exception $e1) {
        // setcookie("eco","Please Check Your Enternet Connection",time()+3);
        echo "<script>
        alert('Please Check Your Enternet Connection');
        window.location.href = '/myweb/contact.php'
        </script>";
    }
}










if(isset($_POST['go1'])){
    $ose = $_POST['ef1'];
    $ot = rand(100000,999999);


    $so = "SELECT * FROM user where email='$ose' ";
    $sor =mysqli_query($con,$so);
    $sf=mysqli_fetch_assoc($sor);
    if(mysqli_num_rows($sor) > 0 ){
            require 'PHPMailer/Exception.php';
            require 'PHPMailer/PHPMailer.php';
            require 'PHPMailer/SMTP.php';

            //Create an instance; passing true enables exceptions
            $mail = new PHPMailer(true);

            try {
                //Server settings
                //Enable verbose debug output
                // $mail->SMTPDebug = SMTP::DEBUG_SERVER;
                $mail->isSMTP();                                            //Send using SMTP
                $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
                $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
                $mail->Username   = 'websitekwebsite@gmail.com';                     //SMTP username
                $mail->Password   = 'tvscygrvllvqnbrs';                               //SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
                $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS

                //Recipients
                $mail->setFrom('websitekwebsite@gmail.com', 'Mobile Shopping Here');
                $mail->addAddress($ose, $sf['name']);     //Add a recipient


                $mail->isHTML(true);                                  //Set email format to HTML
                $mail->Subject = 'Forget Your Password';
                $mail->Body    = '<center>
                <strong>Hello <b>'.$sf['name'].'</b> You Get Your  Forget Password OTP Here, </strong><br>
                <h2 style="background:yellow;">Your Otp :'.$ot.'</h2>
                </center>';

                $mail->send();
                $ino = "UPDATE user SET otp='$ot',cou=0 where email='$ose' ";
                $ro = mysqli_query($con,$ino);
                $_SESSION['soe']=$ose;
                setcookie("otp","OTP Sended Successfully In Your Email",time()+3);
                echo "<script>
                window.location.href = '/myweb/otp.php'
                </script>";

            } catch (Exception $e) {
                // setcookie("eco","Please Check Your Enternet Connection",time()+3);
                echo "<script>
                alert('Please Check Your Enternet Connection');
                window.location.href = '/myweb/fget.php'
                </script>";
            }
    }
    else{
        setcookie("une","User Dose Not Existe",time()+3);
        echo "<script>
        window.location.href = '/myweb/fget.php'
        </script>";
    }

}








if(isset($_POST['fg'])){
    $ek = $_POST['ef'];
    $pk = $_POST['psf'];

    $sk = $pk;
    $nk = "";
    $n1 = "";

    $mk = array(
        "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z",
        "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
        "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
        "!", "\"", "#", "$", "%", "&", "'", "(", ")", "*", "+", ",", "-", ".", "/", ":", ";", "<", "=", ">", "?", "@", "[", "\\", "]", "^", "_", "`", "{", "|", "}", "~",
        " ", "\t", "\n"
    );
    for($i = 0; $i < strlen($sk); $i++) {
        for($j = 0; $j < count($mk); $j++) {
            if($sk[$i] == $mk[$j]) {
                $nk .= $mk[$j + 3];
            }
        }
    }


        for($i1 = 0; $i1 < strlen($nk); $i1++) {
            for($j1 = 0; $j1 < count($mk); $j1++) {
                if($nk[$i1] == $mk[$j1]) {
                    $n1 .= $mk[$j1 - 3];
                }
            }
        }



    $rs2 = "SELECT * FROM user where email='$ek'";
    $rsr2 =mysqli_query($con,$rs2);
    $rfe = mysqli_fetch_assoc($rsr2);
    $op = $rfe['otp'];

    $rs22 = "SELECT * FROM user where email='$ek'";
    $rsr22 =mysqli_query($con,$rs22);

    if(mysqli_num_rows($rsr22) >0){
        $upd = "UPDATE user SET password='$nk' where email='$ek'";
        $updr=mysqli_query($con,$upd);


        $fname2 = "SELECT * FROM user WHERE email='$ek'";
        $frun2=mysqli_query($con,$fname2);
        $fd2=mysqli_fetch_assoc($frun2);
        $nk1 = $fd2['password'];
        $n111 = "";

        $mk1= array(
            "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z",
            "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
            "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
            "!", "\"", "#", "$", "%", "&", "'", "(", ")", "*", "+", ",", "-", ".", "/", ":", ";", "<", "=", ">", "?", "@", "[", "\\", "]", "^", "_", "`", "{", "|", "}", "~",
            " ", "\t", "\n"
        );

            for($i1 = 0; $i1 < strlen($nk1); $i1++) {
                for($j1 = 0; $j1 < count($mk1); $j1++) {
                    if($nk1[$i1] == $mk1[$j1]) {
                        $n111 .= $mk1[$j1 - 3];
                    }
                }
            }


            $_SESSION['r']['p'] =  $pk ;

        setcookie("pus","Password Updated Successfully",time()+3);
        echo "<script>
            window.location.href = '/myweb/log.php';
            </script>";
    }

}








if(isset($_POST['go11'])){
    $ef2 = $_POST['ef2'];
    $nm2 = $_POST['nm2'];
    $rnd = rand(1000,9999);
    require 'PHPMailer/Exception.php';
    require 'PHPMailer/PHPMailer.php';
    require 'PHPMailer/SMTP.php';

    //Create an instance; passing true enables exceptions
    $mail2 = new PHPMailer(true);

    try {
        //Server settings
        //Enable verbose debug output
        // $mail->SMTPDebug = SMTP::DEBUG_SERVER;
        $mail2->isSMTP();                                            //Send using SMTP
        $mail2->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
        $mail2->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail2->Username   = 'websitekwebsite@gmail.com';                     //SMTP username
        $mail2->Password   = 'tvscygrvllvqnbrs';                               //SMTP password
        $mail2->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
        $mail2->Port       = 465;                                    //TCP port to connect to; use 587 if you have set SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS

        //Recipients
        $mail2->setFrom('websitekwebsite@gmail.com', 'Mobile Shopping Here');
        $mail2->addAddress($ef2, $nm2);     //Add a recipient

        $mail2->isHTML(true);                                  //Set email format to HTML
        $mail2->Subject = 'OTP FOR UPDATE DETAILS';
        $mail2->Body    = '<center>
        <strong>Hello <b>'.$nm2.'</b> You Get Your  Update Mobile & Email OTP here, </strong><br>
        <h2 style="background:yellow;">Your Otp :'.$rnd.'</h2>
        </center>';

        $mail2->send();
        $ino1 = "UPDATE user SET otp='$rnd' where email='$ef2'";
        $ro1 = mysqli_query($con,$ino1);
        setcookie("otp1","OTP Sended Successfully In Your Email",time()+3);
        echo "<script>
        window.location.href = '/myweb/userem1.php'
        </script>";

    } catch (Exception $e) {
        // setcookie("eco","Please Check Your Enternet Connection",time()+3);
        echo "<script>
        alert('Please Check Your Enternet Connection');
        window.location.href = '/myweb/userem.php'
        </script>";
    }

}





if(isset($_POST['fg11'])){
    $ef3 = $_POST['ef3'];
    $psf3 = $_POST['psf3'];
    $pf3 = $_POST['pf3'];
    $em = $_SESSION['r']['e'];

    $rs22 = "SELECT * FROM user where email='$em'";
    $rsr22 =mysqli_query($con,$rs22);
    $rfe2 = mysqli_fetch_assoc($rsr22);
    $op1 = $rfe2['otp'];
    if($ef3 == $rfe2['email'] || $psf3 == $rfe2['mobile']){
        setcookie("onm1","Email Or Mobile Is Aready Registered",time()+3);
        echo "<script>
            window.location.href = '/myweb/userem1.php';
            </script>";
    }
    else{

if($op1 == $pf3){

    $rs22 = "SELECT * FROM user where email='$em' and otp='$op1'";
    $rsr22 =mysqli_query($con,$rs22);

    if(mysqli_num_rows($rsr22) >0){
        $upd111 = "UPDATE user SET email='$ef3',mobile='$psf3',otp='' where email='$em' and otp='$op1'";
        $updr111 =mysqli_query($con,$upd111);

       if($updr111){
        $_SESSION['r']['e'] = $ef3;
        $_SESSION['r']['m'] = $psf3;

        setcookie("pus1","Your Mobile And Email Update Successfully",time()+3);
        echo "<script>
            window.location.href = '/myweb/userem1.php';
            </script>";
       }
    }
    else{
        setcookie("ede1","Email Dosent Exist",time()+3);
        echo "<script>
            window.location.href = '/myweb/userem1.php';
            </script>";
    }

}
else{
    setcookie("onm111","Enter Valid Otp Or <a href='userem.php'>RE-SEND OTP</a>",time()+3);
    echo "<script>
        window.location.href = '/myweb/userem1.php';
        </script>";
}
}

}

























$emvr  = $_SESSION['soe'];

    if(isset($_POST['otp1'])){
        $o = $_POST['otpvr'];
        $selvr = "SELECT * FROM user where otp='$o' ";
        $selkr=mysqli_query($con,$selvr);
        if(mysqli_num_rows($selkr) > 0){
            $sl1k = "UPDATE user SET otp='' where email='$emvr' ";
            $slr1k = mysqli_query($con,$sl1k);
            echo "<script>
            alert('Your OTP Verifiyd Successfully');
            window.location.href = '/myweb/fget1.php'
            </script>";
        }
        else{
            setcookie("evo","Enter Valid OTP",time()+3);
            echo "<script>
            window.location.href = '/myweb/otp.php'
            </script>";
        }
    }


    if(isset($_POST['otp2'])){
    $rnd = rand(100000,999999);
    $sl = "UPDATE user SET otp='$rnd' where email='$emvr' and cou<3";
    $slr = mysqli_query($con,$sl);
    if($slr == 1){
      require 'PHPMailer/Exception.php';
      require 'PHPMailer/PHPMailer.php';
      require 'PHPMailer/SMTP.php';

      //Create an instance; passing true enables exceptions
      $mailvr = new PHPMailer(true);

      try {
          //Server settings
          //Enable verbose debug output
          // $mailvr->SMTPDebug = SMTP::DEBUG_SERVER;
          $mailvr->isSMTP();                                            //Send using SMTP
          $mailvr->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
          $mailvr->SMTPAuth   = true;                                   //Enable SMTP authentication
          $mailvr->Username   = 'websitekwebsite@gmail.com';                     //SMTP username
          $mailvr->Password   = 'tvscygrvllvqnbrs';                               //SMTP password
          $mailvr->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
          $mailvr->Port       = 465;                                    //TCP port to connect to; use 587 if you have set SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS

          //Recipients
          $mailvr->setFrom('websitekwebsite@gmail.com', 'Mobile Shopping Here');
          $mailvr->addAddress($emvr, "user");     //Add a recipient


          $mailvr->isHTML(true);                                  //Set email format to HTML
          $mailvr->Subject = 'RE-Sent OTP';
          $mailvr->Body    = '<center>
          <strong>Hello <b>'.'user'.'</b> You Get Your  Forget Password OTP Here, </strong><br>
          <h2 style="background:yellow;">Your Otp :'.$rnd.'</h2>
          </center>';

          $mailvr->send();
          $ino = "UPDATE user SET otp='$rnd',cou=cou+1 where email='$emvr' ";
          $ro = mysqli_query($con,$ino);
          $_SESSION['soe']=$emvr;
          setcookie("otpr","OTP Re-Sended Successfully In Your Email",time()+3);
          echo "<script>
          window.location.href = '/myweb/otp.php'
          </script>";

      } catch (Exception $e) {
          // setcookie("eco","Please Check Your Enternet Connection",time()+3);
          echo "<script>
          alert('Please Check Your Enternet Connection');
          window.location.href = '/myweb/otp.php'
          </script>";
      }
    }

    else{
        echo "<script>
        window.location.href = 'otp.php'
        </script>";
    }

    }

?>