<?php
include('ses.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
    body {
        z-index: 20;
    }

    .modal {
        z-index: 9000;
        margin-top: 60px;
    }
    </style>
</head>


<body class="w3-animate-opacity">


    <?php
    if(isset($_COOKIE['plg'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-danger alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:100px;">
            <strong><?php echo $_COOKIE['plg']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>

    <?php
    if(isset($_COOKIE['dvr'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-danger alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:100px;">
            <strong><?php echo $_COOKIE['dvr']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>




    <?php
    if(isset($_COOKIE['el'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-danger alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:100px;">
            <strong><?php echo $_COOKIE['el']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>



    <?php
    if(isset($_COOKIE['pus'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:100px;">
            <strong><?php echo $_COOKIE['pus']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>




    <script>
    setTimeout(function() {
        document.getElementById('alt1').style.display = "none";
    }, 3000)
    </script>






    <?php
    if(isset($_SESSION['reg']) && $_SESSION['reg'] == "login" ||  isset($_SESSION['log']) &&  $_SESSION['log'] == "login"){
       echo "
       <script>
       window.location.href = '/myweb/index.php'
       </script>
       ";
   }
   else{
       include('navbar.php');
   }
   ?>


    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="main-banner header-text" id="top1">
        <div class="Modern-Slider">
            <div class="item item-3">
                <div class="img-fill">
                    <div class="text-content">
                    </div>
                </div>
            </div>

        </div>
    </div>
    <br><br><br>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="text-center mb-4">
                </div>
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h2 class="card-title text-center mb-4">Login</h2>
                        <form action="lrm.php" method="post" id="formlog">
                            <div class="form-group">
                                <label for="email">Email Id</label>
                                <input name="e11" class="form-control" id="email" placeholder="john.doe@domain.com"
                                    type="email" aria-invalid="true" />
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                    <input name="p11" class="form-control" id="password" placeholder="Password"
                                        type="password"  aria-invalid="true" maxlength=9 minlength=1 /> <br>
                                <span><input type="checkbox" class="" id="ch" onclick="show()"> Show Password</span>
                                <script>
                                document.getElementById('password').type = "password"

                                function show() {
                                    var x = document.getElementById('password');
                                    if (x.type === "password") {
                                        x.type = "text";
                                    } else {
                                        x.type = "password";
                                    }
                                }
                                </script>
                            </div>
                            <input type="submit" name="log" class="btn btn-primary btn-block" value="Login">
                            <a href="reg.php" class="btn btn-outline-primary btn-block mt-3" type="button">If Already
                                Not have
                                an
                                account? Register</a>
                        </form><br>

                        <a href="fget.php">Forget Password</a><br>

                    </div>
                </div>
            </div>
        </div>
    </div><br><br><br><br>




    <script>
    $.validator.addMethod("allowedDomain", function(value, element) {
        var domain = value.split('@')[1];
        var allowed = ['gmail.com', 'ac.in', 'yourdomain.com'];
        return this.optional(element) || allowed.includes(domain);
    }, "Sirf gmail.com, ac.in ya allowed domains hi valid hain.");


    $("#formlog").validate({
        rules: {
            e11: {
                required: true,
                email: true,
                allowedDomain: true
            },
            p11: {
                required: true,
                minlength: 8,
                maxlength: 12,
                // Regex: kam se kam 1 lowercase, 1 uppercase, 1 digit, 1 special character
                pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%?&])[A-Za-z\d@$!%?&]{8,12}$/
            }
        },
        messages: {
            e11: {
                required: "Please enter email",
                email: "Please enter valid email ",
                allowedDomain: "Please enter valid email"
            },
            p11: {
                required: "Please provide a password",
                minlength: "Password must be exactly 8",
                maxlength: "Password Length less then 12",
                pattern: "Password Formate Ksadhu@1"
            }
        },
        highlight: function(element) {
            $(element).addClass("highlight").removeClass("valid");
        },
        unhighlight: function(element) {
            $(element).removeClass("highlight").addClass("valid");
        }
    });
    </script>

    <?php
    include('foot.php');
    ?>
</body>

</html>