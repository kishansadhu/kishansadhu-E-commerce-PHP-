<?php
include('ses.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My_Dashbord</title>
    <!-- <link rel="stylesheet" href="users.css"> -->
</head>

<body class="w3-animate-opacity bg-light" id="bdy">

    <?php
    if(isset($_COOKIE['orderrecive'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:100px;">
            <strong><?php echo $_COOKIE['orderrecive']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>


    <script>
    setTimeout(function() {
        document.getElementById('alt1').style.display = "none";
    }, 60000)
    </script>

    <?php
    if(isset($_COOKIE['upf'])){
        ?>
    <div class="d-flex flex-row-reverse">
        <div class="container  w-100">
            <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show"
                role="alert" id="alt" style="margin-top:100px;z-index:10000;">
                <strong><?php echo $_COOKIE['upf']; ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
    <?php
    }
    ?>


    <script>
    setTimeout(function() {
        document.getElementById('alt').style.display = "none";
    }, 2000)
    </script>











    <?php

    if(isset($_SESSION['log']) &&  $_SESSION['log'] == "login"){
        include('navbaru.php');
    }
    else{
        echo "<script>
        window.location.href = '/myweb/index.php';
        </script>";
    }


    ?>
    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="main-banner header-text" id="top1">
        <div class="Modern-Slider">
            <div class="item item-3">
                <div class="img-fill">
                    <div class="text-content">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <br><br>

    <?php
    ?>
    <div class="container mt-4 bg-white p-4" style="border-radius:20px;">
        <center class="" style="border-bottom:1px solid lightgray;">
            <span><span style="font-size:30px;color:#a4c639;">M</span><span style="font-size:30px;">y</span>
                <span><span style="font-size:30px;color:#a4c639;">P</span><span
                        style="font-size:30px;">rofile</span></span><br>
        </center><br><br><br>
        <div class="row">
            <div class="col-md-3 col-lg-3" style="padding:20px;">
                <img src="uploads/<?php echo $_SESSION['r']['i'];?>" alt="img" class="img rounded-circle img-thumbnail"
                    style="height:150px;width:150px"><br><br><br>
                <table class="table table-striped">
                    <tr>
                        <th>Action</th>
                        <th></th>
                    </tr>
                    <tr>
                        <?php
                        $em = $_SESSION['r']['e'];
                        $selk1 = "SELECT  * FROM orderp WHERE email='$em'and  stat='complete'";
                        $run = mysqli_query($con,$selk1);
                        $no = mysqli_num_rows($run);

                        $su = "SELECT  * FROM user WHERE email='$em'";
                        $ru = mysqli_query($con,$su);
                        $ft = mysqli_fetch_assoc($ru);




                        $sel6 = "SELECT  *  FROM orderp where email='$em' and stat='cansel'";
                        $run6 = mysqli_query($con,$sel6);
                        $tr6 =mysqli_num_rows($run6) ;


                        $selk1 = "SELECT  *  FROM orders where email='$em' and stat='pendding'";
                        $runk1 = mysqli_query($con,$selk1);
                        $trk =mysqli_num_rows($runk1) ;
                        ?>
                        <td>Completed Orders</td>
                        <td><?php echo $no; ?></td>
                    </tr>
                    <tr>
                        <td>Canseled Orders</td>
                        <td><?php echo $tr6; ?></td>
                    </tr>
                    <tr>
                        <td>Pendding Orders</td>
                        <td><?php echo $trk; ?></td>
                    </tr>
                </table>
            </div>
            <div class="col-md-1 col-lg-1"></div>
            <div class="col-md-8 col-lg-8">
                <div class="nav ">
                    <li>
                        <button data-target="#profile" style="font-size:15px;font-weight:bold;"
                            class="list-group-item list-group-item-action ">Profile</button>
                    </li>
                    <li style="margin-left:5px;">
                        <button data-target="#order" style="font-size:15px;font-weight:bold;"
                            class="list-group-item list-group-item-action">Orders</button>
                    </li>
                    <li style="margin-left:5px;">
                        <button data-target="#updateProfile" style="font-size:15px;font-weight:bold;"
                            class="list-group-item list-group-item-action">Update Profile</button>
                    </li>
                </div><br>
                <br>


                <div id="profile" class="tab-content" style="padding:20px;">
                    <form action="">
                        <div class="row">
                            <div class="div.col-lg-6">
                                <div class="form-group">

                                    <div class="col-xs-6">
                                        <label for="first_name">
                                            <h4>FullName</h4>
                                        </label>
                                        <input type="text" class="form-control" name="n" id="first_name"
                                            placeholder="Enter Your name" title="enter your first name if any." disabled
                                            value="<?php echo $_SESSION['r']['n']; ?>">
                                    </div>
                                </div>

                                <div class="form-group">

                                    <div class="col-xs-6">
                                        <label for="first_name">
                                            <h4>Email</h4>
                                        </label>
                                        <input type="text" class="form-control" name="e" id="first_name"
                                            placeholder="Enter Email" title="enter your first name if any."
                                            value="<?php echo $_SESSION['r']['e']; ?>" disabled>
                                    </div>
                                </div>

                                <div class="form-group">

                                    <div class="col-xs-6">
                                        <label for="password">
                                            <h4>Password</h4>
                                        </label>
                                        <input type="password" class="form-control" name="p" id="password"
                                            value="<?php echo  $_SESSION['r']['p']; ?>" placeholder="password"
                                            title="enter your password." disabled>
                                        <span><input type="checkbox" class="" id="ch" onclick="show()"> Show
                                            Password</span>
                                        <script>
                                        document.getElementById('password').type = "password"

                                        function show() {
                                            var x = document.getElementById('password');
                                            if (x.type === "password") {
                                                x.type = "text";
                                            } else {
                                                x.type = "password";
                                            }
                                        }
                                        </script>
                                    </div>
                                </div>

                            </div>



                            <div class="col-lg-6">
                                <div class="form-group">

                                    <div class="col-xs-6">
                                        <label for="phone">
                                            <h4>Mobile Num</h4>
                                        </label>
                                        <input type="text" class="form-control" name="m" id="phone"
                                            value="<?php echo $_SESSION['r']['m']; ?>" placeholder="Enter Your Mobile"
                                            title="enter your phone number if any." disabled>
                                    </div>

                                </div>

                                <div class="form-group">
                                    <div class="col-xs-6">
                                        <label for="email">
                                            <h4>Address</h4>
                                        </label>
                                        <textarea name="add" class="form-control text-center"
                                            style="text-align: center;" disabled>
                                            <?php
                                            function cleanText($text) {
                                                $text = trim($text);
                                                $text = preg_replace('/\s+/', ' ', $text);
                                                return $text;
                                            }
                                            $adrr = $_SESSION['r']['ad'] ?? '';
                                            echo cleanText($adrr);
                                            ?>
                                        </textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    <hr>
                </div>













                <div id="order" class="tab-content" style="display:none;">
                    <style>
                    img {
                        height: 50px;
                        width: 50px;
                    }
                    </style>
                    <?php
                            $em = $_SESSION['r']['e'];
                            $sel = "SELECT  * FROM orderp WHERE email='$em' and stat!='canseled' and stat!='recived' and stat!='pendding'";
                            $run = mysqli_query($con,$sel);
                            // $fm = mysqli_fetch_assoc($run);

                            // jese hi select ho jaye vese num rows ke wise data add karo table me.
                            echo "
                            <table class='table table-striped table-responsive'>
                                    <tr>
                                    <th>id</th>
                                    <th>img</th>
                                    <th>Name</th>
                                    <th>Prize</th>
                                    <th>Qunitity</th>
                                    <th>Total</th>
                                    <th>Method Way</th>
                                    <th>Statuse</th>
                                    <th>Time</th>
                                    <th>Action</th>
                                    </tr>
                            ";

                            if(mysqli_num_rows($run) > 0){
                                $i = 1;
                                $total_prize= 0;
                                while($f = mysqli_fetch_assoc($run)){
                                    $st = $f['prize'];
                                    $int = (int)str_replace(",","",$st);
                                    $mmn = $f['dt'];
                                    $nmn1 = $f['name'];
                            
                                    $ssl1 = "SELECT * FROM orderp WHERE email='$em' and name='$nmn1' and dt='$mmn' and stat='complete'";
                                    $runf1 = mysqli_query($con, $ssl1);
                            
                                    $ssl11 = "SELECT * FROM orderp WHERE email='$em' and name='$nmn1' and dt='$mmn'";
                                    $runf11 = mysqli_query($con, $ssl11);
                                    $runff = mysqli_fetch_assoc($runf11); // fixed typo here
                            
                                    $m = ($f['qun']) * $int;
                                    $st1 = number_format($m);
                                    $total_prize += $m;
                            
                                    echo "
                                    <tr>
                                    <td>$i</td>
                                    <td><img src='img/{$f['img']}'></td>
                                    <td>{$f['name']}</td>
                                    <td>{$f['prize']}</td>
                                    <td>{$f['qun']}</td>
                                    <td>$st1</td>
                                    <td>{$f['method']}</td>
                                    <td><p style='border-radius:5px;width:70px;' class='bg-primary text-white text-center'>{$f['stat']}</p></td>
                                    <td>{$f['dt']}</td>
                                    ";
                            
                                    if(mysqli_num_rows($runf1) > 0){
                                        echo "
                                        <td>
                                        <form action='user.php' method='post' class='form'>
                                          <input type='submit' name='cl' value='Cansel Order' class='form-control btn btn-danger'>
                                          <input type='hidden' name='clq' value='{$f['qun']}' class='form-control'>
                                          <input type='hidden' name='cln' value='{$f['name']}' class='form-control'>
                                          <input type='hidden' name='cld' value='{$f['dt']}' class='form-control'>
                                        </form>
                                        </td>
                                        ";
                                    } else {
                                        if($runff['stat'] == "recive"){
                                            echo "<td>Order Recived</td>";
                                        } else {
                                            echo "
                                            <td>
                                            <form action='user.php' method='post'>
                                              <input type='submit' name='orm' value='Remove' class='form-control btn btn-danger'>
                                              <input type='hidden' name='orq' value='{$f['qun']}' class='form-control'>
                                              <input type='hidden' name='orn' value='{$f['name']}' class='form-control'>
                                              <input type='hidden' name='ord' value='{$f['dt']}' class='form-control'>
                                            </form>
                                            </td>
                                            ";
                                        }
                                    }
                                    echo "</tr>";
                                    $i++;
                                }
                                $fk = number_format($total_prize);
                                echo "</table>";
                                echo "";
                            }
                            else{
                                Echo "
                                <table>
                                <tr>
                                <h2 class='text-dark'>Not Have Any Order</h2><br>
                                </tr>
                                </table>
                                ";
                            }


                    ?>
                </div>
                <?php
                //  apne city ke mutab
                date_default_timezone_set('Asia/Kolkata');
                $dt= date("Y-m-d H:i:s", time());
                if(isset($_POST['cl'])){
                    $cq = $_POST['clq'];
                    $cn = $_POST['cln'];
                    $cd = $_POST['cld'];

                    $pp1 = "SELECT * FROM product where name='$cn'";
                    $pp2 = mysqli_query($con,$pp1);
                    $pp3 = mysqli_fetch_assoc($pp2);


                    $fq = $pp3['qun'] + $cq;
                    $uors = "UPDATE orderp SET stat='cansel',dt='$dt' where name='$cn' and email='$em' and dt='$cd'";
                    $uorsr = mysqli_query($con,$uors);

                     $int = "UPDATE product SET qun='$fq' where name='$cn'";
                     $irt= mysqli_query($con,$int);

                     echo "<script>
                     alert('This Order Placed But Now you  Cansel  your order ,And  you get your refund within 24-hourse')
                      window.location.href = 'user.php'
                     </script>";
                }

                if(isset($_POST['orm'])){
                    $oq = $_POST['orq'];
                    $on = $_POST['orn'];
                    $od = $_POST['ord'];
                    $mord = "SELECT * FROM orderp where stat='cansel' ";
                    $mordr = mysqli_query($con,$mord);
                    if(mysqli_num_rows($mordr) > 0){
                        $uors = "UPDATE orderp SET stat='canseled' where name='$on' and email='$em' and dt='$od'";
                        $uorsr = mysqli_query($con,$uors);
                    }
                    else{
                        $uors1 = "UPDATE orderp SET stat='recived' where name='$on' and email='$em' and dt='$od'";
                        $uorsr1 = mysqli_query($con,$uors1);
                    }

                    echo "<script>
                    alert('Order Deleted Succesfully')
                    window.location.href = 'user.php'
                    </script>";
                }
                ?>














                <div id="updateProfile" class="tab-content" style="display:none;">
                    <form action="userm.php" method="post" id="formupdate" enctype="multipart/form-data">
                        <div class="row">
                            <div class="div.col-lg-6">
                                <div class="form-group">
                                    <div class="col-xs-6">
                                        <label for="first_name">
                                            <h4>FullName</h4>
                                        </label>
                                        <input type="text" class="form-control" name="n1" id="first_name"
                                            value='<?php echo $ft['name']; ?>' placeholder="Enter Your name"
                                            title="enter your first name if any.">
                                    </div>
                                </div>

                                <div class="form-group">

                                    <div class="col-xs-6">
                                        <label for="email1">
                                            <h4>Email</h4>
                                        </label>
                                        <input type="email" class="form-control" name="e1" id="email1"
                                            value='<?php echo $ft['email']; ?>' readonly placeholder="Enter Email"
                                            title="enter your first name if any.">
                                    </div>
                                </div>

                                <div class="form-group">

                                    <div class="col-xs-6">
                                        <label for="password1">
                                            <h4>Password</h4>
                                        </label>
                                        <input type="password" class="form-control" name="p1" id="password1"
                                            value='<?php echo   $_SESSION['r']['p']; ?>' placeholder="password"
                                            title="enter your password.">
                                    </div>
                                    <span><input type="checkbox" class="" id="ch1" onclick="show1()"> Show
                                        Password</span>
                                    <script>
                                    document.getElementById('password1').type = "password"

                                    function show1() {
                                        var x = document.getElementById('password1');
                                        if (x.type === "password") {
                                            x.type = "text";
                                        } else {
                                            x.type = "password";
                                        }
                                    }
                                    </script>
                                </div>
                            </div>



                            <div class="col-lg-6">
                                <div class="form-group">
                                    <div class="col-xs-6">
                                        <label for="phone1">
                                            <h4>Mobile Num</h4>
                                        </label>
                                        <input type="tel" class="form-control" name="m1" id="phone1" maxlength="10"
                                            value='<?php echo $ft['mobile']; ?>' readonly
                                            placeholder="Enter Your Mobile" title="enter your phone number if any.">


                                    </div>
                                </div>

                                <div class="form-group">

                                    <div class="col-xs-6">
                                        <label for="">
                                            <h4>Address</h4>
                                        </label>
                                        <textarea name="add1" class="form-control">
                                        <?php
                                            $adrr1 = $_SESSION['r']['ad'] ?? '';
                                            echo cleanText($adrr1);
                                            ?>
                                        </textarea>
                                    </div>
                                </div>
                                <div class="form-group">

                                    <div class="col-xs-6">
                                        <label for="password2">
                                            <h4>Profile Picture</h4>
                                        </label>
                                        <input type="file" class="form-control" name="f11">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <input type="submit" name="upd" class="btn btn-lg btn-success" value="Update Details">
                    </form>
                    <hr>
                    <a href="userem.php">Update Mobile & Email</a>
                </div>
            </div>
        </div>
    </div>




    <script>
    // Simple script to toggle between sections
    $('.list-group-item').click(function() {
        $('.tab-content').hide();
        const target = $(this).attr('data-target');
        $(target).show();
        $('.list-group-item').removeClass('active');
        $(this).addClass('active');
    });
    </script>


    <script>
    $("#formupdate").validate({
        rules: {
            n1: {
                required: true
            },
            e1: {
                required: true,
                email: true
            },
            p1: {
                required: true,
                minlength: 8,
                maxlength: 12,
                // Regex: kam se kam 1 lowercase, 1 uppercase, 1 digit, 1 special character
                pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%?&])[A-Za-z\d@$!%?&]{8,12}$/
            },
            m1: {
                required: true,
                maxlength: 10
            },
            f1: {
                required: true,
                accept: "image/*",
                fileSize: 100 * 1024
            },
            add1: {
                required: true
            }

        },
        messages: {
            n1: {
                required: "Please enter your full name"
            },
            e1: {
                required: "Please enter email",
                email: "Please enter valid email "
            },
            p1: {
                required: "Please provide a password",
                minlength: "Password must be exactly 8",
                maxlength: "Password Length less then 12",
                pattern: "Password Formate Ksadhu@1"
            },
            m1: {
                required: "Enter Mobile Num",
                maxlength: "Max Length 10"
            },
            f1: {
                required: "Please Select New Img",
                accept: "Upload Onley jpeg,png,svg..",
                fileSize: "File Maximum Size 100KB"
            },
            add1: {
                required: "Enter Your Address"
            }
        },
        highlight: function(element) {
            $(element).addClass("highlight").removeClass("valid");
        },
        unhighlight: function(element) {
            $(element).removeClass("highlight").addClass("valid");
        }
    });
    </script>


    </div>

    <br><br><br><br><br><br><br><br>

    <?php
include('foot.php');
?>
</body>

</html>