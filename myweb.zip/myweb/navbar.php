<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="/myweb/plug/bootstrap-4.0.0-dist/css/bootstrap.min.css">


    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/owl.css">

    <style>
    /* this is for the form error */
    label.error {
        border-radius: 5px;
        color: red;
    }

    .error {
        margin-top: 1.5px;
        color: red;
        font-size: 15px;
        font-weight: 500;
    }

    .highlight {
        border: 2px solid rgb(252, 150, 150);
    }

    .valid {
        border: 2px solid green;

    }
    .modal{
        z-index:9000;
    }
    body.modal-open {
        overflow: visible !important;
        padding-right: 0 !important;
    }

    </style>
</head> 
<script src="/myweb/plug/js/jquery-3.7.1.min.js"></script>
<script src="/myweb/plug/js/jquery.validate.js"></script>
<script src="/myweb/plug/js/additional-methods.js"></script>

<script src="/myweb/plug/bootstrap-4.0.0-dist/js/bootstrap.bundle.js"></script>

<body>

    <header class="">
        <style>
            form .form-control{
             background: #F8F8FA;
      }
      body{
        background: #F8F8FA;
      }
        </style>
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <span class="navbar-brand" href="index.php">
                    <h2>Mobile Store<em></em></h2>
                </span>
                <button class="navbar-toggler" style="border-radius:15px;" type="button" data-toggle="collapse" data-target="#navbarResponsive"
                    aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="#" style="visibility:hidden;">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="products.php">Products</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="cmp.php">Compare Products</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact Us</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="dropdown-toggle nav-link" data-toggle="dropdown" href="#" role="button"
                                aria-haspopup="true" aria-expanded="false" data-target="#open">Login / Register</a>

                            <div class="dropdown-menu" id="open">
                                <a class="dropdown-item" href="log.php">Login</a>
                                <a class="dropdown-item" href="reg.php">Register</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>






<style>
    input.filled-button:hover{
        border:none;
    }
    a.filled-button:hover{
        border:none;
    }
</style>
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/slick.js"></script>
    <script src="assets/js/accordions.js"></script>


</body>

</html>