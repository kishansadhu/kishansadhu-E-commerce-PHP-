<?php
include('ses.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Contact Page</title>

</head>

<body class="w3-animate-opacity">
    <?php
    if(isset($_COOKIE['cms'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert  alert-success alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:100px;">
            <strong><?php echo $_COOKIE['cms']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>




    <script>
    setTimeout(function() {
        document.getElementById('alt1').style.display = "none";
    }, 3000)
    </script>












    <?php
  if(isset($_SESSION['reg']) && $_SESSION['reg'] == "login" ||  isset($_SESSION['log']) &&  $_SESSION['log'] == "login"){
    include('navbaru.php');
}
else{
    include('navbar.php');
}
  ?>

    <div class="main-banner header-text" id="top1">
        <div class="Modern-Slider">
            <div class="item item-3">
                <div class="img-fill">
                    <div class="text-content">
                    </div>
                </div>
            </div>

        </div>
    </div>



    <div class="contact-information">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="contact-item">
                        <i class="fa fa-phone"></i>
                        <h4>Phone</h4>
                        <p>Fill Free To Contact Us Any Time</p>
                        <a href="#">1234567890</a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="contact-item">
                        <i class="fa fa-envelope"></i>
                        <h4>Email</h4>
                        <p>We Always With You If Any Qustion To sent Throw Email</p>
                        <a href="#">websitekwebsite@gmail.com</a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="contact-item">
                        <i class="fa fa-shield"></i>
                        <h4>Service</h4>
                        <p>24 x 7 We Provide Our Service</p>
                        <a href="#">E Commerse</a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <br>
    <hr><br>




    <div class="container">
        <center>
            <span><span style="font-weight:bold;font-family: monospace;font-size:30px;color:#a4c639;">S</span><span
                    style="font-weight:bold;font-family: monospace;font-size:30px;">end</span>
                <span><span style="font-weight:bold;font-family: monospace;font-size:30px;color:#a4c639;">U</span><span
                        style="font-weight:bold;font-family: monospace;font-size:30px;">s</span></span>
                <span><span style="font-weight:bold;font-family: monospace;font-size:30px;color:#a4c639;">a</span><span
                        style="font-weight:bold;font-family: monospace;font-size:30px;"> </span></span>

                <span><span style="font-weight:bold;font-family: monospace;font-size:30px;color:#a4c639;">M</span><span
                        style="font-weight:bold;font-family: monospace;font-size:30px;">essage</span></span>
            </span>
        </center><br>
        <form action="fgetm.php" method="post" id="fque">
            <div class="form-group">
                <label for="name">Name</label>
                <input name="cnm" class="form-control" id="name" placeholder="John Doe" type="text" />
            </div>
            <div class="form-group">
                <label for="email">Email Id</label>
                <input name="cem" class="form-control" id="email" placeholder="john.doe@domain.com" type="email" />
            </div>

            <div class="form-group">
                <label for="confirm-password">What's Your Query</label>
                <textarea name="cqu" class=" form-control"></textarea>
            </div>

            <input type="submit" class="btn btn-primary btn-block" name="qur" value="Submit">

        </form>
        <script>
        $("#fque").validate({
            rules: {
                cnm: {
                    required: true
                },
                cem: {
                    required: true,
                    email: true
                },
                cqu: {
                    required: true
                }

            },
            messages: {
                cnm: {
                    required: "Please enter your full name"
                },
                cem: {
                    required: "Please enter email",
                    email: "Please enter valid email "
                },
                cqu: {
                    required: "Write Your Query Here"
                }
            },
            highlight: function(element) {
                $(element).addClass("highlight").removeClass("valid");
            },
            unhighlight: function(element) {
                $(element).removeClass("highlight").addClass("valid");
            }
        });
        </script>
    </div>
    <br><br><br>
    <?php
  include('foot.php');
  ?>

</body>

</html>