<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Orders</title>
</head>

<body>

    <?php
    if(isset($_COOKIE['ao'])){
        ?>
    <div class="container  w-100">
        <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show" role="alert"
            id="alt" style="z-index:10000;">
            <strong><?php echo $_COOKIE['ao']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>

    <?php
    if(isset($_COOKIE['do'])){
        ?>
    <div class="container  w-100">
        <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show" role="alert"
            id="alt" style="z-index:10000;">
            <strong><?php echo $_COOKIE['do']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>

    <?php
    if(isset($_COOKIE['eo'])){
        ?>
    <div class="container  w-100">
        <div class="fixed-top container w3-animate-right alert alert-danger alert-dismissible fade show" role="alert"
            id="alt" style="z-index:10000;">
            <strong><?php echo $_COOKIE['eo']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>

    <?php
    if(isset($_COOKIE['uo'])){
        ?>
    <div class="container  w-100">
        <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show" role="alert"
            id="alt" style="z-index:10000;">
            <strong><?php echo $_COOKIE['uo']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>











    <?php
    include('admin.php');
    ?><br><br><br>

    <div class="container card w3-animate-opacity" style="padding:20px;border-radius:20px;">
        <span><span style="font-weight:bold;font-family: monospace;font-size:30px;color:#a4c639;">U</span><span
                style="font-weight:bold;font-family: monospace;font-size:30px;">sers</span>
            <span><span style="font-weight:bold;font-family: monospace;font-size:30px;color:#a4c639;">O</span><span
                    style="font-weight:bold;font-family: monospace;font-size:30px;">rders</span></span>
        </span>
        <div class="d-flex flex-row-reverse">
            <button style="width:100px;" type="button" class="btn btn-success" data-toggle="modal" data-target="#ord">
                Add Orders
            </button>
        </div>
        <br>
        <style>
            img{
                height:50px;
                width:50px;
            }
        </style>
        <?php
                $selo = "SELECT  * FROM orderp";
                $runo = mysqli_query($con,$selo);
                // $fm = mysqli_fetch_assoc($run);

                // jese hi select ho jaye vese num rows ke wise data add karo table me.
                echo "<table class='container table table-striped table-responsive' style='font-size:16px;font-weight:bold;'>
                        <tr>
                        <th>id</th>
                        <th>image</th>
                        <th>Name</th>
                        <th>Prize</th>
                        <th>Qun</th>
                        <th>Total</th>
                        <th>Statuse</th>
                        <th>Method</th>
                        <th>Address</th>
                        <th>Time</th>
                        <th>Email</th>
                        <th>Edit</th>
                        <th>Action</th>
                        </tr>
                ";

                if(mysqli_num_rows($runo) > 0){
                    $i = 1;
                    while($f = mysqli_fetch_assoc($runo)){
                        $st = $f['prize'];
                        $int = (int)str_replace(",","",$st);


                        $m = ($f['qun'] ) * $int;
                        $st1 = number_format($m);
                        // $i mens all item starting from 1
                        // f[prize] ke niche jo form he usme muje jo qun he usme uske total prize ke liye likha he
                        echo"
                        <tr>
                        <td>$i</td>
                        <td><img src='img/$f[img]'></td>
                        <td>$f[name]</td>
                        <td>$f[prize]</td>
                        <td>$f[qun]</td>
                        <td>$st1</td>
                        <td><p style='border-radius:5px;width:70px;' class='bg-primary text-white text-center'>$f[stat]</p></td>
                        <td>$f[method]</td>
                        <td>$f[adr]</td>
                        <td>$f[dt]</td>
                        <td>$f[email]</td>
                        <td>
                        <form action='oma1.php' method='post'>
                            <input type='submit' name='up1' class='btn btn-success' value='Edit'>
                            <input type='hidden' name='up' value='$f[email]'>
                            <input type='hidden' name='up2' value='$f[name]'>
                        </form>
                        </td>
                        <td>
                        <form action='oma.php' method='post'>
                            <input type='submit' name='rm1' class='btn btn-danger' value='Remove'>
                            <input type='hidden' name='rm' value='$f[name]'>
                            <input type='hidden' name='rm2' value='$f[email]'>
                            <input type='hidden' name='rm3' value='$f[prize]'>
                            <input type='hidden' name='rm4' value='$f[qun]'>
                            <input type='hidden' name='rm5' value='$i'>
                        </form>
                        </td>
                        </tr>
                        ";
                        $i =  $i + 1;
                    }
                    echo "</table>";
                }
                else{
                    Echo "
                    <table>
                    <tr>
                    <center style='font-weight:bold'><h2 class='text-dark'>Dosen't Have Any Orders</h2></center><br>
                    </tr>
                    </table>
                    ";

                }

                ?>
        <hr><br>




        <div class="modal fade" id="ord">
            <div class="modal-dialog" role="document">
                <div class="modal-content bg-light text-dark">
                    <div class="modal-header">
                        <h3>Add New Order</h3>
                    </div>
                    <div class="modal-body">
                        <form action="oma.php" method="post" id="ford" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input name="on" class="form-control" id="name" type="text" />
                            </div>
                            <div class="form-group">
                                <label for="email">Prize</label>
                                <input name="op" class="form-control" id="quantity" type="text" />
                            </div>
                            <div class="form-group">
                                <label for="password">Quntity</label>
                                <input name="oq"  id="quantity1"  class="form-control"  type="text" />

                            </div>
                            <div class="form-group">
                                <label for="confirm-password">Order Total</label>
                                <input name="otot" class="form-control" id="quantity2" type="text" />

                            </div>

                            <div class="form-group">
                                <label for="confirm-password">Order Statuse</label>
                                <input name="os" class="form-control" type="text" />

                            </div>

                            <div class="form-group">
                                <label for="confirm-password">Order Method</label>
                                <input name="ome" class="form-control" type="text" />

                            </div>

                            <div class="form-group">
                                <label for="confirm-password">Order Email</label>
                                <input name="oe" class="form-control" type="email" />
                            </div>

                            <input type="submit" class="btn btn-success btn-block" name="addo" value="Add New Order">
                        </form>
                        <script>
                        // Simple jQuery to allow only numbers
                        $('#quantity').on('input', function() {
                            // Replace non-numeric characters with an empty string
                            $(this).val($(this).val().replace(/[^0-9]/g, ''));
                        });
                        </script>
                        <script>
                        // Simple jQuery to allow only numbers
                        $('#quantity1').on('input', function() {
                            // Replace non-numeric characters with an empty string
                            $(this).val($(this).val().replace(/[^0-9]/g, ''));
                        });
                        </script>
                        <script>
                        // Simple jQuery to allow only numbers
                        $('#quantity2').on('input', function() {
                            // Replace non-numeric characters with an empty string
                            $(this).val($(this).val().replace(/[^0-9]/g, ''));
                        });
                        </script>

                        <script>
                        $("#ford").validate({
                            rules: {
                                on: {
                                    required: true
                                },
                                op: {
                                    required: true,
                                },
                                oq: {
                                    required: true
                                },
                                otot: {
                                    required: true
                                },
                                os: {
                                    required: true
                                },
                                ome: {
                                    required: true
                                },
                                oe: {
                                    required: true,
                                    email: true
                                }

                            },
                            messages: {
                                on: {
                                    required: "enter Orde name"
                                },
                                op: {
                                    required: "enter order prize"
                                },
                                oq: {
                                    required: "enter order quntity"
                                },
                                otot: {
                                    required: "enter order total"
                                },
                                os: {
                                    required: "enter order statuse"
                                },
                                ome: {
                                    required: "enter order method"
                                },
                                oe: {
                                    required: "enter order email",
                                    email: "enter valid email"
                                }
                            },
                            highlight: function(element) {
                                $(element).addClass("highlight").removeClass("valid");
                            },
                            unhighlight: function(element) {
                                $(element).removeClass("highlight").addClass("valid");
                            }
                        });
                        </script>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div><br><br><br>
    <script>
    setTimeout(function() {
        document.getElementById('alt').style.display = "none";
    }, 2000)
    </script>
</body>

</html>