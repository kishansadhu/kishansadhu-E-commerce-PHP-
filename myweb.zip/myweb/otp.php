<?php
include("ses.php");
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, inherit-scale=1.0">
    <title>OTP Verify</title>
</head>

<body>

    <?php
    if(isset($_COOKIE['otp'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:100px;">
            <strong><?php echo $_COOKIE['otp']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>

    <?php
    if(isset($_COOKIE['evo'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-danger alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:100px;">
            <strong><?php echo $_COOKIE['evo']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>



    <?php
    if(isset($_COOKIE['oex'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-danger alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:100px;">
            <strong><?php echo $_COOKIE['oex']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>

    <?php
    if(isset($_COOKIE['otpr'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:100px;">
            <strong><?php echo $_COOKIE['otpr']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>




    <script>
    setTimeout(function() {
        document.getElementById('alt1').style.display = "none";
    }, 3000)
    </script>





    <?php
    if(isset($_SESSION['reg']) && $_SESSION['reg'] == "login" ||  isset($_SESSION['log']) &&  $_SESSION['log'] == "login"){
       echo "
       <script>
       window.location.href = '/myweb/indefgetm.php'
       </script>
       ";
   }
   else{
       include('navbar.php');
   }
   ?>


    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="main-banner header-text" id="top1">
        <div class="Modern-Slider">
            <div class="item item-3">
                <div class="img-fill">
                    <div class="text-content">
                    </div>
                </div>
            </div>

        </div>
    </div>
    <br><br><br>


    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="text-center mb-4">
                </div>
                <div class="card shadow-sm">
                    <div class="card text-danger p-1">
                        <center>
                            <h5 id="timer"></h5>
                        </center>
                    </div>
                    <div class="card-body">
                        <h2 class="card-title text-center mb-4">OTP Verify</h2>
                        <hr>
                        <form action="fgetm.php" method="post" id="formotp">
                            <div class="form-group">
                                <label for="email">OTP Verify</label>
                                <input name="otpvr" class="form-control" id="pass" placeholder="Enter OTP" type="text"
                                    maxlength="6" />
                            </div><br>

                            <button class="btn btn-primary" name="otp1" id="otp1" type="submit">Verify</button>
                        </form><br>

                        <form action="fgetm.php" method="post" id="resendForm">
                            <input type="hidden" name="otp2" value="1">
                            <button class="btn btn-primary" name="otp2_btn" id="otp2" type="submit">Resend OTP</button>
                        </form>
                        <script>

                        $("#formotp").validate({
                            rules: {
                                otpvr: {
                                    required: true
                                }
                            },
                            messages: {
                                otpvr: {
                                    required: "Enter OTP"
                                }
                            },
                            highlight: function(element) {
                                $(element).addClass("highlight").removeClass("valid");
                            },
                            unhighlight: function(element) {
                                $(element).removeClass("highlight").addClass("valid");
                            },
                        });
                        </script>


                    </div>
                </div>
            </div>
        </div>
    </div><br><br><br><br>
    <?php
    $em= $_SESSION['soe'];
    if(isset($_SESSION['soe'])){
        $sl = "SELECT * FROM user WHERE email='$em' and cou >= 3";
    $s = mysqli_query($con,$sl);
    if(mysqli_num_rows($s)){
        ?>
    <script>
    document.getElementById('otp2').type = 'button';

    document.getElementById('otp2').onclick = function() {
        alert("Your Next OTP Genrate After 24 Hours .You Use Previous OTP");
    };
    </script>
    <?php
    }
    }
    else{
        echo "
        <script>
        window.location.href = 'fget.php'
        </script>
        ";
    }

?>




    <?php
    include("foot.php");
    ?>
</body>

</html>