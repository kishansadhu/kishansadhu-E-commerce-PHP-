<?php
include('ses.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
</head>

<body>
    <?php

if(isset($_SESSION['reg']) && $_SESSION['reg'] == "login" ||  isset($_SESSION['log']) &&  $_SESSION['log'] == "login"){
    include('navbaru.php');
}
else{
    echo "<script>
    window.location.href = '/myweb/index.php';
    </script>";
}

?>
    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="main-banner header-text" id="top1">
        <div class="Modern-Slider">
            <div class="item item-3">
                <div class="img-fill">
                    <div class="text-content">
                    </div>
                </div>
            </div>

        </div>
    </div>

    <br><br><br><br><br>






    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="text-center mb-4">
                </div>
                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="container">
                            <center>
                                <h1><em style="color:#1E1E1E;">My</em> <em style="color:#A4C639;">Products</em></h1>
                                <hr><br>
                            </center>
                            <?php
                            if(isset($_SESSION['cr'])){
                                 $_SESSION['cr'];
                               }
                               else{
                                 $_SESSION['cr'] = "Remove";
                               }
                                ?>
                            <style>
                            img {
                                height: 50px;
                                width: 50px;
                            }
                            </style>
                            <?php
                              $em = $_SESSION['r']['e'];
                              $sel = "SELECT  * FROM orders WHERE email='$em'";
                              $run = mysqli_query($con,$sel);

                              // $fm = mysqli_fetch_assoc($run);

                              // jese hi select ho jaye vese num rows ke wise data add karo table me.
                              echo "<table class='container table table-striped table-responsive'>
                                      <tr>
                                      <th>id</th>
                                      <th>Image</th>
                                      <th>Name</th>
                                      <th>Prize</th>
                                      <th>Qunitity</th>
                                      <th>Total</th>
                                      </tr>
                              ";

                              if(mysqli_num_rows($run) > 0){
                                  $i = 1;
                                  $total_prize= 0;
                                  while($f = mysqli_fetch_assoc($run)){
                                      $st = $f['prize'];
                                      $int = (int)str_replace(",","",$st);


                                      $m = ($f['qun'] ) * $int;
                                      $st1 = number_format($m);
                                      $total_prize = $total_prize + $m;
                                      // $i mens all item starting from 1
                                      // f[prize] ke niche jo form he usme muje jo qun he usme uske total prize ke liye likha he
                                      echo"
                                      <tr>
                                      <td>$i</td>
                                       <td><img src='img/$f[img]'></td>
                                      <td>$f[name]</td>
                                      <td>$f[prize]</td>
                                      <td>
                                      $f[qun]
                                      </td>
                                      <td>$st1</td>
                                      </tr>
                                      ";
                                      $i =  $i + 1;
                                  }
                                  $fo =number_format($total_prize);
                                  echo "</form></table>";
                                  echo "
                                  <table class='table table-responsive table-striped'>
                                  <tr>
                                      <th>Total Prize</th>
                                      <th>$fo</th>
                                      <th></th>
                                      <th></th>
                                      <th></th>
                                      <th></th>
                                  </tr>
                                  </table>
                                  ";
                                  ?>
                            <?php

                              }
                              else{
                                  Echo "
                                  <table>
                                  <tr>
                                  <center><h2 class='text-dark text-center' style='font-weight:bolder;'>You Not Have Any Product To By</h2></center><br>
                                  </tr>
                                  </table>
                                  ";
                              }

                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <br><br>
    <hr><br><br>

    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="text-center mb-4">
                </div>
                <div class="card shadow-sm">
                    <div class="card-body">
                        <center>
                            <h1><em style="color:#1E1E1E;"></em> <em style="color: #A4C639;">Payment</em></h1>
                            <hr><br>
                        </center>
                        <center style="border-radius:10px;font-weight:bold;" class="bg-success text-white"> Your Coupen
                            Code Applide You Getting 10% Discount( <span style="color:rgb(234, 247, 46);">Life
                                Time</span> )</center><br>

                        <form action="checkout1.php" method="post" id="pym">
                            <div class="form-group">
                            <?php
                                $a = mysqli_num_rows($run);
                                    if(mysqli_num_rows($run) == 0){
                                        echo " ";
                                    }
                                    else{
                                    $em1 = $_SESSION['r']['e'];
                                    $sel11 = "SELECT  * FROM orders WHERE email='$em1' and stat='pendding'";
                                    $run11 = mysqli_query($con,$sel11);
                                        $i=1;
                                        $tt= 0;
                                    if(mysqli_num_rows($run11)){
                                        while($f = mysqli_fetch_assoc($run11)){
                                            $st1 = $f['prize'];
                                            $int1 = (int)str_replace(",","",$st);

                                            $m1 = ($f['qun'] ) * $int1;
                                            $st11 = number_format($m1);
                                            $tt = $tt + $m1;
                                            $i++;
                                        }
                                    }
                                    }
                                     ?>
                            </div>


                            <div class="form-group">
                                <label> Your Name</label>
                                <input type="text" name="pn" class="form-control">
                            </div>

                            <div class="form-group">
                                <label> Your Email</label>
                                <input type="email" name='pe' readonly class="form-control" value="
                                    <?php

                                    if(isset($_SESSION['r']['e'])){
                                        echo $_SESSION['r']['e'];
                                    }
                                    else{
                                        echo " ";
                                    }
                                    ?>" name='pe'>
                                </textarea>
                            </div>



                            <div class="form-group">
                                <label>Products Prize</label>
                                <input type="text" name="pfp" id="onewe" class="form-control" value="<?php
                                $a = mysqli_num_rows($run);
                                    if(mysqli_num_rows($run) == 0){
                                        echo "0";
                                    }
                                    else{
                                    $em1 = $_SESSION['r']['e'];
                                    $sel11 = "SELECT  * FROM orders WHERE email='$em1' and stat='pendding'";
                                    $run11 = mysqli_query($con,$sel11);
                                    if(mysqli_num_rows($run11)){
                                            $i = 1;
                                            $tp=0;
                                            while($f = mysqli_fetch_assoc($run11)){
                                                $st = $f['prize'];
                                                $int = (int)str_replace(",","",$st);


                                                $m = ($f['qun'] ) * $int;
                                                $st1 = number_format($m);
                                                $tp = $tp + $m;

                                    }
                                    echo number_format($tp);
                                }
                            }
                                     ?>" readonly>
                            </div>





                            <div class="form-group">
                                <label>Coupen Code</label>
                                <input type="text" name="pcup" id="two" class="form-control" value="<?php
                                $sel1 = "SELECT  * FROM user WHERE email='$em'";
                                $run1 = mysqli_query($con,$sel1);
                                $f10 = mysqli_fetch_assoc($run1);

                                 if(mysqli_num_rows($run1) == 0){
                                    echo "0";
                                }
                                else{
                                        echo $f10['cup'];
                                }
                                ?>" readonly>
                            </div>
                            <div class="form-group">
                                <label>Final Amount</label>
                                <input type="text" name="pamu" id="two" class="form-control" value="<?php
                                 if(mysqli_num_rows($run) == 0){
                                    echo "0";
                                }
                                else{
                                       $fc = ($tt * 10) / 100;
                                       $fcr =  $tt - $fc;
                                       echo number_format($fcr);
                                        // yahape ham orders ki jo 0 prize vale ko target karna he
                                        // echo  "<input type='text' name='pup' value='$f[prize]'>";

                                }
                                ?>" readonly>
                            </div>


                            <div class="form-group">
                                <textarea name="pad" id="" readonly>
                                    <?php
                                    function cleanText($text) {
                                        $text = trim($text);
                                        $text = preg_replace('/\s+/', ' ', $text);
                                        return $text;
                                    }
                                    $address = $_SESSION['r']['ad'] ?? '';

                                    if(isset($_SESSION['r']['ad'])){
                                        echo $address;
                                    }
                                    else{
                                        echo "-";
                                    }
                                    ?>
                                </textarea>
                            </div>

                            <div class="form-group">
                                <label>Payment Method</label>
                                <select class="form-control" name="pm" id="payment_method" required>
                                    <option value="Case On Delivary">Case On Delivary</option>
                                    <option value="Pay Now">Pay Now</option>
                                </select>
                            </div>

                            <!-- <input type="submit" class="btn btn-success" name="ps" value="Pay Now"> -->
                            <input type="submit" class="btn btn-success btn-block" name="pays" value="Paymet">

                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
date_default_timezone_set('Asia/Kolkata');
$dt = date("Y-m-d H:i:s", time());

if(isset($_POST['pays'])){
    $pkd = $_POST['pad'] ;
    $a = $pkd ?? '';
    $m = $_POST['pm'];
    $nm = $_POST['pn'];

    if($_POST['pamu'] == 0){
        echo "
        <script>
        alert('Please Add Mobiles Before Making a Payment');
        window.location.href ='checkout.php';
        </script>
        ";
    } else {
        $adr = mysqli_real_escape_string($con, $_POST['pad']);
        $em1 = $_SESSION['r']['e'];

        $upd = "UPDATE orderp SET stat='complete', method='$m', adr='$a', dt='$dt' WHERE email='$em1' AND stat='pendding'";
        mysqli_query($con, $upd);

        $del = "DELETE FROM orders WHERE email='$em1'";
        mysqli_query($con, $del);

        echo "
        <script>
            alert('Payment Successful! Your order will be delivered in 1-2 working days.');
            window.location.href ='checkout1.php';
        </script>
        ";
    }
}



?>







    <script>
    $("#pym").validate({
        rules: {
            pn:{
                required:true
            },
            pm: {
                required: true
            }
        },
        messages: {
            pn:{
                required:"Please Enter Your Name"
            },
            pm: {
                required: "Please Select Method"
            }
        },
        highlight: function(element) {
            $(element).addClass("highlight").removeClass("valid");
        },
        unhighlight: function(element) {
            $(element).removeClass("highlight").addClass("valid");
        }
    });
    </script>

    <br><br><br><br><br><br><br><br>
    <?php
    include("foot.php");
    ?>
</body>

</html>