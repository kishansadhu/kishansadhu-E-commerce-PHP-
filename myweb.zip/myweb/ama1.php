<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Details</title>
</head>

<body>
    <?php
   include('admin.php');


    if(isset($_POST['up'])){
        $e = $_POST['up1'];
        $_SESSION['ue'] = $e;

        $seld = "SELECT  * FROM  admin where email='$e' ";
        $rund = mysqli_query($con,$seld);
        $fd = mysqli_fetch_assoc($rund);
    }
    else{
        echo "<script>
        window.location.href ='/myweb/ada.php'
        </script>";
    }


   ?>
    <br><br>
    <div class="container card" style="padding:20px;border-radius:20px;">
        <h2>Edit Details</h2>
        <hr><br>
        <form action="ama2.php" method="post" id="fadm" enctype="multipart/form-data">

            <div class="form-group">
                <label for="name">Name</label>
                <input name="an" class="form-control" id="name" type="text" value='<?php echo $fd['name']; ?>' />
            </div>
            <div class="form-group">
                <label for="name">Email</label>
                <input name="ae" class="form-control" id="name" type="email" value='<?php echo $fd['email']; ?>' readonly/>
            </div>
            <div class="form-group">
                <label for="name">Password</label>
                <input name="ap" class="form-control" id="apass" type="password"
                    value='<?php echo $fd['password']; ?>' />
            </div>
            <span><input type="checkbox" class="" id="ch4" onclick="show4()"> Show
                Password</span>
            <script>
            document.getElementById('apass').type = "password"

            function show4() {
                var x = document.getElementById('apass');
                if (x.type === "password") {
                    x.type = "text";
                } else {
                    x.type = "password";
                }
            }
            </script><br><br>

            <input type="submit" class="btn btn-success btn-block" name="addadm" value="Update Details">
        </form>

        <script>
        $("#fadm").validate({
            rules: {
                an: {
                    required: true
                },
                ae: {
                    required: true,
                    email: true
                },
                ap: {
                    required: true,
                    minlength: 8,
                    maxlength: 12,
                    // Regex: kam se kam 1 lowercase, 1 uppercase, 1 digit, 1 special character
                    pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%?&])[A-Za-z\d@$!%?&]{8,12}$/
                }

            },
            messages: {
                an: {
                    required: "Please enter your full name"
                },
                ae: {
                    required: "Please enter Prize",
                    email: "Enter Valid Email"
                },
                ap: {
                    required: "Please provide a password",
                    minlength: "Password must be exactly 8",
                    maxlength: "Password Length less then 12",
                    pattern: "Password Formate Ksadhu@1"
                }
            },
            highlight: function(element) {
                $(element).addClass("highlight").removeClass("valid");
            },
            unhighlight: function(element) {
                $(element).removeClass("highlight").addClass("valid");
            }
        });
        </script>
    </div>



</body>

</html>