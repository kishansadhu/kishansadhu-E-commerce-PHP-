<?php
include('ases.php');
session_destroy();
echo "<script>
        window.location.href = '/myweb/index.php';
</script>";
?>