<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Query</title>
</head>

<body>
    <?php
    if(isset($_COOKIE['delq'])){
        ?>
    <div class="d-flex flex-row-reverse">
        <div class="container  w-100">
            <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show"
                role="alert" id="alt" style="z-index:10000;">
                <strong><?php echo $_COOKIE['delq']; ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
    <?php
    }
    ?>


    <?php
    if(isset($_COOKIE['uqadd'])){
        ?>
    <div class="d-flex flex-row-reverse">
        <div class="container  w-100">
            <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show"
                role="alert" id="alt" style="z-index:10000;">
                <strong><?php echo $_COOKIE['uqadd']; ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
    <?php
    }
    ?>








    <?php
    include('admin.php');
    ?><br><br><br>
    <div class="container card w3-animate-opacity" style="padding:20px;border-radius:20px;">
        <span><span style="font-weight:bold;font-family: monospace;font-size:30px;color:#a4c639;">Q</span><span
                style="font-weight:bold;font-family: monospace;font-size:30px;">uerys</span></span>

        <div class="d-flex flex-row-reverse">
            <button style="width:100px;" type="button" class="btn btn-success" data-toggle="modal" data-target="#quq">
                Add Query
            </button>
        </div><br>
        <?php
                $sel3 = "SELECT  * FROM contact ";
                $run = mysqli_query($con,$sel3);
                // $fm = mysqli_fetch_assoc($run);

                // jese hi select ho jaye vese num rows ke wise data add karo table me.
                echo "<table class=' container table table-striped table-responsive' style='font-size:16px;font-weight:bold;'>
                        <tr>
                        <th>id</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Query</th>
                        <th>Edit</th>
                        <th>Action</th>
                        </tr>
                ";

                if(mysqli_num_rows($run) > 0){
                    $i = 1;
                    $total_prize= 0;
                    while($f = mysqli_fetch_assoc($run)){
                        // $i mens all item starting from 1
                        // f[prize] ke niche jo form he usme muje jo qun he usme uske total prize ke liye likha he
                        echo"
                        <tr>
                        <td>$i</td>
                        <td>$f[name]</td>
                        <td>$f[email]</td>
                        <td><textarea readonly class=' align-content-between' rows=3>
                        $f[ques]
                        </textarea></td>
                        <td>
                        <form action='conu1.php' method='post'>
                            <input type='submit' name='up' class='btn btn-success' value='View'>
                            <input type='hidden' name='up1' value='$f[email]'>
                            <input type='hidden' name='up2' value='$f[ques]'>
                        </form>
                        </td>
                        <td>
                        <form action='conu.php' method='post'>
                            <input type='submit' name='rm1' class='btn btn-danger' value='Remove'>
                            <input type='hidden' name='rm' value='$f[email]'>
                              <input type='hidden' name='rm2' value='$f[ques]'>
                        </form>
                        </td>
                        </tr>
                        ";
                        $i =  $i + 1;
                    }
                    echo "</table>";
                }
                else{
                    Echo "
                    <table>
                    <tr>
                    <h2 class='text-dark'>We Dont Have Any Users</h2><br>
                    </tr>
                    </table>
                    ";

                }

                ?>
        <hr><br>





        <div class="modal fade" id="quq">
            <div class="modal-dialog" role="document">
                <div class="modal-content bg-light text-dark">
                    <div class="modal-header">
                        <h3>Add New Query</h3>
                    </div>
                    <div class="modal-body">
                        <form action="conu.php" method="post" id="fadque" enctype="multipart/form-data">

                            <div class="form-group">
                                <label for="name">Name</label>
                                <input name="an1" class="form-control" id="name" type="text" />
                            </div>
                            <div class="form-group">
                                <label for="name">Email</label>
                                <input name="ae1" class="form-control" id="name" type="email" />
                            </div>
                            <div class="form-group">
                                <label for="name">User Query</label>
                                <textarea name="ap1" class="form-control"></textarea>
                            </div>

                            <input type="submit" class="btn btn-success btn-block" name="uqu" value="Add New Query">
                        </form>

                        <script>
                        $("#fadque").validate({
                            rules: {
                                an1: {
                                    required: true
                                },
                                ae1: {
                                    required: true,
                                    email: true
                                },
                                ap1: {
                                    required: true
                                }

                            },
                            messages: {
                                an: {
                                    required: "Please enter your full name"
                                },
                                ae: {
                                    required: "Please enter Email",
                                    email: "Enter Valid Email"
                                },
                                ap: {
                                    required: "Please provide a password"
                                }
                            },
                            highlight: function(element) {
                                $(element).addClass("highlight").removeClass("valid");
                            },
                            unhighlight: function(element) {
                                $(element).removeClass("highlight").addClass("valid");
                            },
                        });
                        </script>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div><br><br><br>


    <script>
    setTimeout(function() {
        document.getElementById('alt').style.display = "none";
    }, 2000)
    </script>
</body>

</html>