<?php
include('ses.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>My Cart</title>

</head>

<body class="w3-animate-opacity">


    <?php
    if(isset($_COOKIE['piost'])){
        ?>
    <div class="d-flex flex-row-reverse">
        <div class="container  w-100">
            <div class="fixed-top container w3-animate-right alert alert-danger alert-dismissible fade show"
                role="alert" id="alt1" style="z-index:10000;margin-top:80px;">
                <strong><?php echo $_COOKIE['piost']; ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
    <?php
    }
    ?>


    <?php
    if(isset($_COOKIE['odel'])){
        ?>
    <div class="d-flex flex-row-reverse">
        <div class="container  w-100">
            <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show"
                role="alert" id="alt" style="z-index:10000;margin-top:80px;">
                <strong><?php echo $_COOKIE['odel']; ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
    <?php
    }
    ?>

    <?php
    if(isset($_COOKIE['nup'])){
        ?>
    <div class="d-flex flex-row-reverse">
        <div class="container  w-100">
            <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show"
                role="alert" id="alt" style="z-index:10000;margin-top:80px;">
                <strong><?php echo $_COOKIE['nup']; ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
    <?php
    }
    ?>




    <script>
    setTimeout(function() {
        document.getElementById('alt').style.display = "none";
    }, 4000)

    setTimeout(function() {
        document.getElementById('alt1').style.display = "none";
    }, 60000)
    </script>




    <?php
    if(isset($_SESSION['reg']) && $_SESSION['reg'] == "login" ||  isset($_SESSION['log']) &&  $_SESSION['log'] == "login"){
        include('navbaru.php');
    }
    else{
        echo "<script>
        window.location.href = '/myweb/index.php';
        </script>";
    }

    ?>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="main-banner header-text" id="top1">
        <div class="Modern-Slider">
            <div class="item item-3">
                <div class="img-fill">
                    <div class="text-content">
                    </div>
                </div>
            </div>

        </div>
    </div>








    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="text-center mb-4">
                </div>
                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="container">
                            <center>
                                <h1><em style="color:#1E1E1E;">My</em> <em style="color:#A4C639;">Cart</em></h1>
                                <hr><br>
                            </center>
                            <?php
                            if(isset($_SESSION['cr'])){
                                 $_SESSION['cr'];
                               }
                               else{
                                 $_SESSION['cr'] = "Remove";
                               }
                                ?>
                            <style>
                            img {
                                height: 50px;
                                width: 50px;
                            }
                            </style>
                            <?php
                              $em = $_SESSION['r']['e'];
                              $sel = "SELECT  * FROM orders WHERE email='$em'";
                              $run = mysqli_query($con,$sel);

                              // $fm = mysqli_fetch_assoc($run);

                              // jese hi select ho jaye vese num rows ke wise data add karo table me.
                              echo "<table class='container table table-striped table-responsive'>
                                      <tr>
                                      <th>id</th>
                                      <th>Image</th>
                                      <th>Name</th>
                                      <th>Prize</th>
                                      <th>Qunitity</th>
                                      <th>Total</th>
                                      <th>Statuse</th>
                                      <th>Action</th>
                                      </tr>
                              ";

                              if(mysqli_num_rows($run) > 0){
                                  $i = 1;
                                  $total_prize= 0;
                                  while($f = mysqli_fetch_assoc($run)){
                                      $st = $f['prize'];
                                      $int = (int)str_replace(",","",$st);


                                      $m = ($f['qun'] ) * $int;
                                      $st1 = number_format($m);
                                      $total_prize = $total_prize + $m;
                                      // $i mens all item starting from 1
                                      // f[prize] ke niche jo form he usme muje jo qun he usme uske total prize ke liye likha he
                                      echo "
                                      <tr>
                                          <td>$i</td>
                                          <td><img src='img/{$f['img']}'></td>
                                          <td>{$f['name']}</td>
                                          <td>{$f['prize']}</td>
                                          <td>
                                              <form action='chem.php' method='post'>
                                                  <input type='number' name='qup' value='{$f['qun']}' min='1' max='50' class='' id='mq'>
                                                  <input type='hidden' name='nup' value='{$f['name']}'>
                                                  <input type='hidden' name='pup' value='{$f['prize']}'>
                                                  <input type='submit' name='sup' value='Update' class='btn btn-success'>
                                              </form>
                                          </td>
                                          <td>$st1</td>
                                          <td>";
                                      ?>
                                      <?php
                                      $nm = $f['name'];
                                       $psl = "SELECT * FROM product where name='$nm'";
                                       $pslr = mysqli_query($con,$psl);
                                       $pslf = mysqli_fetch_assoc($pslr);
                                      if ($pslf['qun'] >= 1 && $pslf['qun'] <= 50){
                                          echo "<h1 class='badge badge-success'>In Stock</h1>";
                                      } else {
                                          echo "<h1 class='badge badge-danger'>Out Of Stock</h1>";
                                      }
                                      ?>
                                      <?php
                                      echo "
                                          </td>
                                          <td>
                                              <form action='chem.php' method='post'>
                                                  <input type='submit' name='rm1' class='btn btn-danger' value='{$_SESSION['cr']}'>
                                                  <input type='hidden' name='rm' value='{$f['name']}'>
                                                  <input type='hidden' name='rm3' value='{$f['prize']}'>
                                                  <input type='hidden' name='rm4' value='{$f['qun']}'>
                                                  <input type='hidden' name='rm5' value='$i'>
                                              </form>
                                          </td>
                                      </tr>
                                      ";
                                      $i =  $i + 1;
                                  }
                                  $fo =number_format($total_prize);
                                  echo "</form></table>";
                                  echo "
                                  <table class='table table-responsive table-striped'>
                                  <tr>
                                      <th>Total Prize</th>
                                      <th>$fo</th>
                                      <th></th>
                                      <th></th>
                                      <th></th>
                                      <th></th>
                                  </tr>
                                  </table>
                                  ";
                                  ?>
                            <div class="container">
                                <form action="checkout1.php" method="post">
                                    <input type="submit" class=" btn btn-primary btn-block" value="Continue To By"
                                        name="pay">
                                    <input type='hidden' name='qup' value='<?php echo $f['name']; ?>' class='' id='mq'
                                        min=1 max=50>
                                    <input type='hidden' name='nup' value='$f[name]'>
                                    <input type='hidden' name='pup' value='$f[prize]'>
                                </form>
                            </div>
                            <?php

                              }
                              else{
                                  Echo "
                                  <table>
                                  <tr>
                                  <center><h2 class='text-dark text-center' style='font-weight:bolder;'>Cart Is Empty</h2></center><br>
                                  </tr>
                                  </table>
                                  ";
                              }

                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <br><br><br><br><br><br><br><br><br><br><br><br>











    <?php
include('foot.php');
?>
</body>

</html>