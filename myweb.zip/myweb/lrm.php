<?php
include('ses.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

try {
if (isset($_POST['reg'])) {
    function cleanText($text) {
        $text = trim($text);
        $text = preg_replace('/\s+/', ' ', $text);
        return $text;
    }



    $n = $_POST['n'];
    $e = strtolower($_POST['e']);
    $p = $_POST['p'];
    $mbl = $_POST['m'];
    $ad = $_POST['ad'] ?? '';
    $i = $_FILES['f1']['name'];
    $c = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $cup = substr(str_shuffle($c), 0, 6);


        $s = $p;
        $npass = "";

        $m = array(
    "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z",
    "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
    "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
    "!", "\"", "#", "$", "%", "&", "'", "(", ")", "*", "+", ",", "-", ".", "/", ":", ";", "<", "=", ">", "?", "@", "[", "\\", "]", "^", "_", "`", "{", "|", "}", "~",
    " ", "\t", "\n"
);
        for($i = 0; $i < strlen($s); $i++) {
            for($j = 0; $j < count($m); $j++) {
                if($s[$i] == $m[$j]) {
                    $npass .= $m[$j + 3];
                }
            }
        }


    // Check if email or mobile already exists
    $rs = "SELECT email, mobile FROM user WHERE email='$e' OR mobile='$mbl'";
    $rsr = mysqli_query($con, $rs);
    if (mysqli_num_rows($rsr) > 0) {
        setcookie("er", "Email or mobile already exists", time() + 3);
        echo "<script>window.location.href = '/myweb/reg.php';</script>";
    } else {
        $ff = uniqid() . $_FILES['f1']['name'];
        if (move_uploaded_file($_FILES['f1']['tmp_name'], 'uploads/' . $ff)) {
            require 'PHPMailer/Exception.php';
            require 'PHPMailer/PHPMailer.php';
            require 'PHPMailer/SMTP.php';
                $ui = "INSERT INTO user (name, email, password, mobile, adr, cup, img, stat) VALUES ('$n', '$e', '$npass', '$mbl', '$ad', '$cup', '$ff', 'inactive')";
                $ur = mysqli_query($con, $ui);

                // $_SESSION['reg'] = "login";
                $fname = "SELECT * FROM user WHERE email='$e'";
                $frun = mysqli_query($con, $fname);
                $fd = mysqli_fetch_assoc($frun);

                $_SESSION['r']['n'] = $fd['name'];
                $_SESSION['r']['e'] = $fd['email'];
                $_SESSION['r']['p'] = $fd['password'];
                $_SESSION['r']['m'] = $fd['mobile'];
                $_SESSION['r']['ad'] = $fd['adr'];
                $_SESSION['r']['i'] = $fd['img'];
                echo "<script>
                alert('Register Successfully .You Login To Your Account');
                window.location.href = '/myweb/log.php';
                </script>";

                if($ur == 1){
                    $mail1 = new PHPMailer(true);

                        $mail1->isSMTP();
                        $mail1->Host = 'smtp.gmail.com';
                        $mail1->SMTPAuth = true;
                        $mail1->Username = "websitekwebsite@gmail.com"; // Set your email here
                        $mail1->Password = 'tvscygrvllvqnbrs'; // Your App Password
                        $mail1->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
                        $mail1->Port = 465;

                        $mail1->setFrom("websitekwebsite@gmail.com", "Welcome To Our Family $n");
                        $mail1->addAddress($e, "User");

                        $mail1->isHTML(true);
                        $mail1->Subject = "Thanks For Register";

                        $mail1->Body = "
                        <h2>Hello $n</h2><br>
                        We warmly welcome you to our shop. We provide the best products for you. Visit our website for amazing deals. <a href='http://localhost/myweb/index.php'>E-Shopping</a><br>
                        <h3 class='bg-success text-white'>$n, You get a 10% discount on all products for <u style='background:yellow;'>Life Time</u></h3>
                        <br><br>
                        <hr>
                        <h1>Thank You For Registering</h1>";

                        $mail1->send();

                        }

                }

                }

        }
    }

    catch (Exception $e1) {
        echo "<script>
        alert('Please check your internet connection');
        window.location.href = '/myweb/reg.php';
        </script>";

    }







if(isset($_POST['log'])){

    /*---------------------------------------------------------------------------------------------------------------------------------------------------- */
    /*--------------------------------------------- THIS IS FOR USER LOGIN ---------------------------------------------------------------------------------*/
    /*----------------------------------------------------------------------------------------------------------------------------------------------------*/
    $e1 = strtolower($_POST['e11']);
    $p1 =  $_POST['p11'];

    $s1   = $p1;
    $npass1 = "";

    $m1 = array(
    "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z",
    "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
    "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
    "!", "\"", "#", "$", "%", "&", "'", "(", ")", "*", "+", ",", "-", ".", "/", ":", ";", "<", "=", ">", "?", "@", "[", "\\", "]", "^", "_", "`", "{", "|", "}", "~",
    " ", "\t", "\n"
    );
        for($i = 0; $i < strlen($s1); $i++) {
            for($j = 0; $j < count($m1); $j++) {
                if($s1[$i] == $m1[$j]) {
                    $npass1 .= $m1[$j + 3];
                }
            }
        }


        $ls = "SELECT email FROM user WHERE email='$e1'";
        $lr=mysqli_query($con,$ls);


        $ls1 = "SELECT password FROM user WHERE password='$npass1'";
        $lr1=mysqli_query($con,$ls1);


            $fname1 = "SELECT * FROM user WHERE email='$e1'";
            $frun1=mysqli_query($con,$fname1);
            $fd1=mysqli_fetch_assoc($frun1);

        if(mysqli_num_rows($lr) >0  && mysqli_num_rows($lr1) >0){
            $_SESSION['log'] = "login";
            $_SESSION['r']['n'] = $fd1['name'];
            $_SESSION['r']['e'] = $fd1['email'];
            $_SESSION['r']['p'] = $p1;
            $_SESSION['r']['m'] = $fd1['mobile'];
            $_SESSION['r']['ad'] = $fd1['adr'];
            $_SESSION['r']['i'] = $fd1['img'];

            echo "<script>
            alert('Login Succsessfully');
            window.location.href  = '/myweb/index.php';
            </script>";

        }
        else{
            setcookie("el","Enter Valid Email Or Password",time()+3);
            echo "<script>
            window.location.href = '/myweb/log.php';
            </script>";

        }

    }



















if(isset($_POST['adm'])){
    $ae = $_POST['ae'];
    $ap = $_POST['ap'];


    $ad = "SELECT email FROM admin where email='$ae'";
    $adr =mysqli_query($con,$ad);

    if(mysqli_num_rows($adr) >0){
        $_SESSION['admin'] = "login";
        $_SESSION['am']['e'] = $ae;
        $_SESSION['am']['p']=$ap;
        echo "<script>
            window.location.href = '/myweb/ad.php';
            alert('Login Successfully');
            </script>";
    }
    else{
        echo "<script>
            window.location.href = '/myweb/index.php';
            alert('You Are Not Admin');
            </script>";
    }
}










if(isset($_POST['vac'])){
    $eml = $_SESSION['r']['e'];
    $uvr = "UPDATE user SET stat='active' where email='$eml'";
    setcookie("dvr","Your Account Varify Now You Login To Your Acount",time()+3);
    echo "<script>
    window.location.href = '/myweb/log.php';
    </script>";
}



?>