<?php
include('ses.php');
$nm = $_SESSION['ue'];
$u = $_SESSION['ue1'];

        if(isset($_POST['uppro'])){

            $n = $_POST['pn1'];
            $p = mysqli_real_escape_string($con,$_POST['pp1']);
            $o = mysqli_real_escape_string($con,$_POST['po1']);
            $or =mysqli_real_escape_string($con,$_POST['por1']);
            $d = $_POST['pd1'];
            $q = $_POST['pq1'];
            $ab = $_POST['pab1'];
            $m = $_POST['pm1'];
            $i =$_POST['pi1'];
            $t = $_POST['pt1'];
            $img = $_FILES['f2']['name'];
            $ti = "o11.png";


                $rs1 = "SELECT * FROM product  where  name='$nm'";
                $rsr1 =mysqli_query($con,$rs1);
                if(mysqli_num_rows($rsr1)>0){
                    if($_FILES['f2']['name'] == ""){
                        $ins2 = "UPDATE product SET  name='$n',prize='$p',qun='$q',offer='$o',offr='$or',di='$d',about='$ab',mem='$m',inf='$i',tec='$t',img='$ti'  where name='$nm' and u='$u'";
                        $ur = mysqli_query($con,$ins2);


                            setcookie("updatep","Updated Successfully",time()+3);
                            echo "<script>
                            window.location.href = '/myweb/adp.php';
                            </script>";
                    }
                    else{
                        if(move_uploaded_file($_FILES['f2']['tmp_name'],'img/'.$img)){

                            $ins = "UPDATE product SET  name='$n',prize='$p',qun='$q',offer='$o',offr='$or',di='$d',about='$ab',mem='$m',inf='$i',tec='$t',img='$img'  where name='$nm  ' and u='$u'";
                            $ur1 = mysqli_query($con,$ins);


                            setcookie("updatep","Updated Successfully",time()+3);
                            echo "<script>
                            window.location.href = '/myweb/adp.php';
                            </script>";
                            }
                    }
                }


    }

?>