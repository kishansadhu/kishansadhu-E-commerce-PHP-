<?php
include('ses.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="/myweb/plug/bootstrap-4.0.0-dist/css/bootstrap.min.css">

    <title>Admin Login</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/owl.css">

    <style>
    /* this is for the form error */
    label.error {
        border-radius: 5px;
        color: red;
    }

    .error {
        margin-top: 1.5px;
        color: red;
        font-size: 15px;
        font-weight: 500;
    }

    .highlight {
        border: 2px solid rgb(252, 150, 150);
    }

    .valid {
        border: 2px solid green;

    }

    body.modal-open {
        overflow: visible !important;
        padding-right: 0 !important;
    }
    </style>
</head>
<script src="/myweb/plug/js/jquery-3.7.1.min.js"></script>
<script src="/myweb/plug/js/jquery.validate.js"></script>
<script src="/myweb/plug/js/additional-methods.js"></script>

<script src="/myweb/plug/bootstrap-4.0.0-dist/js/bootstrap.bundle.js"></script>

<body class="w3-animate-opacity">

<style>
    body{
        background-color:black;
        background-image: url('/myweb/assets/images/slider-image-1-1920x900.jpg');
        background-repeat: no-repeat;
        background-position: bottom;
        background-size:contain;
        background-attachment: fixed;
        /* background-size:cover contain; */
    }
</style>


<?php

    if(isset($_SESSION['admin']) && $_SESSION['admin'] == "login"){
        echo "
        <script>
        window.location.href = '/myweb/index.php'
        </script>
        ";
    }
    else{
        echo "
        ";
    }

    ?>



    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <br><br><br>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="text-center mb-4">
                </div>
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h2 class="card-title text-center mb-4">Admin Login</h2>
                        <form action="lrm.php" method="post" id="formlog">
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input name="ae" class="form-control" id="email" placeholder="john.doe@domain.com"
                                    type="email" />
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <div class="input-group">
                                    <input name="ap" class="form-control" id="password" placeholder="Password"
                                        type="password" /> <br>

                                </div><br>
                                <span><input type="checkbox" class="" id="ch" onclick="show()"> Show Password</span>
                                <script>
                                document.getElementById('password').type = "password"

                                function show() {
                                    var x = document.getElementById('password');
                                    if (x.type === "password") {
                                        x.type = "text";
                                    } else {
                                        x.type = "password";
                                    }
                                }
                                </script>
                            </div><br><br>
                            <input type="submit" name="adm" class="btn btn-primary btn-block" value="Login">
                        </form><br>
                    </div>
                </div>
            </div>
        </div>
    </div><br><br><br><br>





    <script>
    $("#formlog").validate({
        rules: {
            ae: {
                required: true,
                email: true
            },
            ap: {
                required: true,
                minlength: 8,
                maxlength: 12,
                // Regex: kam se kam 1 lowercase, 1 uppercase, 1 digit, 1 special character
                pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%?&])[A-Za-z\d@$!%?&]{8,12}$/
            }
        },
        messages: {
            ae: {
                required: "Please enter email",
                email: "Please enter valid email "
            },
            ap: {
                required: "Please provide a password",
                minlength: "Password must be exactly 8",
                maxlength: "Password Length less then 12",
                pattern: "Password Formate Ksadhu@1"
            }
        },
        highlight: function(element) {
            $(element).addClass("highlight").removeClass("valid");
        },
        unhighlight: function(element) {
            $(element).removeClass("highlight").addClass("valid");
        }
    });
    </script>


</body>
</html>