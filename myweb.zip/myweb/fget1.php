<?php
include('ses.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forget Password</title>
</head>

<body>



    <script>
    setTimeout(function() {
        document.getElementById('alt1').style.display = "none";
    }, 3000)
    </script>





    <?php
    if(isset($_SESSION['reg']) && $_SESSION['reg'] == "login" ||  isset($_SESSION['log']) &&  $_SESSION['log'] == "login"){
       echo "
       <script>
       window.location.href = '/myweb/index.php'
       </script>
       ";
   }
   else{
       include('navbar.php');
   }
   ?>


    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="main-banner header-text" id="top1">
        <div class="Modern-Slider">
            <div class="item item-3">
                <div class="img-fill">
                    <div class="text-content">
                    </div>
                </div>
            </div>

        </div>
    </div>
    <br><br><br>




    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="text-center mb-4">
                </div>
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h2 class="card-title text-center mb-4">Forget Password</h2>
                        <hr>
                        <form action="fgetm.php" method="post" id="formfor">
                            <div class="form-group">
                                <!-- <label for="email">Email Id</label> -->
                                <input name="ef" class="form-control" value="<?php
                                $ek = $_SESSION['soe'];
                                if(isset($_SESSION['soe'])){
                                    echo $_SESSION['soe'];
                                }
                                    else{
                                        echo "<script>
                                        window.location.href = '/myweb/fget.php'
                                        </script>";
                                    }

                                ?>" id="email" placeholder="john.doe@domain.com"
                                    type="hidden" readonly/>
                            </div>
                            <div class="form-group">
                                <label for="email">New Password</label>
                                <input name="psf" class="form-control" id="pass" placeholder="Password Formate Like Ksadhu@1k"
                                    type="password" maxlength=9 minlength=1  />
                            </div>
                            <span><input type="checkbox" class="" id="ch2" onclick="show2()"> Show
                                Password</span><br><br>
                            <script>
                            document.getElementById('pass').type = "password"

                            function show2() {
                                var x = document.getElementById('pass');
                                if (x.type === "password") {
                                    x.type = "text";
                                } else {
                                    x.type = "password";
                                }
                            }
                            </script>

                            <button class="btn btn-primary" name="fg" type="submit">Update</button>
                        </form><br>


                    </div>
                </div>
            </div>
        </div>
    </div><br><br><br><br>


    <script>
         $.validator.addMethod("allowedDomain", function(value, element) {
        var domain = value.split('@')[1];
        var allowed = ['gmail.com', 'ac.in', 'yourdomain.com'];
        return this.optional(element) || allowed.includes(domain);
    }, "Sirf gmail.com, ac.in ya allowed domains hi valid hain.");

    $("#formfor").validate({
        rules: {
            ef: {
                required: true,
                email: true,
                allowedDomain: true
            },
            psf: {
                required: true,
                minlength: 8,
                maxlength: 12,
                // Regex: kam se kam 1 lowercase, 1 uppercase, 1 digit, 1 special character
                pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%?&])[A-Za-z\d@$!%?&]{8,12}$/
            },
            pf: {
                required: true,

            }

        },
        messages: {
            ef: {
                required: "Please enter email",
                email: "Please enter valid email ",
                allowedDomain: "Please enter valid email"
            },
            psf: {
                required: "Please provide a password",
                minlength: "Password must be exactly 8",
                maxlength: "Password Length less then 12",
                pattern: "Password Formate Ksadhu@1"
            },
            pf: {
                required: "Enter OTP",
            }
        },
        highlight: function(element) {
            $(element).addClass("highlight").removeClass("valid");
        },
        unhighlight: function(element) {
            $(element).removeClass("highlight").addClass("valid");
        },
    });
    </script>

<?php
include('foot.php');
?>
</body>

</html>