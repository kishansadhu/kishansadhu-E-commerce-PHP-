<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body class="w3-animate-opacity">
    <!-- Footer Starts Here -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4 footer-item">
                    <h4>Mobile Store</h4>
                    <p>Hello User We Provide The Best Shell For Your Please Check Our Provides WE Given Bes Discount Forewer.</p>
                    <ul class="social-icons">
                        <li><a rel="nofollow" href="#" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                    </ul>
                </div>
                <div class="col-md-4 footer-item">
                    <h4>Useful Links</h4>
                    <ul class="menu-list">
                        <li><a href="index.php">HOME</a></li>
                        <li><a href="products.php">Products</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li><a href="log.php">login/register</a></li>
                    </ul>
                </div>

                <div class="col-md-4 footer-item">
                    <h4>Contact Us</h4>
                    <ul class="menu-list">
                        <li>Tel&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: +91 1234567890</li>
                        <li>Email&nbsp;&nbsp;: websitekwebsite@gmail.com</li>
                        <li></li>
                    </ul>
                </div>

                <!-- <div class="col-md-4 footer-item last-item">
                    <h4>Contact Us</h4>
                    <div class="contact-form">
                        <form id="contact footer-contact" action="foot.php" method="post">
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <fieldset>
                                        <input type="email"  name="efoot" class="form-control">
                                    </fieldset>
                                </div>

                                <div class="col-lg-12">
                                    <fieldset>
                                        <button type="submit" name="fsub" id="form-submit" class="filled-button">Subscribe</button>
                                    </fieldset>
                                </div>
                            </div>
                        </form>
                    </div>
                </div> -->
            </div>
        </div>
    </footer>

    <div class="sub-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <p>
                        Copyright © 2025 E-mobile
                    </p>
                </div>
            </div>
        </div>
    </div>



</body>

</html>