<?php
include('ses.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,400,500,600,700,800,900&display=swap"
        rel="stylesheet">

    <title>About Us Page</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/owl.css">
</head>

<body class="w3-animate-opacity">


    <?php
    if(isset($_SESSION['reg']) && $_SESSION['reg'] == "login" ||  isset($_SESSION['log']) &&  $_SESSION['log'] == "login"){
      include('navbaru.php');
  }
  else{
      include('navbar.php');
  }
    ?>
    <style>
    .header .navbar {
        position: sticky;
        top: 10px;
    }
    </style>
    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="main-banner header-text" id="top1">
        <div class="Modern-Slider">
            <div class="item item-3">
                <div class="img-fill">
                    <div class="text-content">
                    </div>
                </div>
            </div>

        </div>
    </div><br>

    <div class="more-info about-info">
        <div class="container">
            <span><span style="font-weight:bold;font-family: monospace;font-size:40px;color:#a4c639;">A</span><span
                    style="font-weight:bold;font-family: monospace;font-size:40px;">bout</span>
                <span>
                    <span style="font-weight:bold;font-family: monospace;font-size:40px;color:#a4c639;">U</span><span
                        style="font-weight:bold;font-family: monospace;font-size:40px;">s</span></span>
            </span>
            <div class="row">
                <div class="col-md-12">
                    <div class="more-info-content">
                        <div class="row">
                            <div class="col-md-6 align-self-center">
                                <div class="right-content">
                                    <div class="container">
                                    </div>
                                    <hr>
                                    <span class=" text-center" style="color:black;">
                                        Everything we do starts with you: The products we make, our customer service,
                                        the brands we partner with and the content we create. Ultimately you call the
                                        shots around here and that’s the way we like it.
                                        <br><br>
                                        <hr>
                                        In 2008 we created ban.do because we loved laughing, connecting and designing
                                        things that made people happy. Over a decade later a lot has changed, but why we
                                        do what we do and who we are hasn’t. At our core we are and have always been
                                        optimists who aspire to be better than great and less than perfect and firmly
                                        believe that being upside down is much more fun than being right side up.
                                        <br><br>
                                        <hr>
                                        Joy comes in many forms—color, music, confetti, great conversation—and we
                                        believe it sparks creativity, connects people, and makes us more resilient. It
                                        lives inside of all of us, sometimes it just needs a little encouragement. So we
                                        create and curate products to inspire it.
                                        <br><br>
                                        <hr>
                                        Gone are the days of cool meaning exclusive and elusive. We think it’s defined
                                        by championing others and supporting individuality. We’re consistently teaming
                                        up with independent artists and companies to celebrate you and your unique brand
                                        of coo
                                        <br><br>
                                        <hr>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="left-image">
                                    <img src="assets/images/about-1-570x350.jpg" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <br><br>
    <?php
include('foot.php');
?>

</body>

</html>