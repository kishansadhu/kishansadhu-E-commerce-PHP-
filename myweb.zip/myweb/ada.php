<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admins</title>
</head>

<body>
    <?php
    if(isset($_COOKIE['add'])){
        ?>
    <div class="d-flex flex-row-reverse">
        <div class="container  w-100">
            <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show"
                role="alert" id="alt" style="z-index:10000;">
                <strong><?php echo $_COOKIE['add']; ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
    <?php
    }
    ?>

    <?php
    if(isset($_COOKIE['adu'])){
        ?>
    <div class="d-flex flex-row-reverse">
        <div class="container  w-100">
            <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show"
                role="alert" id="alt" style="z-index:10000;">
                <strong><?php echo $_COOKIE['adu']; ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
    <?php
    }
    ?>

    <?php
    if(isset($_COOKIE['ade'])){
        ?>
    <div class="container  w-100">
        <div class="fixed-top container w3-animate-right alert alert-danger alert-dismissible fade show" role="alert" id="alt"
            style="z-index:10000;">
            <strong><?php echo $_COOKIE['ade']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>

    <?php
    if(isset($_COOKIE['ada'])){
        ?>
    <div class="container  w-100">
        <div class="fixed-top container w3-animate-right alert alert-success alert-dismissible fade show" role="alert" id="alt"
            style="z-index:10000;">
            <strong><?php echo $_COOKIE['ada']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>







    <?php
    include('admin.php');
    ?><br><br><br>
    <div class="container card w3-animate-opacity" style="padding:20px;border-radius:20px;">
        <style>
        #services #sr {
            /* overflow-y:scroll; */
            height: 100px;
        }
        </style>
        <span><span style="font-weight:bold;font-family: monospace;font-size:30px;color:#a4c639;">A</span><span
                style="font-weight:bold;font-family: monospace;font-size:30px;">dmin</span></span>

        <div class="d-flex flex-row-reverse">
            <button style="width:100px;" type="button" class="btn btn-success" data-toggle="modal" data-target="#three">
                Add Admin
            </button>
        </div><br>
        <?php
                $sel3 = "SELECT  * FROM admin ";
                $run = mysqli_query($con,$sel3);
                // $fm = mysqli_fetch_assoc($run);

                // jese hi select ho jaye vese num rows ke wise data add karo table me.
                echo "<table class=' container table table-striped table-responsive' style='font-size:16px;font-weight:bold;'>
                        <tr>
                        <th>id</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Password</th>
                        <th>Edit</th>
                        <th>Action</th>
                        </tr>
                ";

                if(mysqli_num_rows($run) > 0){
                    $i = 1;
                    $total_prize= 0;
                    while($f = mysqli_fetch_assoc($run)){
                        // $i mens all item starting from 1
                        // f[prize] ke niche jo form he usme muje jo qun he usme uske total prize ke liye likha he
                        echo"
                        <tr>
                        <td>$i</td>
                        <td>$f[name]</td>
                        <td>$f[email]</td>
                        <td>$f[password]</td>
                        <td>
                        <form action='ama1.php' method='post'>
                            <input type='submit' name='up' class='btn btn-success' value='Edit'>
                            <input type='hidden' name='up1' value='$f[email]'>
                        </form>
                        </td>
                        <td>
                        <form action='ama.php' method='post'>
                            <input type='submit' name='rm1' class='btn btn-danger' value='Remove'>
                            <input type='hidden' name='rm' value='$f[email]'>
                        </form>
                        </td>
                        </tr>
                        ";
                        $i =  $i + 1;
                    }
                    echo "</table>";
                }
                else{
                    Echo "
                    <table>
                    <tr>
                    <h2 class='text-dark'>We Dont Have Any Users</h2><br>
                    </tr>
                    </table>
                    ";

                }

                ?>
        <hr><br>





        <div class="modal fade" id="three">
            <div class="modal-dialog" role="document">
                <div class="modal-content bg-light text-dark">
                    <div class="modal-header">
                        <h3>Add New Admin</h3>
                    </div>
                    <div class="modal-body">
                        <form action="ama.php" method="post" id="fadm" enctype="multipart/form-data">

                            <div class="form-group">
                                <label for="name">Name</label>
                                <input name="an" class="form-control" id="name" type="text" />
                            </div>
                            <div class="form-group">
                                <label for="name">Email</label>
                                <input name="ae" class="form-control" id="name" type="email" />
                            </div>
                            <div class="form-group">
                                <label for="name">Password</label>
                                <input name="ap" class="form-control" id="apass" type="password" />
                            </div>
                            <span><input type="checkbox" class="" id="ch4" onclick="show4()"> Show
                                Password</span>
                            <script>
                            document.getElementById('apass').type = "password"

                            function show4() {
                                var x = document.getElementById('apass');
                                if (x.type === "password") {
                                    x.type = "text";
                                } else {
                                    x.type = "password";
                                }
                            }
                            </script>

                            <input type="submit" class="btn btn-success btn-block" name="addadm" value="Add New Admin">
                        </form>

                        <script>
                        $("#fadm").validate({
                            rules: {
                                an: {
                                    required: true
                                },
                                ae: {
                                    required: true,
                                    email: true
                                },
                                ap: {
                                    required: true,
                                    minlength: 8,
                                    maxlength: 12,
                                    // Regex: kam se kam 1 lowercase, 1 uppercase, 1 digit, 1 special character
                                    pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%?&])[A-Za-z\d@$!%?&]{8,12}$/
                                }

                            },
                            messages: {
                                an: {
                                    required: "Please enter your full name"
                                },
                                ae: {
                                    required: "Please enter Prize",
                                    email: "Enter Valid Email"
                                },
                                ap: {
                                    required: "Please provide a password",
                                    minlength: "Password must be exactly 8",
                                    maxlength: "Password Length less then 12",
                                    pattern: "Password Formate Ksadhu@1"
                                }
                            },
                            highlight: function(element) {
                                $(element).addClass("highlight").removeClass("valid");
                            },
                            unhighlight: function(element) {
                                $(element).removeClass("highlight").addClass("valid");
                            },
                        });
                        </script>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div><br><br><br>


    <script>
    setTimeout(function() {
        document.getElementById('alt').style.display = "none";
    }, 2000)
    </script>
</body>

</html>