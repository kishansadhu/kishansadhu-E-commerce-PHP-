<?php
include('ases.php');
if(isset($_POST['rm1'])){
    $mc = $_POST['rm'];
        $del1 = "DELETE FROM product WHERE name='$mc'";
        $drun1 = mysqli_query($con,$del1);
        setcookie("dp","product deleted Successfully",time()+2);
       echo "
        <script>
        window.location.href ='/myweb/adp.php';
        </script>
        ";

}



if(isset($_POST['addpro'])){
    $nm = $_POST['prd'];
    $n = $_POST['pn'];
    $p = mysqli_real_escape_string($con,$_POST['pp']);
    $o = mysqli_real_escape_string($con,$_POST['po']);
    $or =mysqli_real_escape_string($con,$_POST['por']);
    $d = $_POST['pd'];
    $ab = $_POST['pab'];
    $m = $_POST['pm'];
    $i = $_POST['pi'];
    $t = $_POST['pt'];
    $img = $_FILES['f2']['name'];



    $rs = "SELECT name FROM product where name='$n' and u='$nm'";
    $rsr = mysqli_query($con,$rs);

    if(mysqli_num_rows($rsr) >0){
        setcookie("ep","This Product Already Exist",time()+2);
        echo "<script>
        window.location.href = '/myweb/adp.php';
        </script>";
    }
    else{
        $ff =uniqid().$_FILES['f2']['name'];
        if(move_uploaded_file($_FILES['f2']['tmp_name'],'img/'.$ff)){
        $ins = "INSERT INTO product (name,prize,offer,offr,di,about,mem,inf,tec,u,img) VALUES ('$n','$p','$o','$or','$d','$ab','$m','$i','$t','$nm','$ff')";
        $ir = mysqli_query($con,$ins);

        setcookie("ap","product added Successfully",time()+2);
        echo "
        <script>
        window.location.href = '/myweb/adp.php';
        </script>
        ";
    }
}
}


?>