document.getElementById('qun').readOnly = false;
function pays(){
    document.getElementById('qun').readOnly = true;
}
