<?php
include('ses.php');

if(isset($_POST['upd'])){
    function cleanText($text) {
        $text = trim($text);
        $text = preg_replace('/\s+/', ' ', $text);
        return $text;
    }

    $n = $_POST['n1'];
    $e = $_POST['e1'];
    $p = $_POST['p1'];
    $m = $_POST['m1'];
    $ad= $_POST['add1'] ?? '';
    $i = $_FILES['f11']['name'];
    $re =$_SESSION['r']['e'];
    $rm =$_SESSION['r']['e'];
    $ti='user.png';

    $rs = "SELECT * FROM user where email='$e' and mobile='$m'   ";
    $rsr =mysqli_query($con,$rs);
    $mf = mysqli_fetch_assoc($rsr);

    $sk = $p;
    $nk = "";
    $n11 = "";

    $mk = array(
        "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z",
        "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
        "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
        "!", "\"", "#", "$", "%", "&", "'", "(", ")", "*", "+", ",", "-", ".", "/", ":", ";", "<", "=", ">", "?", "@", "[", "\\", "]", "^", "_", "`", "{", "|", "}", "~",
        " ", "\t", "\n"
    );
    for($i = 0; $i < strlen($sk); $i++) {
        for($j = 0; $j < count($mk); $j++) {
            if($sk[$i] == $mk[$j]) {
                $nk .= $mk[$j + 3];
            }
        }
    }


        for($i1 = 0; $i1 < strlen($nk); $i1++) {
            for($j1 = 0; $j1 < count($mk); $j1++) {
                if($nk[$i1] == $mk[$j1]) {
                    $n11 .= $mk[$j1 - 3];
                }
            }
        }





    if(mysqli_num_rows($rsr) >0){
         $ff = uniqid().$_FILES['f11']['name'];
         $ffk= 'uploads/'.$mf['img'];
        if($_FILES['f11']['name'] == ""){
            setcookie("upf","Updated Successfully",time()+3);
            echo "<script>
            window.location.href = '/myweb/user.php'
            </script>";


            $ui = "UPDATE  user SET name='$n',password='$nk',adr='$ad',img='$ti' where email='$re'";
            $ur = mysqli_query($con,$ui);
                $_SESSION['r']['n'] = $n;
                $_SESSION['r']['e'] = $e;
                $_SESSION['r']['p'] = $p;
                $_SESSION['r']['m'] = $m;
                $_SESSION['r']['ad'] = $ad;
                $_SESSION['r']['i'] = $ti;

                if($mf['img'] === 'user.png'){
                    echo "";
                }
                else{
                    unlink($ffk);
                }

        }
        else{
            if(move_uploaded_file($_FILES['f11']['tmp_name'],'uploads/'.$ff)){
                setcookie("upf","U  pdated Successfully",time()+3);

                echo "
                <script>
                window.location.href = '/myweb/user.php'
                </script>";


                $uiq = "UPDATE  user SET name='$n',password='$nk',adr='$ad',img='$ff' where email='$re'";
                $urq = mysqli_query($con,$uiq);

                $_SESSION['r']['n'] = $n;
                $_SESSION['r']['e'] = $e;
                $_SESSION['r']['p'] = $p;
                $_SESSION['r']['m'] = $m;
                $_SESSION['r']['ad'] = $ad;
                $_SESSION['r']['i'] = $ff;


                if($mf['img'] === 'user.png'){
                    echo "";
                }
                else{
                    unlink($ffk);
                }

                }



        }
    }





    }


?>