<?php
include('ses.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forget Password</title>
</head>

<body>




    <?php
    if(isset($_COOKIE['une'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-danger alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:100px;">
            <strong><?php echo $_COOKIE['une']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>

    <?php
    if(isset($_COOKIE['econ'])){
        ?>
    <div class="container  w-100 bg-light" style="z-index:30000;">
        <div class="fixed-top container w3-animate-right alert alert-danger alert-dismissible fade show" role="alert"
            id="alt1" style="z-index:30000;margin-top:100px;">
            <strong><?php echo $_COOKIE['econ']; ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    }
    ?>



    <script>
    setTimeout(function() {
        document.getElementById('alt1').style.display = "none";
    }, 3000)
    </script>









    <?php
    if(isset($_SESSION['reg']) && $_SESSION['reg'] == "login" ||  isset($_SESSION['log']) &&  $_SESSION['log'] == "login"){
       echo "
       <script>
       window.location.href = '/myweb/index.php'
       </script>
       ";
   }
   else{
       include('navbar.php');
   }
   ?>


    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="main-banner header-text" id="top1">
        <div class="Modern-Slider">
            <div class="item item-3">
                <div class="img-fill">
                    <div class="text-content">
                    </div>
                </div>
            </div>

        </div>
    </div>
    <br><br><br>




    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="text-center mb-4">
                </div>
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h2 class="card-title text-center mb-4">Forget Password</h2>
                        <hr>
                        <form action="fgetm.php" method="post" id="formfor1">
                            <div class="form-group">
                                <label for="email">Email Id</label>
                                <input name="ef1" class="form-control" placeholder="john.doe@domain.com" type="email" />
                            </div>
                            <input type="submit" name="go1" class="btn btn-success" value="Send OTP"><br><br>


                            <a href="log.php">Back To Login</a><br>

                    </div>
                </div>
            </div>
        </div>
    </div><br><br><br><br>


    <script>
    $.validator.addMethod("allowedDomain", function(value, element) {
        var domain = value.split('@')[1];
        var allowed = ['gmail.com', 'ac.in', 'yourdomain.com'];
        return this.optional(element) || allowed.includes(domain);
    }, "Sirf gmail.com, ac.in ya allowed domains hi valid hain.");

    $("#formfor1").validate({
        rules: {
            ef1: {
                required: true,
                email: true,
                allowedDomain: true
            }

        },
        messages: {
            ef1: {
                required: "Please enter email",
                email: "Please enter valid email ",
                allowedDomain: "Please enter valid email"
            }
        },
        highlight: function(element) {
            $(element).addClass("highlight").removeClass("valid");
        },
        unhighlight: function(element) {
            $(element).removeClass("highlight").addClass("valid");
        },
    });
    </script>


    <?php
include('foot.php');
?>
</body>

</html>