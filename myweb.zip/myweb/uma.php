<?php
include('ases.php');
if(isset($_POST['rm1'])){
    $mc = $_POST['rm'];

        $del1 = "DELETE FROM user WHERE email='$mc'";
        $drun1 = mysqli_query($con,$del1);

       setcookie("udel","User Deleated Successfully",time()+2);
       echo "
        <script>
        window.location.href ='/myweb/adu.php';
        </script>
        ";

}


if(isset($_POST['addu'])){
    $nu = $_POST['n'];
    $e = $_POST['e'];
    $p = $_POST['p'];
    $mb = $_POST['m'];
    $ad = $_POST['ad'];
    $i = $_FILES['f1']['name'];


    $s = $p;
    $n = "";
    $n1 = "";

    $m = array(
       "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z",
    "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
    "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
    "!", "\"", "#", "$", "%", "&", "'", "(", ")", "*", "+", ",", "-", ".", "/", ":", ";", "<", "=", ">", "?", "@", "[", "\\", "]", "^", "_", "`", "{", "|", "}", "~",
    " ", "\t", "\n"
);
    for($i = 0; $i < strlen($s); $i++) {
        for($j = 0; $j < count($m); $j++) {
            if($s[$i] == $m[$j]) {
                $n .= $m[$j + 3];
            }
        }
    }


        for($i = 0; $i < strlen($n); $i++) {
            for($j = 0; $j < count($m); $j++) {
                if($n[$i] == $m[$j]) {
                    $n1 .= $m[$j - 3];  // Adding the character 3 positions ahead
                }
            }
        }




    $rs = "SELECT email,mobile FROM user where email='$e'or mobile='$mb'";
    $rsr =mysqli_query($con,$rs);
    if(mysqli_num_rows($rsr) >0){

        setcookie("eu","Entered email or mobile already exist",time()+2);
        echo "<script>
        window.location.href ='/myweb/adu.php';
        </script>";
    }
    else{
        $ff = uniqid().$_FILES['f1']['name'];
        if(move_uploaded_file($_FILES['f1']['tmp_name'],'uploads/'.$ff)){
            $c = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            $cup =  substr(str_shuffle($c),0,6);
        $ui = "INSERT INTO user (name,email,password,mobile,adr,cup,img) VALUES ('$nu','$e','$n','$mb','$ad','$cup','$ff')";
        $ur = mysqli_query($con,$ui);


        setcookie("uadd","User Added Successfully",time()+2);
        echo "<script>
        window.location.href ='/myweb/adu.php';
        </script>";
        }

    }
}








?>