<?php
include('ses.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comparition Page</title>
</head>



<body>
    <?php

if(isset($_SESSION['reg']) && $_SESSION['reg'] == "login" ||  isset($_SESSION['log']) &&  $_SESSION['log'] == "login"){
  include('navbaru.php');
}
else{
  include('navbar.php');
}
?>



    <div class="main-banner header-text" id="top1">
        <div class="Modern-Slider">
            <div class="item item-3">
                <div class="img-fill">
                    <div class="text-content">
                    </div>
                </div>
            </div>

        </div>
    </div>
    <br><br><br>


    <div class="container">
        <form action="cmp.php" method='post'>
            <div class="form-group">
                <select name="cp1" id="" class="form-control">
                    <option value="samsung Galaxy S25 5G">samsung Galaxy S25 5G</option>
                    <option value="Samsung Galaxy S25 Ultra 5G">Samsung Galaxy S25 Ultra 5G</option>
                    <option value="Samsung Galaxy M05">Samsung Galaxy M05</option>
                    <option value="Samsung Galaxy M15">Samsung Galaxy M15</option>
                    <option value="Samsung Galaxy A05">Samsung Galaxy A05</option>
                    <option value="Samsung Galaxy M35">Samsung Galaxy M35</option>
                    <option value="Vivo T3x 5G">Vivo T3x 5G</option>
                    <option value="Vivo T3x 5G">Vivo T3x 5G</option>
                    <option value="vivo Y28e 5G">vivo Y28e 5G</option>
                    <option value="Vivo Y29 5G">Vivo Y29 5G</option>
                    <option value="Vivo V40e 5G">Vivo V40e 5G</option>
                    <option value="Vivo Y27">Vivo Y27</option>
                    <option value="Redmi 14C 5G">Redmi 14C 5G</option>
                    <option value="edmi 13 5G">edmi 13 5G</option>
                    <option value="Redmi 13 5G">Redmi 13 5G</option>
                    <option value="Redmi Note 13">Redmi Note 13</option>
                    <option value="Oppo K12x">Oppo K12x</option>
                    <option value="Oppo K12x 5G">Oppo K12x 5G</option>
                    <option value="OPPO F27 Pro">OPPO F27 Pro</option>
                    <option value="OPPO A3 5G">OPPO A3 5G</option>
                    <option value="OPPO F27 5G">OPPO F27 5G</option>
                    <option value="Oppo A78 5G">Oppo A78 5G</option>
                    <option value="realme NARZO N61">realme NARZO N61</option>
                    <option value="realme NARZO 70x">realme NARZO 70x</option>
                    <option value="realme C65 5G">realme C65 5G</option>
                    <option value="realme NARZO 70 Turbo">realme NARZO 70 Turbo</option>
                    <option value="Redmi A4 5G">Redmi A4 5G</option>
                    <option value="realme 13 Pro 5G">realme 13 Pro 5G</option>
                </select>
            </div>


            <input type="submit" class="btn btn-primary" name='cp' value='compare'>
            <br><br>

            <div class="form-group">
                <select name="cp2" id="" class="form-control">
                    <option value="samsung Galaxy S25 5G">samsung Galaxy S25 5G</option>
                    <option value="Samsung Galaxy S25 Ultra 5G">Samsung Galaxy S25 Ultra 5G</option>
                    <option value="Samsung Galaxy M05">Samsung Galaxy M05</option>
                    <option value="Samsung Galaxy M15">Samsung Galaxy M15</option>
                    <option value="Samsung Galaxy A05">Samsung Galaxy A05</option>
                    <option value="Samsung Galaxy M35">Samsung Galaxy M35</option>
                    <option value="Vivo T3x 5G">Vivo T3x 5G</option>
                    <option value="Vivo T3x 5G">Vivo T3x 5G</option>
                    <option value="vivo Y28e 5G">vivo Y28e 5G</option>
                    <option value="Vivo Y29 5G">Vivo Y29 5G</option>
                    <option value="Vivo V40e 5G">Vivo V40e 5G</option>
                    <option value="Vivo Y27">Vivo Y27</option>
                    <option value="Redmi 14C 5G">Redmi 14C 5G</option>
                    <option value="edmi 13 5G">edmi 13 5G</option>
                    <option value="Redmi 13 5G">Redmi 13 5G</option>
                    <option value="Redmi Note 13">Redmi Note 13</option>
                    <option value="Oppo K12x">Oppo K12x</option>
                    <option value="Oppo K12x 5G">Oppo K12x 5G</option>
                    <option value="OPPO F27 Pro">OPPO F27 Pro</option>
                    <option value="OPPO A3 5G">OPPO A3 5G</option>
                    <option value="OPPO F27 5G">OPPO F27 5G</option>
                    <option value="Oppo A78 5G">Oppo A78 5G</option>
                    <option value="realme NARZO N61">realme NARZO N61</option>
                    <option value="realme NARZO 70x">realme NARZO 70x</option>
                    <option value="realme C65 5G">realme C65 5G</option>
                    <option value="realme NARZO 70 Turbo">realme NARZO 70 Turbo</option>
                    <option value="Redmi A4 5G">Redmi A4 5G</option>
                    <option value="realme 13 Pro 5G">realme 13 Pro 5G</option>

                </select>
            </div>
        </form>
        <?php


        if(isset($_POST['cp'])){
            $a=$_POST['cp1'];
            $sel1 = "SELECT  * FROM product where name='$a'";
            $run = mysqli_query($con,$sel1);
            $f = mysqli_fetch_assoc($run);

            $b= $_POST['cp2'];
            $sel2 = "SELECT  * FROM product where name='$b'";
            $run2 = mysqli_query($con,$sel2);
            $f1 = mysqli_fetch_assoc($run2);



            $st = $f['prize'];
            $int = (int)str_replace(",","",$st);

            $st1 = $f1['prize'];
            $int1 = (int)str_replace(",","",$st1);
            $tp = number_format($int);
            $tp1 = number_format($int1);



            // jese hi select ho jaye vese num rows ke wise data add karo table me.
            echo "<table class='container table table-striped table-responsive' style='font-size:16px;font-weight:bold;'>
                    <tr>
                    <th>Name</th>
                    <th>$f[name]</th>
                    <th>$f1[name]</th>
                    </tr>
                    <tr>
                    <th>Prize</th>
                    <th>$tp</th>
                    <th>$tp1</th>
                    </tr>


                    <tr>
                    <th>Offers</th>
                    <th>$f[offer]</th>
                    <th>$f1[offer]</th>
                    </tr>

                    <tr>
                    <th>Offers-Rate</th>
                    <th>$f[offr]</th>
                    <th>$f1[offr]</th>
                    </tr>


                    <tr>
                    <th>Discription</th>
                    <th>$f[di]</th>
                    <th>$f1[di]</th>
                    </tr>

                    <tr>
                    <th>About</th>
                    <pre><th id='sr'><textarea rows='8' name='' class=' form-control' readonly>$f[about]</textarea></th></pre>
                    <pre><th id='sr'><textarea rows='8' name='' class=' form-control' readonly>$f1[about]</textarea></th></pre>
                    </tr>

                    <tr>
                    <th>Memoriy</th>
                    <th>$f[mem]</th>
                    <th>$f1[mem]</th>
                    </tr>
                    <tr>
                    <th>Interface</th>
                    <th>$f[inf]</th>
                    <th>$f1[inf]</th>
                    </tr>
                    <tr>
                    <th>Technical</th>
                    <th>$f[tec]</th>
                    <th>$f1[tec]</th>
                    </tr>
                </table>
            ";


                // $_SESSION['ksl1'] = $f1['name'];
                // $_SESSION['ksl']  = $f['name'];

        }
        else{
            echo "<center><h2>Please Select To Compare Product</h2></center>";
        }

            ?>
    </div><br><br><br><br><br>
    <br><br><br><br><br>

    <?php
    include('foot.php');
    ?>

</body>

</html>