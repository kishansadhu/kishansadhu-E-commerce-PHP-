<?php
include('ses.php');

date_default_timezone_set('Asia/Kolkata');
$dt= date("Y-m-d H:i:s", time());

if(isset($_POST['sup'])){
    $em = $_SESSION['r']['e'];
    $qu =  $_POST['qup'];
    $pr = $_POST['pup'];
    $nm = $_POST['nup'];
    $str = (int)str_replace(",","",$pr);
    $total =  $str * (int)$_POST['qup'];

    $psl = "SELECT * FROM product where name='$nm'";
    $pslr = mysqli_query($con,$psl);
    $pslf = mysqli_fetch_assoc($pslr);




    $pk = "SELECT * FROM orders WHERE name='$nm' and email='$em'  and stat='pendding'";
    $pk1 = mysqli_query($con,$pk);
    $pk2 = mysqli_fetch_assoc($pk1);
    $pk3 = $pk2['qun'];



    $pkk = "SELECT * FROM product WHERE name='$nm'";
    $pkk1 = mysqli_query($con,$pkk);
    $pkk2 = mysqli_fetch_assoc($pkk1);
    $pkk3 = $pkk2['qun'];

    $niq =$qu -  $pk3;
    $fnl = $pkk3 - $niq;

    if($fnl <=50 && $fnl >=0){

    // echo $pk3."<br>";
    // echo $pkk3."<br>";
    // echo $niq."<br>";
    // echo $fnl."<br>";

    if($pk3 == $qu){
        echo "
        <script>
        window.location.href = '/myweb/checkout.php'
        </script>
        ";
    }
    else{
        $up = "UPDATE orders SET qun='$qu',tot='$total' where name='$nm' and stat='pendding' and email='$em' ";
        $run = mysqli_query($con,$up);

        $up111 = "UPDATE orderp SET qun='$qu',tot='$total' where name='$nm' and stat='pendding' and email='$em'";
        $run1 = mysqli_query($con,$up111);


        $int = "UPDATE product SET qun='$fnl' where name='$nm'";
        $irt= mysqli_query($con,$int);


        echo "
        <script>
        window.location.href = '/myweb/checkout.php'
        </script>
        ";
    }
}

    else{
        setcookie("piost","This Mobile Is Out Of Stock So Cannot Update This Quntity",time()+3);
        echo "
        <script>
        window.location.href = '/myweb/checkout.php'
        </script>
        ";
    }
}
















if(isset($_POST['rm1'])){
    $em = $_SESSION['r']['e'];
    $mc = $_POST['rm'];

    $mc4 = $_POST['rm4'];

            $em1 = $_SESSION['r']['e'];
            $mc = $_POST['rm'];
            $mc4 = $_POST['rm4'];


                $pp1 = "SELECT * FROM product where name='$mc' ";
                $pp2 = mysqli_query($con,$pp1);
                $pp3 = mysqli_fetch_assoc($pp2);

                $pp11= "SELECT * FROM orders where name='$mc'";
                $pp12 = mysqli_query($con,$pp11);
                $pp13 = mysqli_fetch_assoc($pp12);


                $flq1 = ($pp3['qun'] + $mc4) ;


                $int = "UPDATE product SET qun='$flq1' where name='$mc'";
                $irt= mysqli_query($con,$int);

                $del12 = "DELETE  FROM orders WHERE email='$em1' and stat='pendding' and name='$mc'";
                $drun12 = mysqli_query($con,$del12);

                $delkk = "DELETE FROM orderp WHERE email='$em1' and stat='pendding' and name='$mc'";
                mysqli_query($con, $delkk);
               setcookie("odel","Order Deleted Successfully",time()+3);
            echo "
                <script>
                window.location.href ='checkout.php';
                </script>
            ";

    }


















?>