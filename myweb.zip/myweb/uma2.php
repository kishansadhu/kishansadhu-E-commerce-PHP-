<?php
include('ses.php');

if(isset($_POST['upm'])){
    $nm = mysqli_real_escape_string($con,$_POST['n']);
    $e = mysqli_real_escape_string($con,$_POST['e']);
    $p = mysqli_real_escape_string($con,$_POST['p']);
    $mb = mysqli_real_escape_string($con,$_POST['m']);
    $ad = mysqli_real_escape_string($con,$_POST['ad']);
    $ff = $_FILES['f1']['name'];
    $em = $_SESSION['ue'];
    $ti = "user.png";


    $s = $p;
    $n = "";
    $n1 = "";

    $m = array(
       "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z",
    "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
    "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
    "!", "\"", "#", "$", "%", "&", "'", "(", ")", "*", "+", ",", "-", ".", "/", ":", ";", "<", "=", ">", "?", "@", "[", "\\", "]", "^", "_", "`", "{", "|", "}", "~",
    " ", "\t", "\n"
);
    for($i = 0; $i < strlen($s); $i++) {
        for($j = 0; $j < count($m); $j++) {
            if($s[$i] == $m[$j]) {
                $n .= $m[$j + 3];
            }
        }
    }


        for($i = 0; $i < strlen($n); $i++) {
            for($j = 0; $j < count($m); $j++) {
                if($n[$i] == $m[$j]) {
                    $n1 .= $m[$j - 3];  // Adding the character 3 positions ahead
                }
            }
        }





    $rs1 = "SELECT * FROM user where  mobile='$mb'";
    $rsr1 =mysqli_query($con,$rs1);
    if(mysqli_num_rows($rsr1)>0){
            setcookie("ude","Entered mobile num already exist",time()+2);
            echo "<script>
            window.location.href = '/myweb/adu.php';
            </script>";
    }

    else{
        if($_FILES['f1']['name'] == ""){
                $ui = "UPDATE user  SET name='$nm',email='$e',password='$n',mobile='$mb',adr='$ad',img='$ti' where email='$em'";
                $ur = mysqli_query($con,$ui);

                $fname = "SELECT * FROM user WHERE email='$e'";
                $frun=mysqli_query($con,$fname);
                $fd=mysqli_fetch_assoc($frun);


                setcookie("up","User Data Updated Successfully",time()+2);
                echo "<script>
                window.location.href = '/myweb/adu.php';
                </script>";

        }
        else{
            if(move_uploaded_file($_FILES['f1']['tmp_name'],'uploads/'.$ff)){

                $ui = "UPDATE user  SET name='$nm',email='$e',password='$n',mobile='$mb',adr='$ad',img='$ff' where email='$em'";
                $ur = mysqli_query($con,$ui);

                $fname = "SELECT * FROM user WHERE email='$e'";
                $frun=mysqli_query($con,$fname);
                $fd=mysqli_fetch_assoc($frun);


                setcookie("up1","User Data Updated Successfully",time()+2);
                echo "<script>
                window.location.href = '/myweb/adu.php';
                </script>";
                }
        }
    }


}
?>
