<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Details</title>
</head>

<body>
    <?php
   include('admin.php');

    if(isset($_POST['up'])){
        $e = $_POST['up1'];
        $q = $_POST['up2'];
        $_SESSION['ue'] = $e;
        $_SESSION['uq'] = $q;

        $seld = "SELECT  * FROM  contact where email='$e' and ques='$q'";
        $rund = mysqli_query($con,$seld);
        $fd = mysqli_fetch_assoc($rund);
    }
    else{
        echo "<script>
        window.location.href ='/myweb/conq.php'
        </script>";
    }


//    ?>
    <br><br>
    <style>
         table th {
        /* background: #79D7BE; */
        color: rgb(0, 0, 0);
        background: lightgray;

    }

    </style>
    <div class="container card" style="padding:20px;border-radius:20px;">
        <h2>View Details </h2>
        <hr><br>
        <table class='table table-bordered' style='background:red;'>
            <tr>
                <th style='font-size:20px;font-weight:bold;'>Name</th>
                <th style='font-size:17px;font-weight:bold;'><?php echo $fd['name']; ?></th>
            </tr>
            <tr>
                <th style='font-size:20px;font-weight:bold;'>Email</th>
                <th style='font-size:17px;font-weight:bold;'><?php echo $fd['email']; ?></th>
            </tr>
            <tr>
                <th style='font-size:20px;font-weight:bold;'>Query</th>
                <th style='font-size:17px;font-weight:bold;'><textarea readonly id=""><?php echo $fd['ques']; ?></textarea></th>
            </tr>

        </table>


    </div>



</body>

</html>